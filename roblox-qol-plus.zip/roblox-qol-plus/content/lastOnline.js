// Runs on roblox.com/users/{id}/profile pages. Deliberately renders as a
// fixed floating badge instead of injecting into Roblox's own profile
// layout — reaching into their DOM with specific selectors is exactly what
// breaks BTRoblox/Roblokis every time Roblox ships a redesign. A
// self-contained floating element has nothing to break.
(function () {
  const match = window.location.pathname.match(/^\/users\/(\d+)\/profile/);
  if (!match) return;

  const userId = Number(match[1]);

  const badge = document.createElement("div");
  badge.id = "qolplus-last-online-badge";
  badge.textContent = "Roblox QoL+: checking…";
  Object.assign(badge.style, {
    position: "fixed",
    bottom: "16px",
    right: "16px",
    zIndex: "999999",
    background: "#1b1b1d",
    color: "#f4f4f2",
    border: "2px solid #000",
    padding: "8px 12px",
    fontFamily: "system-ui, sans-serif",
    fontSize: "12px",
    fontWeight: "600",
    boxShadow: "2px 2px 0 #000",
  });
  document.body.appendChild(badge);

  chrome.runtime.sendMessage({ type: "GET_PRESENCE_SINGLE", userId }, (response) => {
    if (chrome.runtime.lastError) {
      badge.textContent = "Roblox QoL+: unavailable";
      return;
    }
    if (!response || !response.ok) {
      badge.textContent = `Roblox QoL+: ${response ? response.message : "error"}`;
      return;
    }
    badge.textContent = response.presence
      ? `Roblox QoL+: ${describe(response.presence)}`
      : "Roblox QoL+: no presence data";
  });

  // Mirrors lib/roblox-api.js describePresence() — kept inline here since
  // content scripts don't share the module graph with the background
  // service worker without a bundler.
  function describe(presence) {
    switch (presence.userPresenceType) {
      case 0:
        return presence.lastOnline
          ? `Last seen ${new Date(presence.lastOnline).toLocaleString()}`
          : "Offline";
      case 1:
        return "Online on Roblox";
      case 2:
        return "In a game now";
      case 3:
        return "In Roblox Studio";
      default:
        return "Unknown";
    }
  }
})();
