(() => {
  "use strict";

  /*
   * The harvester. This is the whole product now.
   *
   * Every previous version asked Spotify's servers for the library and lost,
   * for reasons that had nothing to do with this code: the Web API refuses the
   * web player's credential, and a credential of your own needs Premium and a
   * developer app. So this version stops asking.
   *
   * Your browser already has your library. The web player fetched it, laid it
   * out and rendered it — that is what you are looking at. Reading the rows on
   * your own screen needs no token, makes no request, has no quota and cannot
   * be rate limited, because nothing is being asked of anybody.
   *
   * The one obstacle is virtualisation. Spotify renders roughly fifteen rows
   * at a time and recycles them as you scroll, so at any instant the DOM holds
   * a sliver of a 935-track playlist. The fix is the obvious one: scroll the
   * list, collect what appears, repeat. A 935-track library is about sixty
   * steps and finishes in a few seconds.
   *
   * On "parallel processing", which was a reasonable thing to ask: it doesn't
   * apply here, and it is worth saying why rather than quietly not doing it.
   * There is one list, one scroll position and one renderer. You cannot be at
   * two scroll offsets at once, and workers have no DOM. What actually makes
   * this fast is not doing work in parallel but not waiting: each step waits
   * for the player to finish rendering — observed, not guessed at with a fixed
   * sleep — and moves on the instant it has. That turns a naive 15-second
   * sweep into a 4-second one.
   *
   * Three rules this file is built on, each paid for by an earlier version:
   *
   *   1. Every loop has a deadline. No exceptions, no "it'll finish eventually".
   *   2. Progress is a number that changes. If the number stops, the loop
   *      stops, and the user is told the number.
   *   3. Row identity comes from `aria-rowindex`, never from collection order.
   *      Recycled rows arrive out of order and repeat; the index is truth.
   */

  const MAX_SWEEP_MS = 120_000;
  const SETTLE_MAX_MS = 220;
  const STAGNANT_LIMIT = 8;
  const GAP_PASSES = 10;

  /* ------------------------------ locating ------------------------------ */

  /*
   * Test ids first because they are cheap and precise; structure second
   * because test ids are Spotify internals and have changed before. The ARIA
   * grid role is the part that has to keep working — screen readers depend on
   * it — which makes it the most durable selector available.
   */
  function findGrid() {
    const candidates = [
      '[data-testid="playlist-tracklist"]',
      '[data-testid="track-list"]',
      'main div[role="grid"][aria-rowcount]',
      'main div[role="grid"]',
      'main div[role="treegrid"]'
    ];

    for (const selector of candidates) {
      const node = document.querySelector(selector);
      if (node && node.getBoundingClientRect().height > 0) return node;
    }

    return null;
  }

  /*
   * The element that actually scrolls is not the grid — it is an ancestor, and
   * which ancestor has moved between Spotify redesigns. Rather than name it,
   * walk up and take the first thing that both overflows and has somewhere to
   * go. The `document.scrollingElement` fallback covers layouts where the
   * whole page scrolls instead.
   */
  function findScroller(from) {
    let node = from;

    while (node && node !== document.body) {
      const style = getComputedStyle(node);

      if (
        /(auto|scroll|overlay)/.test(style.overflowY) &&
        node.scrollHeight > node.clientHeight + 40
      ) {
        return node;
      }

      node = node.parentElement;
    }

    const root = document.scrollingElement || document.documentElement;
    return root.scrollHeight > root.clientHeight + 40 ? root : null;
  }

  /*
   * aria-rowcount includes the header row, so the track total is one less.
   * This is the single most useful number on the page: it lets progress be
   * "340 of 935" instead of "340 so far", and it gives the sweep a definite
   * finish line rather than a guess.
   */
  function readTotal(grid) {
    const count = Number(grid?.getAttribute("aria-rowcount"));
    if (Number.isFinite(count) && count > 1) return count - 1;

    return 0;
  }

  function rows(grid) {
    return grid.querySelectorAll(
      '[role="row"][aria-rowindex], [data-testid="tracklist-row"]'
    );
  }

  /* ------------------------------ reading ------------------------------ */

  const DURATION = /^(\d{1,2}):([0-5]\d)$/;

  function parseDuration(text) {
    const match = DURATION.exec(String(text || "").trim());
    if (!match) return 0;

    return (Number(match[1]) * 60 + Number(match[2])) * 1000;
  }

  /*
   * Spotify shows "3 days ago" for recent additions and "14 Aug 2024" for
   * older ones, in the user's own locale. Both are turned into a real date,
   * because `added:>2024-06` is worthless against a string.
   *
   * Relative dates are approximate by nature — "2 months ago" is a range, not
   * an instant — which is fine for a filter measured in months. Anything
   * unparseable is left null rather than guessed at.
   *
   * Everything is stored as UTC midnight of the calendar day the page showed.
   * "14 Aug 2024" parses as local midnight, and `toISOString` on local midnight
   * moves the date by a day for every reader east of Greenwich — so the index
   * said the 13th about a row that plainly read the 14th, and `added:` ranges
   * were off by one for half the world. The date on the page is a calendar
   * date, not an instant, so it is stored as one. `query.js` builds its
   * `added:` boundaries with `Date.UTC`, and the list view formats these back
   * in UTC, so all three agree.
   */
  const RELATIVE =
    /^(?:(\d+)|an?)\s+(sec|secs|second|min|mins|minute|hr|hrs|hour|day|wk|wks|week|mo|mos|month|yr|yrs|year)s?\s+ago$/i;

  const RELATIVE_MS = {
    sec: 1000,
    second: 1000,
    min: 60_000,
    minute: 60_000,
    hr: 3_600_000,
    hour: 3_600_000,
    day: 86_400_000,
    wk: 604_800_000,
    week: 604_800_000,
    mo: 2_629_800_000,
    month: 2_629_800_000,
    yr: 31_557_600_000,
    year: 31_557_600_000
  };

  /* The calendar day an instant falls on locally, pinned to UTC midnight. */
  function toCalendarDay(ms) {
    const local = new Date(ms);

    return new Date(
      Date.UTC(local.getFullYear(), local.getMonth(), local.getDate())
    ).toISOString();
  }

  function parseAdded(text) {
    const value = String(text || "").trim();
    if (!value) return null;

    if (/^today$/i.test(value)) return toCalendarDay(Date.now());

    if (/^yesterday$/i.test(value)) {
      return toCalendarDay(Date.now() - 86_400_000);
    }

    const relative = RELATIVE.exec(value);

    if (relative) {
      const unit = relative[2].toLowerCase().replace(/s$/, "");
      const scale = RELATIVE_MS[unit] ?? RELATIVE_MS[relative[2].toLowerCase()];

      if (scale) {
        /* "a week ago" has no digits; the article means one. */
        const count = relative[1] ? Number(relative[1]) : 1;
        return toCalendarDay(Date.now() - scale * count);
      }
    }

    const parsed = Date.parse(value);
    if (!Number.isNaN(parsed)) return toCalendarDay(parsed);

    return null;
  }

  /*
   * Is this cell plausibly a date at all?
   *
   * The date column is optional, and when it is absent the cell to the left of
   * the duration is the album. `Date.parse` accepts an album called "1989" and
   * one called "August", so it cannot be the test — it used to stamp a
   * completely fictional added-at onto those rows, which then silently decided
   * `added:` results.
   */
  function looksLikeDate(text) {
    if (RELATIVE.test(text)) return true;
    if (/^(today|yesterday)$/i.test(text)) return true;

    /* Every absolute form Spotify renders carries a day number *and* a month,
     * in some order and some locale: "14 Aug 2024", "Aug 14, 2024",
     * "2024-08-14", "14/08/2024". A bare year or a bare word is not one. */
    return text.length >= 6 && /\d/.test(text) && /[^\d\s]/.test(text);
  }

  function idFrom(href, kind) {
    const match = new RegExp(`/${kind}/([A-Za-z0-9]+)`).exec(String(href || ""));
    return match ? match[1] : null;
  }

  function cleanText(node) {
    return (node?.textContent || "").replace(/\s+/g, " ").trim();
  }

  /*
   * One row in, one record out, or null if the row isn't a track (the header,
   * a section divider, a still-rendering placeholder).
   *
   * Everything is read from links wherever possible: a track's identity lives
   * in `/track/<id>`, an artist's in `/artist/<id>`, an album's in
   * `/album/<id>`. Those hrefs are what the player itself navigates with, so
   * they are far more stable than any class name and unambiguous in a way that
   * text never is — two tracks can share a title, but not an id.
   */
  function readRow(row) {
    const rowIndex = Number(row.getAttribute("aria-rowindex"));
    if (!Number.isFinite(rowIndex) || rowIndex < 2) return null;

    /* Header is row 1, so the first track is row 2 and position 0. */
    const position = rowIndex - 2;

    const trackLink =
      row.querySelector('[data-testid="internal-track-link"]') ||
      row.querySelector('a[href*="/track/"]');

    const id = idFrom(trackLink?.getAttribute("href"), "track");

    const artistLinks = [...row.querySelectorAll('a[href*="/artist/"]')];
    const artists = artistLinks.map(cleanText).filter(Boolean);

    const albumLink = row.querySelector('a[href*="/album/"]');

    let name = cleanText(trackLink);
    let album = cleanText(albumLink);

    const cells = [...row.querySelectorAll('[role="gridcell"]')];

    /*
     * Local files have no Spotify id and no links at all, so the whole row is
     * plain text. They are real entries in the user's library and are indexed,
     * flagged, and excluded from anything that needs an id.
     */
    if (!name) {
      const titleCell = cells[1] || cells[0];
      const lines = (titleCell?.innerText || "").split("\n").map((s) => s.trim());
      const filled = lines.filter(Boolean);

      name = filled[0] || "";
      if (!artists.length && filled[1]) artists.push(filled[1]);
    }

    if (!name) return null;

    /* Duration is the cell that looks like a duration. Reading it by position
     * breaks the moment Spotify adds or removes a column, which it does. */
    let duration = 0;
    let durationCell = -1;

    for (let i = cells.length - 1; i >= 0; i--) {
      const text = cleanText(cells[i]);
      if (!text) continue;

      if (DURATION.test(text)) {
        duration = parseDuration(text);
        durationCell = i;
        break;
      }
    }

    /*
     * Date added sits immediately before the duration, when the column is
     * shown at all. Only that one cell is considered: the previous version
     * scanned every remaining cell and kept the first that `Date.parse`
     * accepted, which on a layout without a date column meant an album named
     * "1989" became an added-at of 1 January 1989.
     */
    let added = null;
    const dateCell = durationCell > 0 ? durationCell - 1 : -1;

    if (dateCell >= 0) {
      const text = cleanText(cells[dateCell]);
      if (text && looksLikeDate(text)) added = parseAdded(text);
    }

    if (!album) {
      /* Album as plain text, which happens in compact view and on some
       * playlist layouts. Take the cell between title and date. */
      const middle = cells[2];
      const text = cleanText(middle);

      /* Compared by index rather than by shape: an album really can be called
       * "1989", and rejecting it for looking date-ish would lose it. */
      if (text && !DURATION.test(text) && dateCell !== 2) album = text;
    }

    const image = row.querySelector("img")?.getAttribute("src") || "";

    return {
      position,
      id: id || `local:${position}`,
      name,
      artists,
      album,
      image,
      duration,
      added,
      isLocal: !id
    };
  }

  function collect(grid, into) {
    let added = 0;

    for (const row of rows(grid)) {
      const rowIndex = Number(row.getAttribute("aria-rowindex"));
      if (!Number.isFinite(rowIndex) || into.has(rowIndex)) continue;

      const record = readRow(row);
      if (!record) continue;

      into.set(rowIndex, record);
      added++;
    }

    return added;
  }

  /* ------------------------------ scrolling ------------------------------ */

  function frame() {
    return new Promise((resolve) => requestAnimationFrame(() => resolve()));
  }

  /*
   * Wait for the player to render, then continue — rather than sleeping for a
   * fixed period and hoping. A virtualised list mutates within a frame or two
   * of a scroll, so this usually returns well inside the timeout, and the
   * timeout only bites at the very bottom where nothing new renders.
   *
   * The observer is armed BEFORE the scroll, which is the whole trick and was
   * worth finding: React commits a scroll-driven re-render synchronously, so
   * an observer attached afterwards has already missed the mutation it is
   * waiting for and sits out the full timeout every single step. Measured on a
   * 935-track list that mistake was the difference between four seconds and
   * seventy.
   */
  function arm(grid) {
    let settle;
    const settled = new Promise((resolve) => {
      settle = resolve;
    });

    let done = false;

    const finish = async () => {
      if (done) return;
      done = true;

      observer.disconnect();
      clearTimeout(timer);

      /* One frame after the mutation, so layout is committed and the rows
       * being read are finished rather than half-built. */
      await frame();
      settle();
    };

    const observer = new MutationObserver(finish);
    observer.observe(grid, { childList: true, subtree: true });

    const timer = setTimeout(finish, SETTLE_MAX_MS);

    return settled;
  }

  /* Arm, act, wait. Never act then arm. */
  async function stepAndSettle(grid, action) {
    const settled = arm(grid);
    action();
    await settled;
  }

  function settle(grid) {
    return arm(grid);
  }

  function atBottom(scroller) {
    return scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4;
  }

  /* ------------------------------ sweeping ------------------------------ */

  /*
   * The main sweep. Linear pass down the list, then targeted passes to fill
   * anything that was skipped — which happens when a scroll step outruns the
   * renderer, and is why the result is checked rather than assumed.
   */
  async function harvest({ onProgress, signal } = {}) {
    const grid = findGrid();
    if (!grid) throw new Error("NO_TRACKLIST");

    const total = readTotal(grid);
    const scroller = findScroller(grid);

    /*
     * No scroller means the list does not overflow, which means every row it
     * has is already rendered. Short playlists took this path straight into a
     * NO_SCROLLER error in the first draft — a twelve-track playlist is not a
     * failure, it is the easiest possible case.
     */
    if (!scroller) {
      const visible = new Map();
      collect(grid, visible);

      const records = [...visible.entries()]
        .sort((a, b) => a[0] - b[0])
        .map(([, record], index) => ({ ...record, position: index }));

      onProgress?.({ collected: records.length, total: total || records.length, complete: true });

      return {
        records,
        total: total || records.length,
        complete: true,
        aborted: false
      };
    }
    const found = new Map();
    const deadline = Date.now() + MAX_SWEEP_MS;

    /* Put the user back where they were when this is over. Nobody asked to be
     * teleported to the bottom of their library. */
    const origin = scroller.scrollTop;

    const report = () =>
      onProgress?.({ collected: found.size, total, complete: false });

    const aborted = () => signal?.aborted || Date.now() > deadline;

    try {
      await stepAndSettle(grid, () => {
        scroller.scrollTop = 0;
      });

      collect(grid, found);
      report();

      let stagnant = 0;
      let lastSize = found.size;

      while (!aborted()) {
        if (total && found.size >= total) break;

        const wasAtBottom = atBottom(scroller);

        /* 80% of a viewport, so consecutive steps overlap. A full-viewport
         * step leaves a seam whenever rendering lags by even one row. */
        await stepAndSettle(grid, () => {
          scroller.scrollTop += Math.max(240, scroller.clientHeight * 0.8);
        });

        collect(grid, found);
        report();

        if (wasAtBottom) break;

        if (found.size === lastSize) {
          stagnant++;
          if (stagnant >= STAGNANT_LIMIT) break;
        } else {
          stagnant = 0;
          lastSize = found.size;
        }
      }

      /* Bottom of the list: the last screenful often needs a beat longer,
       * because there is no further scroll to trigger a render. */
      await settle(grid);
      collect(grid, found);
      report();

      if (total) await fillGaps({ grid, scroller, found, total, deadline, signal, report });
    } finally {
      scroller.scrollTop = origin;
    }

    const records = [...found.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([, record], index) => ({ ...record, position: index }));

    const complete = Boolean(total) && records.length >= total;

    onProgress?.({ collected: records.length, total, complete: true });

    return { records, total: total || records.length, complete, aborted: Boolean(signal?.aborted) };
  }

  /*
   * A linear sweep can skip rows. Rather than sweep again and hope, work out
   * exactly which row indices are missing and scroll to each one.
   *
   * The estimate uses measured row height rather than a constant, because row
   * height differs between the normal and compact list views and getting it
   * wrong turns a targeted pass into another blind one.
   */
  async function fillGaps({ grid, scroller, found, total, deadline, signal, report }) {
    for (let pass = 0; pass < GAP_PASSES; pass++) {
      if (found.size >= total) return;
      if (signal?.aborted || Date.now() > deadline) return;

      /* Progress, not passes, is the stopping condition. A fixed number of
       * attempts loses rows whenever a gap-filling scroll is itself dropped —
       * which happens, because the thing being worked around is a renderer
       * that sometimes does not render. Keep going while it is still finding
       * things; stop the moment a whole pass adds nothing. */
      const before = found.size;

      const missing = [];
      for (let rowIndex = 2; rowIndex <= total + 1; rowIndex++) {
        if (!found.has(rowIndex)) missing.push(rowIndex);
      }

      if (!missing.length) return;

      const rowHeight = measureRowHeight(grid) || 56;
      const base = measureGridOffset(grid, scroller);

      /* Group neighbouring gaps so one scroll covers a run of them. */
      const targets = [];
      for (const rowIndex of missing) {
        const last = targets[targets.length - 1];
        if (last === undefined || rowIndex - last > 8) targets.push(rowIndex);
      }

      for (const rowIndex of targets) {
        if (signal?.aborted || Date.now() > deadline) return;

        const offset = Math.max(
          0,
          base + (rowIndex - 2) * rowHeight - scroller.clientHeight / 2
        );

        await stepAndSettle(grid, () => {
          scroller.scrollTop = offset;
        });

        collect(grid, found);
        report();
      }

      if (found.size === before) return;
    }
  }

  function measureRowHeight(grid) {
    const list = rows(grid);

    for (const row of list) {
      const height = row.getBoundingClientRect().height;
      if (height > 20) return height;
    }

    return 0;
  }

  /*
   * How far the first track row sits below the top of the scroller's content.
   *
   * Spotify puts a large header above the grid — cover art, title, play button,
   * on a playlist page a description too — so the first row does not begin at
   * scroll offset zero. `position * rowHeight` was therefore several hundred
   * pixels short on every targeted scroll, which quietly turned gap filling and
   * "scroll to this result" back into the blind guessing they exist to replace.
   *
   * Measured from a row that is currently on screen, because the rendered
   * layout is the only thing that is actually true; the header's height is not
   * a constant and differs between playlist, album and Liked Songs pages.
   */
  function measureGridOffset(grid, scroller) {
    if (!scroller) return 0;

    const scrollerTop = scroller.getBoundingClientRect
      ? scroller.getBoundingClientRect().top
      : 0;

    for (const row of rows(grid)) {
      const rowIndex = Number(row.getAttribute("aria-rowindex"));
      if (!Number.isFinite(rowIndex) || rowIndex < 2) continue;

      const rect = row.getBoundingClientRect();
      if (!(rect.height > 20)) continue;

      const topWithinContent = rect.top - scrollerTop + scroller.scrollTop;

      return Math.max(0, topWithinContent - (rowIndex - 2) * rect.height);
    }

    return 0;
  }

  /* -------------------------- playlist directory -------------------------- */

  /*
   * Which playlists exist, read from the sidebar — which is also virtualised,
   * so it gets the same treatment. Falls back to whatever is rendered if the
   * sidebar can't be scrolled, which is correct for small libraries where
   * everything is on screen anyway.
   *
   * Only `/playlist/` links are taken. Albums, artists and the Liked Songs
   * entry live in the same list and are not playlists.
   */
  async function harvestPlaylistDirectory({ signal } = {}) {
    const container = findSidebarList();
    const found = new Map();

    const sweep = () => {
      for (const link of document.querySelectorAll('a[href^="/playlist/"]')) {
        const id = idFrom(link.getAttribute("href"), "playlist");
        if (!id || found.has(id)) continue;

        const name =
          cleanText(link.querySelector("p, span, div")) ||
          link.getAttribute("aria-label") ||
          cleanText(link);

        if (!name) continue;

        found.set(id, { id, name });
      }
    };

    sweep();

    const scroller = container ? findScroller(container) : null;

    if (scroller) {
      const origin = scroller.scrollTop;
      const deadline = Date.now() + 20_000;

      try {
        await stepAndSettle(container, () => {
          scroller.scrollTop = 0;
        });

        sweep();

        let stagnant = 0;
        let lastSize = found.size;

        while (!signal?.aborted && Date.now() < deadline) {
          const wasAtBottom = atBottom(scroller);

          await stepAndSettle(container, () => {
            scroller.scrollTop += Math.max(200, scroller.clientHeight * 0.8);
          });

          sweep();

          if (wasAtBottom) break;

          if (found.size === lastSize) {
            stagnant++;
            if (stagnant >= 4) break;
          } else {
            stagnant = 0;
            lastSize = found.size;
          }
        }
      } finally {
        scroller.scrollTop = origin;
      }
    }

    return [...found.values()];
  }

  function findSidebarList() {
    const candidates = [
      '[data-testid="rootlist"]',
      'nav [role="list"]',
      '[aria-label="Your Library"]',
      'nav'
    ];

    for (const selector of candidates) {
      const node = document.querySelector(selector);
      if (node && node.querySelector('a[href^="/playlist/"]')) return node;
    }

    return null;
  }

  /* --------------------------- page description --------------------------- */

  function readTitle() {
    const heading =
      document.querySelector('[data-testid="entityTitle"] h1') ||
      document.querySelector("main h1");

    return cleanText(heading);
  }

  /*
   * What is this page, and is there anything on it worth harvesting? Answered
   * from the URL and the DOM together so the caller never has to guess.
   */
  function describePage() {
    const path = location.pathname;
    const grid = findGrid();
    const total = grid ? readTotal(grid) : 0;

    if (path === "/collection/tracks") {
      return { type: "liked", id: null, label: "Liked Songs", total, hasGrid: Boolean(grid) };
    }

    const playlist = /^\/playlist\/([^/?#]+)/.exec(path);

    if (playlist) {
      return {
        type: "playlist",
        id: decodeURIComponent(playlist[1]),
        label: readTitle() || "Playlist",
        total,
        hasGrid: Boolean(grid)
      };
    }

    return { type: null, id: null, label: "", total: 0, hasGrid: false };
  }

  window.SLSHarvest = {
    harvest,
    harvestPlaylistDirectory,
    describePage,
    findGrid,
    findScroller,
    readTotal,
    readRow,
    parseAdded,
    parseDuration,
    measureRowHeight,
    measureGridOffset
  };
})();
