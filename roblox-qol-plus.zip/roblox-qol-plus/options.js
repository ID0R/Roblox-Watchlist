import { getSettings, updateSettings } from "./lib/storage.js";
import { isPremiumUnlocked, unlockWithCode } from "./lib/premium.js";

const input = document.getElementById("pollInterval");
const saveBtn = document.getElementById("saveBtn");
const status = document.getElementById("saveStatus");
const premiumStatus = document.getElementById("premiumStatus");
const unlockCodeInput = document.getElementById("unlockCodeInput");
const unlockBtn = document.getElementById("unlockBtn");
const unlockError = document.getElementById("unlockError");
const lastErrorLine = document.getElementById("lastErrorLine");

async function render() {
  const settings = await getSettings();
  input.value = settings.pollIntervalMinutes;

  const unlocked = await isPremiumUnlocked();
  premiumStatus.textContent = unlocked ? "Unlocked" : "Locked";
  unlockCodeInput.style.display = unlocked ? "none" : "";
  unlockBtn.style.display = unlocked ? "none" : "";

  if (settings.lastError) {
    const when = new Date(settings.lastError.at).toLocaleString();
    lastErrorLine.textContent = `Last error (${settings.lastError.source}) at ${when}: ${settings.lastError.message}`;
  } else {
    lastErrorLine.textContent = "";
  }
}

saveBtn.addEventListener("click", async () => {
  const minutes = Math.max(1, Number(input.value) || 1);
  await updateSettings({ pollIntervalMinutes: minutes });
  chrome.runtime.sendMessage({ type: "SET_POLL_INTERVAL", minutes });
  status.textContent = "Saved.";
  setTimeout(() => (status.textContent = ""), 1500);
});

unlockBtn.addEventListener("click", async () => {
  unlockError.textContent = "";
  try {
    await unlockWithCode(unlockCodeInput.value);
    unlockCodeInput.value = "";
    render();
  } catch (err) {
    unlockError.textContent = err.message;
  }
});

render();
