"use strict";
(function attachStore(global) {
  const Text = global.SLSText;

  const SCHEMA_VERSION = 10;
  const CHUNK_SIZE = 500;
  const META_PREFIX = "idx.meta.";
  const CHUNK_PREFIX = "idx.chunk.";
  const PLAYLIST_DIRECTORY_KEY = "idx.playlists";

  const memory = new Map();
  const locks = new Map();

  function contextKey(context) {
    if (context?.type === "liked") return "liked";
    if (context?.type === "global") return "global";
    if (context?.type === "playlist" && context.id) return `pl_${context.id}`;
    throw new Error("INVALID_CONTEXT");
  }

  const metaKey = (key) => `${META_PREFIX}${key}`;
  const chunkKey = (key, index) => `${CHUNK_PREFIX}${key}.${index}`;

  function withLock(key, task) {
    const previous = locks.get(key) || Promise.resolve();
    const next = previous.then(task, task);
    locks.set(key, next.catch(() => {}));
    return next;
  }

  function trackUri(song) {
    return song.lo ? "" : `spotify:track:${song.id}`;
  }
  function trackUrl(song) {
    return song.lo ? "" : `https://open.spotify.com/track/${song.id}`;
  }

  function toRecord(row, position) {
    const name = String(row?.name || "").trim();
    if (!name) return null;
    const artists = Array.isArray(row.artists) ? row.artists.filter(Boolean) : [];
    const album = String(row.album || "").trim();
    return {
      i: position,
      id: row.id || `local:${position}`,
      n: name,
      a: artists,
      al: album,
      im: String(row.image || ""),
      y: 0,
      d: Number(row.duration) || 0,
      ad: row.added || null,
      lo: row.isLocal ? 1 : 0,
      _t: Text.normalize(name),
      _a: Text.normalize(artists.join(" ")),
      _l: Text.normalize(album)
    };
  }

  function toRecords(rows) {
    const byPosition = new Map();
    for (const row of rows || []) {
      const position = Number(row?.position);
      if (!Number.isFinite(position)) continue;
      if (byPosition.has(position)) continue;
      byPosition.set(position, row);
    }
    const ordered = [...byPosition.entries()].sort((a, b) => a[0] - b[0]);
    const records = [];
    for (const [position, row] of ordered) {
      const record = toRecord(row, position);
      if (record) records.push(record);
    }
    return records;
  }

  async function readMeta(key) {
    const stored = await chrome.storage.local.get(metaKey(key));
    const meta = stored[metaKey(key)];
    if (!meta || meta.v !== SCHEMA_VERSION) return null;
    return meta;
  }

  async function readChunks(key, chunkCount) {
    if (!chunkCount) return [];
    const keys = [];
    for (let i = 0; i < chunkCount; i++) keys.push(chunkKey(key, i));
    const stored = await chrome.storage.local.get(keys);
    const songs = [];
    for (const name of keys) {
      const chunk = stored[name];
      if (Array.isArray(chunk)) songs.push(...chunk);
    }
    return songs;
  }

  async function dropChunks(key, chunkCount) {
    if (!chunkCount) return;
    const keys = [];
    for (let i = 0; i < chunkCount; i++) keys.push(chunkKey(key, i));
    await chrome.storage.local.remove(keys);
  }

  async function load(context) {
    const key = contextKey(context);
    const cached = memory.get(key);
    if (cached) return cached;
    const meta = await readMeta(key);
    if (!meta) return null;
    const songs = await readChunks(key, meta.chunks);
    const entry = { meta, songs };
    memory.set(key, entry);
    return entry;
  }

  async function write(context, rows, { total, complete = true } = {}) {
    const key = contextKey(context);
    const records = toRecords(rows);
    return withLock(key, async () => {
      const existing = await readMeta(key);
      const wantedTotal = Number(total) || 0;
      const isComplete =
        Boolean(complete) && (!wantedTotal || records.length >= wantedTotal);
      if (existing?.complete && existing.count >= records.length) {
        memory.delete(key);
        return { indexed: existing.count, complete: true };
      }
      if (!isComplete && existing && existing.count >= records.length) {
        memory.delete(key);
        return { indexed: existing.count, complete: Boolean(existing.complete) };
      }
      if (existing) await dropChunks(key, existing.chunks);
      const writes = {};
      let chunks = 0;
      for (let i = 0; i < records.length; i += CHUNK_SIZE) {
        writes[chunkKey(key, chunks)] = records.slice(i, i + CHUNK_SIZE);
        chunks++;
      }
      const meta = {
        v: SCHEMA_VERSION,
        type: context.type,
        id: context.id || null,
        label: context.label || "",
        total: wantedTotal || records.length,
        count: records.length,
        chunks,
        indexedAt: Date.now(),
        complete: isComplete
      };
      writes[metaKey(key)] = meta;
      await chrome.storage.local.set(writes);
      memory.set(key, { meta, songs: records });
      if (context.type === "playlist" && context.id) {
        await notePlaylist(context, records.length);
      }
      return { indexed: records.length, complete: isComplete };
    });
  }

  async function getStatus(context) {
    if (context?.type === "global") return getGlobalStatus();
    const entry = await load(context);
    if (!entry) {
      return { ready: false, complete: false, indexed: 0, total: 0, indexedAt: null, headId: null };
    }
    return {
      ready: entry.songs.length > 0,
      complete: Boolean(entry.meta.complete),
      indexed: entry.songs.length,
      total: entry.meta.total || entry.songs.length,
      indexedAt: entry.meta.indexedAt || null,
      /* Position 0 = the newest entry in a newest-first list. Cheap enough
       * to include on every status check, and it's what lets the content
       * script tell "still fresh" apart from "count matches by luck". */
      headId: entry.songs[0]?.id || null
    };
  }

  async function getPlaylistDirectory() {
    const stored = await chrome.storage.local.get(PLAYLIST_DIRECTORY_KEY);
    return stored[PLAYLIST_DIRECTORY_KEY] || null;
  }

  async function setPlaylistDirectory(playlists) {
    const existing = (await getPlaylistDirectory()) || { playlists: [] };
    const byId = new Map(existing.playlists.map((entry) => [entry.id, entry]));
    for (const playlist of playlists || []) {
      if (!playlist?.id) continue;
      byId.set(playlist.id, { ...(byId.get(playlist.id) || {}), ...playlist });
    }
    const directory = { updatedAt: Date.now(), playlists: [...byId.values()] };
    await chrome.storage.local.set({ [PLAYLIST_DIRECTORY_KEY]: directory });
    return directory;
  }

  async function notePlaylist(context, total) {
    await setPlaylistDirectory([{ id: context.id, name: context.label || "Playlist", total }]);
  }

  async function getGlobalStatus() {
    const directory = await getPlaylistDirectory();
    const contexts = [{ type: "liked" }, ...(directory?.playlists || []).map(toPlaylistContext)];
    let indexed = 0, covered = 0, coveredPlaylists = 0;
    for (const context of contexts) {
      const meta = await readMeta(contextKey(context));
      if (!meta?.count) continue;
      indexed += meta.count;
      covered++;
      if (context.type === "playlist") coveredPlaylists++;
    }
    return {
      ready: covered > 0,
      complete: covered === contexts.length && contexts.length > 1,
      indexed, total: indexed,
      playlists: directory?.playlists?.length || 0,
      covered: coveredPlaylists, indexedAt: null
    };
  }

  function toPlaylistContext(playlist) {
    return { type: "playlist", id: playlist.id, label: playlist.name };
  }

  async function loadGlobal() {
    const directory = await getPlaylistDirectory();
    const contexts = [{ type: "liked", label: "Liked Songs" }, ...(directory?.playlists || []).map(toPlaylistContext)];
    const sources = [];
    for (const context of contexts) {
      const entry = await load(context);
      if (!entry?.songs.length) continue;
      sources.push({
        context, label: context.label || "Liked Songs",
        labelNorm: Text.normalize(context.label || "Liked Songs"),
        songs: entry.songs
      });
    }
    return sources;
  }

  async function clearAllIndexes() {
    const all = await chrome.storage.local.get(null);
    const keys = Object.keys(all).filter(
      (key) => key.startsWith(META_PREFIX) || key.startsWith(CHUNK_PREFIX) || key === PLAYLIST_DIRECTORY_KEY
    );
    if (keys.length) await chrome.storage.local.remove(keys);
    memory.clear();
    locks.clear();
  }

  async function estimateUsage() {
    const all = await chrome.storage.local.get(null);
    let indexBytes = 0, contexts = 0;
    for (const [key, value] of Object.entries(all)) {
      if (key.startsWith(CHUNK_PREFIX)) indexBytes += JSON.stringify(value).length;
      if (key.startsWith(META_PREFIX)) contexts++;
    }
    return { indexBytes, contexts };
  }

  global.SLSStore = {
    SCHEMA_VERSION, contextKey, toPlaylistContext, toRecords, load, loadGlobal, write,
    getStatus, getGlobalStatus, getPlaylistDirectory, setPlaylistDirectory,
    clearAllIndexes, estimateUsage, trackUri, trackUrl
  };
})(typeof self !== "undefined" ? self : globalThis);