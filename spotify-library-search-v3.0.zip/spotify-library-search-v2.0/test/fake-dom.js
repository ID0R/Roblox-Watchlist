"use strict";

/*
 * A stand-in for Spotify's virtualised tracklist, faithful in the ways that
 * matter to the harvester: only a window of rows exists at any moment, the
 * window follows scrollTop, aria-rowindex is the only stable identity, and
 * rows carry their data in links and gridcells.
 *
 * Built by hand because the container has no network and therefore no jsdom.
 * That turned out to be a feature: this fake can be made to misbehave in the
 * specific ways a real renderer does — lagging behind a fast scroll, rendering
 * a narrower window than expected — which is exactly what the gap-filling pass
 * exists for and what a well-behaved mock would never exercise.
 */

const ROW_HEIGHT = 56;

function makeLibrary(count) {
  const artists = [
    ["Travis Scott"],
    ["Travis Scott", "Drake"],
    ["Kendrick Lamar"],
    ["Queen"],
    ["Daft Punk"],
    ["Café Tacvba"],
    ["Travis Scott", "Kid Cudi"]
  ];

  const albums = ["ASTROWORLD", "Rodeo", "Discovery", "Jazz", "UTOPIA", "Birds"];

  return Array.from({ length: count }, (_, i) => ({
    id: `trk${String(i).padStart(6, "0")}`,
    name:
      i % 37 === 0
        ? "SICKO MODE"
        : i % 11 === 0
          ? `Don't Stop ${i}`
          : `Track Number ${i}`,
    artists: artists[i % artists.length],
    album: albums[i % albums.length],
    duration: `${2 + (i % 4)}:${String(10 + (i % 49)).padStart(2, "0")}`,
    added: i % 3 === 0 ? "2 weeks ago" : "14 Aug 2024"
  }));
}

/* ------------------------------ fake nodes ------------------------------ */

class Node {
  constructor({ tag = "div", attrs = {}, children = [], text = "" } = {}) {
    this.tag = tag;
    this.attrs = attrs;
    this.childNodes = children;
    this.text = text;
  }

  getAttribute(name) {
    return name in this.attrs ? String(this.attrs[name]) : null;
  }

  get textContent() {
    if (this.text) return this.text;
    return this.childNodes.map((child) => child.textContent).join(" ");
  }

  get innerText() {
    if (this.text) return this.text;
    return this.childNodes.map((child) => child.innerText).join("\n");
  }

  matches(selector) {
    /* Compound selectors are split, exactly as a browser would. */
    if (selector.includes(",")) {
      return selector.split(",").some((part) => this.matches(part.trim()));
    }

    if (selector === '[role="row"][aria-rowindex]') {
      return this.attrs.role === "row" && "aria-rowindex" in this.attrs;
    }

    if (selector === '[data-testid="tracklist-row"]') {
      return this.attrs["data-testid"] === "tracklist-row";
    }

    if (selector === "p, span, div") return true;

    if (selector === "img") return this.tag === "img";
    if (selector === '[role="gridcell"]') return this.attrs.role === "gridcell";
    if (selector === '[data-testid="internal-track-link"]') {
      return this.attrs["data-testid"] === "internal-track-link";
    }

    const href = this.attrs.href || "";
    if (selector === 'a[href*="/track/"]') return this.tag === "a" && href.includes("/track/");
    if (selector === 'a[href*="/artist/"]') return this.tag === "a" && href.includes("/artist/");
    if (selector === 'a[href*="/album/"]') return this.tag === "a" && href.includes("/album/");
    if (selector === 'a[href^="/playlist/"]') return this.tag === "a" && href.startsWith("/playlist/");
    if (selector === '[role="row"]') return this.attrs.role === "row";

    return false;
  }

  walk(out = []) {
    out.push(this);
    for (const child of this.childNodes) child.walk(out);
    return out;
  }

  querySelectorAll(selector) {
    return this.walk().filter((node) => node !== this && node.matches(selector));
  }

  querySelector(selector) {
    return this.querySelectorAll(selector)[0] || null;
  }

  getBoundingClientRect() {
    return { width: 800, height: ROW_HEIGHT, top: 0, left: 0, bottom: ROW_HEIGHT };
  }
}

/*
 * A row that knows where it is.
 *
 * Geometry used to be a constant — every row claimed `top: 0` — which made the
 * fake agree with any scroll maths at all, correct or not. Spotify's rows sit
 * below a page header of a few hundred pixels and move as the scroller moves,
 * so a row that reports its real position is what makes "scroll to row N"
 * testable rather than merely runnable.
 */
class RowNode extends Node {
  constructor(options, grid, rowIndex) {
    super(options);
    this.grid = grid;
    this.rowIndex = rowIndex;
  }

  getBoundingClientRect() {
    const top =
      this.grid.header + (this.rowIndex - 2) * ROW_HEIGHT - this.grid.scroller.scrollTop;

    return { width: 800, height: ROW_HEIGHT, top, left: 0, bottom: top + ROW_HEIGHT };
  }
}

function buildRow(track, rowIndex, grid) {
  const cells = [
    new Node({ attrs: { role: "gridcell" }, text: String(rowIndex - 1) }),
    new Node({
      attrs: { role: "gridcell" },
      children: [
        new Node({ tag: "img", attrs: { src: `https://i.scdn.co/image/${track.id}` } }),
        new Node({
          tag: "a",
          attrs: { href: `/track/${track.id}`, "data-testid": "internal-track-link" },
          text: track.name
        }),
        ...track.artists.map(
          (name, i) =>
            new Node({ tag: "a", attrs: { href: `/artist/a${i}` }, text: name })
        )
      ]
    }),
    new Node({
      attrs: { role: "gridcell" },
      children: [
        new Node({ tag: "a", attrs: { href: `/album/al1` }, text: track.album })
      ]
    }),
    new Node({ attrs: { role: "gridcell" }, text: track.added }),
    new Node({ attrs: { role: "gridcell" }, text: track.duration })
  ];

  return new RowNode(
    {
      attrs: {
        role: "row",
        "aria-rowindex": rowIndex,
        "data-testid": "tracklist-row"
      },
      children: cells
    },
    grid,
    rowIndex
  );
}

/* ------------------------------ the grid ------------------------------ */

class FakeGrid extends Node {
  /*
   * `header` is the height of everything Spotify paints above the first track
   * row — cover art, title, play controls, and on a playlist page a
   * description. It defaults to 0 so existing cases keep their old geometry,
   * and a case that sets it is testing whether the harvester's scroll targets
   * account for the offset or merely assume row 0 starts at pixel 0.
   */
  constructor(
    tracks,
    { viewport = 700, overscan = 3, lag = 0, flakyEvery = 0, header = 0 } = {}
  ) {
    super({ attrs: { role: "grid", "aria-rowcount": tracks.length + 1, "data-testid": "playlist-tracklist" } });

    this.tracks = tracks;
    this.viewport = viewport;
    this.overscan = overscan;
    this.lag = lag;
    this.flakyEvery = flakyEvery;
    this.header = header;
    this.scrolls = 0;

    this.observers = [];
    this.renderCount = 0;

    this.scroller = new FakeScroller(this);
    this.render(0);
  }

  get perScreen() {
    return Math.ceil(this.viewport / ROW_HEIGHT);
  }

  render(scrollTop) {
    /* The header scrolls away with the content, so the first track on screen
     * is decided by how far past the header the scroller has travelled. */
    const past = scrollTop - this.header;

    const first = Math.max(0, Math.floor(past / ROW_HEIGHT) - this.overscan);
    const last = Math.min(this.tracks.length - 1, first + this.perScreen + this.overscan * 2);

    const rows = [];
    for (let i = first; i <= last; i++) rows.push(buildRow(this.tracks[i], i + 2, this));

    this.childNodes = rows;
    this.renderCount++;

    for (const callback of this.observers) setTimeout(callback, 0);
  }

  getBoundingClientRect() {
    const top = this.header - this.scroller.scrollTop;
    return { width: 800, height: this.viewport, top, left: 0, bottom: top + this.viewport };
  }
}

class FakeScroller {
  constructor(grid) {
    this.grid = grid;
    this._scrollTop = 0;
    this.childNodes = [grid];
  }

  get clientHeight() {
    return this.grid.viewport;
  }

  get scrollHeight() {
    return this.grid.header + this.grid.tracks.length * ROW_HEIGHT;
  }

  get scrollTop() {
    return this._scrollTop;
  }

  set scrollTop(value) {
    const max = Math.max(0, this.scrollHeight - this.clientHeight);
    this._scrollTop = Math.max(0, Math.min(max, value));

    this.grid.scrolls++;

    /* A dropped render: the browser was busy and this scroll produced no new
     * rows at all. Real and occasional, and precisely what the gap-filling
     * pass exists to recover from. */
    if (this.grid.flakyEvery && this.grid.scrolls % this.grid.flakyEvery === 0) return;

    if (this.grid.lag) setTimeout(() => this.grid.render(this._scrollTop), this.grid.lag);
    else this.grid.render(this._scrollTop);
  }

  getBoundingClientRect() {
    return { width: 800, height: this.grid.viewport, top: 0, left: 0, bottom: this.grid.viewport };
  }

  querySelector() {
    return null;
  }
}

/* --------------------------- global installation --------------------------- */

function install(grid) {
  const body = { tag: "body" };

  grid.parentElement = grid.scroller;
  grid.scroller.parentElement = body;

  global.document = {
    body,
    documentElement: { scrollHeight: 0, clientHeight: 0 },
    scrollingElement: { scrollHeight: 0, clientHeight: 0 },

    querySelector(selector) {
      if (
        selector === '[data-testid="playlist-tracklist"]' ||
        selector === 'main div[role="grid"][aria-rowcount]' ||
        selector === 'main div[role="grid"]'
      ) {
        return grid;
      }

      return null;
    },

    querySelectorAll() {
      return [];
    }
  };

  global.getComputedStyle = (node) =>
    node === grid.scroller ? { overflowY: "auto" } : { overflowY: "visible" };

  global.requestAnimationFrame = (fn) => setTimeout(fn, 0);

  global.MutationObserver = class {
    constructor(callback) {
      this.callback = callback;
    }

    observe(target) {
      const host = target === grid ? grid : grid;
      host.observers.push(this.callback);
      this._host = host;
    }

    disconnect() {
      if (!this._host) return;
      this._host.observers = this._host.observers.filter((cb) => cb !== this.callback);
    }
  };

  global.location = { pathname: "/collection/tracks" };
  global.window = global;
}

module.exports = { makeLibrary, FakeGrid, install, ROW_HEIGHT };
