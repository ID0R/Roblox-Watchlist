import { getSettings, updateSettings } from "./lib/storage.js";

const input = document.getElementById("pollInterval");
const saveBtn = document.getElementById("saveBtn");
const status = document.getElementById("saveStatus");

(async () => {
  const settings = await getSettings();
  input.value = settings.pollIntervalMinutes;
})();

saveBtn.addEventListener("click", async () => {
  const minutes = Math.max(1, Number(input.value) || 1);
  await updateSettings({ pollIntervalMinutes: minutes });
  chrome.runtime.sendMessage({ type: "SET_POLL_INTERVAL", minutes });
  status.textContent = "Saved.";
  setTimeout(() => (status.textContent = ""), 1500);
});
