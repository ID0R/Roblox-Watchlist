// Runs on roblox.com/games/{placeId}/... pages. This is the only reliable
// signal an extension can get about "the game you're currently playing" —
// actual gameplay happens in the native Roblox client, not the browser tab,
// so we treat "you have this game's page open" as the current-game context.
(function () {
  const match = window.location.pathname.match(/^\/games\/(\d+)/);
  if (!match) return;

  const placeId = Number(match[1]);
  const placeName = document.title.replace(/\s*-\s*Roblox$/, "");

  chrome.runtime.sendMessage({
    type: "CURRENT_GAME_DETECTED",
    placeId,
    placeName,
  });
})();
