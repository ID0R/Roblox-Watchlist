"use strict";
const { makeLibrary, FakeGrid, install } = require("./fake-dom.js");

async function run(label, count, opts) {
  const tracks = makeLibrary(count);
  const grid = new FakeGrid(tracks, opts);
  install(grid);

  // Load the real harvester against the fake DOM.
  delete require.cache[require.resolve("../content/harvest.js")];
  require("../content/harvest.js");

  const started = Date.now();
  let lastProgress = null;

  const result = await global.window.SLSHarvest.harvest({
    onProgress: (p) => { lastProgress = p; }
  });

  const ms = Date.now() - started;

  // Correctness: every track, once, in the right order.
  const names = result.records.map(r => r.name);
  const expected = tracks.map(t => t.name);
  const exact = names.length === expected.length && names.every((n, i) => n === expected[i]);
  const ids = new Set(result.records.map(r => r.id));

  console.log(
    `${label.padEnd(34)} ${String(result.records.length).padStart(5)}/${count}  ` +
    `unique=${String(ids.size).padStart(5)}  order=${exact ? "ok " : "BAD"}  ` +
    `complete=${result.complete}  renders=${grid.renderCount}  ${ms}ms`
  );

  if (!exact) {
    const missing = expected.filter(n => !names.includes(n)).slice(0, 5);
    console.log("      missing sample:", missing);
  }

  return { result, tracks, exact };
}

(async () => {
  console.log("harvest results (real harvest.js against a fake virtualised grid)\n");

  const a = await run("935 tracks, clean renderer", 935, {});
  await run("935 tracks, renderer lags 30ms", 935, { lag: 30 });
  await run("935 tracks, zero overscan", 935, { overscan: 0 });
  await run("935 tracks, every 4th render drops", 935, { flakyEvery: 4 });
  await run("935 tracks, every 3rd drops + lag", 935, { flakyEvery: 3, lag: 20, overscan: 0 });

  /* A page header pushes every row down by a few hundred pixels. The sweep
   * itself only scrolls forward and survives that, but the gap-filling pass
   * scrolls to a computed row — so it is the dropped-render case that proves
   * the offset is measured rather than assumed. */
  await run("935 tracks, 320px page header", 935, { header: 320 });
  await run("935 tracks, header + drops", 935, {
    header: 512,
    viewport: 400,
    flakyEvery: 4,
    overscan: 0
  });

  await run("10,000 tracks", 10000, {});
  await run("12 tracks (fits on screen)", 12, {});
  await run("1 track", 1, {});
  await run("0 tracks", 0, {});

  console.log("\nheader offset measurement:");
  for (const header of [0, 320, 512]) {
    const grid = new FakeGrid(makeLibrary(200), { header });
    install(grid);

    grid.scroller.scrollTop = header + 40 * 56;

    const measured = global.window.SLSHarvest.measureGridOffset(grid, grid.scroller);
    console.log(
      `  header=${String(header).padStart(4)}  measured=${String(Math.round(measured)).padStart(4)}` +
      `  ${Math.abs(measured - header) < 1 ? "ok" : "BAD"}`
    );
  }

  console.log("\nfield extraction, first record of the 935 run:");
  console.log(JSON.stringify(a.result.records[0], null, 2));

  console.log("\nrelative + absolute date parsing:");
  const H = global.window.SLSHarvest;
  for (const s of ["2 weeks ago", "14 Aug 2024", "today", "yesterday", "3 months ago", "nonsense"]) {
    const v = H.parseAdded(s);
    console.log(`  ${s.padEnd(14)} -> ${v ? v.slice(0, 10) : "null"}`);
  }
})();
