(() => {
"use strict";
const Text = window.SLSText;
const Query = window.SLSQuery;
const Tracklist = window.SLSTracklist;
const Harvest = window.SLSHarvest;
const Sweep = window.SLSSweep;
const ROW_SELECTOR = '[data-testid="tracklist-row"], [role="row"][aria-rowindex]';
const ROUTES = [
  { id: "liked", test: (path) => path === "/collection/tracks", placeholder: "Search Liked Songs", scopeLabel: "Liked Songs" },
  { id: "playlist", test: (path) => /^\/playlist\/[^/]+/.test(path), placeholder: "Search this playlist", scopeLabel: "This playlist" }
];
const SEARCH_DEBOUNCE_MS = 60;
const OBSERVER_INTERVAL_MS = 220;
const ROW_SCAN_ATTEMPTS = 10;
const RESULT_LIMIT = 0;
const state = {
  route: null, playlistId: null, contextLabel: "", scope: "context", root: null, shell: null, panel: null,
  savedBox: null, input: null, counter: null, clearButton: null, statusBox: null, actionButton: null,
  resultList: null, footer: null, progressBar: null, support: null, overlay: null, query: "", parsed: null,
  results: [], activeIndex: -1, panelOpen: false, searchSeq: 0, searchTimer: 0, mountTimer: 0, positionFrame: 0,
  observerTimer: 0, observerPending: false, lastObserverRun: 0, statusTimer: 0, harvesting: false,
  harvestController: null, lastHarvestKey: "", savedFilters: [], settings: null, disconnected: false
};
const ICONS = {
  search: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M10.533 2.25a8.283 8.283 0 0 1 6.607 13.279l4.165 4.166a1.125 1.125 0 0 1-1.59 1.59l-4.166-4.165A8.283 8.283 0 1 1 10.533 2.25Zm0 2.25a6.033 6.033 0 1 0 0 12.066 6.033 6.033 0 0 0 0-12.066Z"/></svg>',
  clear: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5.25 5.25a1.06 1.06 0 0 1 1.5 0L12 10.5l5.25-5.25a1.06 1.06 0 1 1 1.5 1.5L13.5 12l5.25 5.25a1.06 1.06 0 1 1-1.5 1.5L12 13.5l-5.25 5.25a1.06 1.06 0 1 1-1.5-1.5L10.5 12 5.25 6.75a1.06 1.06 0 0 1 0-1.5Z"/></svg>',
  coffee: '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill-rule="evenodd">' +
    '<path d="M4 9.5h12.2v4.7a5.1 5.1 0 0 1-5.1 5.1H9.1A5.1 5.1 0 0 1 4 14.2V9.5Zm2 2v2.7a3.1 3.1 0 0 0 3.1 3.1h2a3.1 3.1 0 0 0 3.1-3.1v-2.7H6Z"/>' +
    '<path d="M17.4 10.6h1.3a3.2 3.2 0 0 1 0 6.4h-1.3v-2h1.3a1.2 1.2 0 0 0 0-2.4h-1.3v-2Z"/>' +
    '<path d="M3.6 20.4h13v1.8h-13v-1.8Z"/>' +
    '<path d="M7.6 3.2c.9.9.9 2 0 2.9l-1-1c.3-.3.3-.6 0-.9l1-1Zm3.4 0c.9.9.9 2 0 2.9l-1-1c.3-.3.3-.6 0-.9l1-1Z"/>' +
    "</svg>"
};
const KOFI_URL = "https://ko-fi.com/id0r58858";

init();

async function init() {
  patchHistory();
  observeDom();
  document.addEventListener("keydown", onGlobalKeydown, true);
  document.addEventListener("pointerdown", onDocumentPointerDown, true);
  window.addEventListener("resize", schedulePanelPosition, { passive: true });
  window.addEventListener("scroll", schedulePanelPosition, { passive: true, capture: true });
  chrome.runtime.onMessage.addListener(onRuntimeMessage);
  Tracklist?.setHandlers({ onActivate: (track) => activateFromList(track), onClear: () => resetSearch({ keepFocus: true }) });
  state.settings = (await send({ type: "GET_SETTINGS" }))?.settings || null;
  state.savedFilters = state.settings?.savedFilters || [];
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.settings) return;
    state.settings = changes.settings.newValue || state.settings;
    state.savedFilters = state.settings?.savedFilters || [];
    applySupportVisibility();
    renderSavedFilters();
  });
  scheduleMount(0);
  Sweep.resume({ onProgress: renderSweepOverlay, onDone: onSweepDone });
}

async function send(message) {
  try {
    const response = await chrome.runtime.sendMessage(message);
    return response || { ok: false, error: "NO_RESPONSE" };
  } catch (error) {
    const text = String(error?.message || error || "");
    if (/context invalidated|receiving end does not exist/i.test(text)) {
      state.disconnected = true;
      return { ok: false, error: "EXTENSION_RELOADED" };
    }
    return { ok: false, error: text || "MESSAGE_FAILED" };
  }
}

function onRuntimeMessage(message) {
  if (message?.type === "FOCUS_SEARCH") { focusSearch(); return; }
  if (message?.type === "SHOW_TRACK_PLAYLISTS") { showTrackPlaylists(message.trackId, null); return; }
  if (message?.type === "START_SWEEP") { beginSweep(); }
}

function currentRoute() { return ROUTES.find((route) => route.test(location.pathname)) || null; }
function currentPlaylistId() {
  const match = location.pathname.match(/^\/playlist\/([^/?#]+)/);
  return match ? decodeURIComponent(match[1]) : null;
}
function getContext() {
  if (state.scope === "global") return { type: "global", label: "Your library" };
  if (!state.route) return null;
  if (state.route.id === "liked") return { type: "liked", label: "Liked Songs" };
  if (state.route.id === "playlist" && state.playlistId) {
    return { type: "playlist", id: state.playlistId, label: state.contextLabel || "" };
  }
  return null;
}
function contextKey(context) {
  if (!context) return "";
  return context.type === "playlist" ? `pl_${context.id}` : context.type;
}

function scheduleMount(wait = 120) {
  clearTimeout(state.mountTimer);
  state.mountTimer = setTimeout(mount, wait);
}

function mount() {
  const route = currentRoute();
  if (!route) { teardown(); return; }
  if (!document.body) { scheduleMount(120); return; }
  const previousRoute = state.route;
  const previousPlaylist = state.playlistId;
  state.route = route;
  state.playlistId = route.id === "playlist" ? currentPlaylistId() : null;
  state.contextLabel = route.id === "playlist" ? Harvest.describePage().label || "Playlist" : "Liked Songs";
  if (!state.root || !state.root.isConnected) build();
  attachToActionBar();
  applyRouteChrome();
  const contextChanged = previousRoute?.id !== route.id || previousPlaylist !== state.playlistId;
  if (contextChanged) {
    resetSearch({ keepFocus: false });
    if (state.settings?.autoIndexOnOpen !== false) warmIndex();
  } else if (state.query.trim()) {
    applyRowHighlights();
  }
}

function build() {
  const root = document.createElement("div");
  root.className = "sls-root";
  root.dataset.slsRoot = "true";
  const shell = document.createElement("div");
  shell.className = "sls-shell";
  shell.innerHTML = `
    <span class="sls-icon">${ICONS.search}</span>
    <input class="sls-input" type="text" autocomplete="off" spellcheck="false"
      role="combobox" aria-expanded="false" aria-autocomplete="list"
      aria-controls="sls-results" aria-haspopup="listbox">
    <span class="sls-spinner" aria-hidden="true"></span>
    <span class="sls-count" aria-live="polite" aria-atomic="true"></span>
    <button class="sls-clear" type="button" aria-label="Clear search">
      ${ICONS.clear}
    </button>
  `;
  root.appendChild(shell);
  const support = document.createElement("a");
  support.className = "sls-kofi";
  support.href = KOFI_URL;
  support.target = "_blank";
  support.rel = "noopener noreferrer";
  support.title = "Support this extension on Ko-fi";
  support.setAttribute("aria-label", "Support this extension on Ko-fi");
  support.innerHTML = ICONS.coffee;
  root.appendChild(support);
  const panel = document.createElement("div");
  panel.className = "sls-panel";
  panel.hidden = true;
  panel.innerHTML = `
    <div class="sls-progress" hidden><span></span></div>
    <div class="sls-saved" hidden></div>
    <div class="sls-scopes" role="tablist" aria-label="Search scope">
      <button class="sls-scope is-active" type="button" role="tab"
        data-scope="context" aria-selected="true"></button>
      <button class="sls-scope" type="button" role="tab"
        data-scope="global" aria-selected="false">Everything</button>
    </div>
    <div class="sls-status" role="status" hidden></div>
    <button class="sls-action" type="button" hidden></button>
    <div class="sls-results" id="sls-results" role="listbox" tabindex="-1"></div>
    <div class="sls-footer" hidden></div>
  `;
  document.body.append(root, panel);
  state.root = root;
  state.shell = shell;
  state.panel = panel;
  state.input = shell.querySelector(".sls-input");
  state.counter = shell.querySelector(".sls-count");
  state.clearButton = shell.querySelector(".sls-clear");
  state.statusBox = panel.querySelector(".sls-status");
  state.actionButton = panel.querySelector(".sls-action");
  state.resultList = panel.querySelector(".sls-results");
  state.footer = panel.querySelector(".sls-footer");
  state.progressBar = panel.querySelector(".sls-progress");
  state.savedBox = panel.querySelector(".sls-saved");
  state.savedBox.addEventListener("click", onSavedClick);
  state.input.addEventListener("input", onInput);
  state.input.addEventListener("keydown", onInputKeydown);
  state.input.addEventListener("focus", onInputFocus);
  for (const type of ["keydown", "keyup", "keypress"]) {
    state.input.addEventListener(type, (event) => event.stopPropagation());
  }
  state.clearButton.addEventListener("click", () => resetSearch({ keepFocus: true }));
  state.actionButton.addEventListener("click", onActionClick);
  for (const button of panel.querySelectorAll(".sls-scope")) {
    button.addEventListener("click", () => setScope(button.dataset.scope));
  }
  state.resultList.addEventListener("click", onResultClick);
  state.resultList.addEventListener("mousemove", onResultHover);
  state.support = support;
  applySupportVisibility();
}

async function harvestCurrentPage({ force = false } = {}) {
  const context = getContext();
  if (!context || context.type === "global") return { ok: false, error: "NO_CONTEXT" };
  const page = Harvest.describePage();
  if (!page.hasGrid) return { ok: false, error: "NO_TRACKLIST" };
  if (state.harvesting) return { ok: true, running: true };
  const key = contextKey(context);
  if (!force && state.lastHarvestKey === key) return { ok: true, cached: true };
  state.harvesting = true;
  state.harvestController = new AbortController();
  const controller = state.harvestController;
  const filterWasActive = Tracklist?.isActive();
  if (filterWasActive) Tracklist.restore();
  try {
    const result = await Harvest.harvest({
      signal: controller.signal,
      onProgress: (progress) => renderHarvestProgress(progress, context)
    });
    if (!result.records.length) {
      return { ok: false, error: "EMPTY_TRACKLIST" };
    }
    if (!result.complete || controller.signal.aborted) {
      showTransientStatus(
        `Read ${formatCount(result.records.length)} of ${formatCount(result.total)} ` +
          `tracks — not complete, so not stored. Will try again.`
      );
      return { ok: true, indexed: 0, complete: false, short: true };
    }
    await send({ type: "INGEST", context, records: result.records, total: result.total, complete: true });
    state.lastHarvestKey = key;
    return { ok: true, indexed: result.records.length, complete: true };
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  } finally {
    state.harvesting = false;
    state.harvestController = null;
    renderProgress(null);
    if (filterWasActive && state.query.trim()) runSearch({ silent: true });
  }
}

function renderHarvestProgress(progress, context) {
  const collected = progress.collected || 0;
  const total = progress.total || 0;
  renderProgress({ indexed: collected, total, complete: progress.complete });
  if (state.results.length) {
    setFooterSuffix(total ? `reading ${formatCount(collected)} of ${formatCount(total)}` : `reading ${formatCount(collected)}`);
    return;
  }
  const what = context.type === "liked" ? "Liked Songs" : context.label || "this playlist";
  showStatus(
    total ? `Reading ${what} — ${formatCount(collected)} of ${formatCount(total)} tracks` : `Reading ${what} — ${formatCount(collected)} tracks`
  );
}

/*
 * Is the stored index still trustworthy for this page, or does it need a
 * re-read?
 *
 * The old check was "does the stored count match the page's count" — but a
 * count match doesn't mean the CONTENTS still match. Liked Songs is
 * newest-first: liking one new track pushes every existing track down by
 * one position, and unliking an old one anywhere shifts everything below
 * it up by one. If you also unliked something since the last index, the
 * counts can coincidentally still agree while every stored position below
 * the change point now points at the wrong track. That's a silent
 * mismatch a count comparison can never catch, and it's exactly what made
 * old (low-on-the-page) tracks fail to play while search kept finding them
 * fine — the record's name/artist text is still correct, only its
 * position has drifted.
 *
 * The cheap, high-value check: does the CURRENTLY VISIBLE first row match
 * what the index believes is first? That catches the common case (new
 * likes shifting the list) without paying for a full re-harvest on every
 * page visit.
 */
async function warmIndex() {
  const context = getContext();
  if (!context || context.type === "global") return;
  const status = await send({ type: "GET_CONTEXT_STATUS", context });
  const page = Harvest.describePage();
  const indexed = status?.status?.indexed || 0;
  const countOk =
    status.ok &&
    status.status?.ready &&
    status.status?.complete !== false &&
    (!page.total || indexed >= page.total);
  if (countOk && headStillMatches(status.status?.headId)) {
    state.lastHarvestKey = contextKey(context);
    return;
  }
  harvestCurrentPage({ force: true });
}

/* True if we can't tell yet (nothing rendered, nothing stored) — absence of
 * evidence isn't evidence of staleness, and shouldn't force an extra
 * harvest on its own. False only on a positive, checkable mismatch. */
function headStillMatches(storedHeadId) {
  if (!storedHeadId) return true;
  const top = visibleRows().find((row) => Number(row.getAttribute("aria-rowindex")) === 2);
  if (!top) return true;
  const link =
    top.querySelector('[data-testid="internal-track-link"]') ||
    top.querySelector('a[href*="/track/"]') ||
    top.querySelector('a[href*="/episode/"]') ||
    top.querySelector('a[href*="/show/"]');
  const href = link?.getAttribute("href") || "";
  const match = /\/(?:track|episode|show)\/([A-Za-z0-9]+)/.exec(href);
  if (!match) return true;
  return match[1] === storedHeadId;
}

function onInput(event) {
  state.query = event.target.value || "";
  state.parsed = Query.parse(state.query);
  state.activeIndex = -1;
  const hasQuery = Boolean(state.query.trim());
  state.root.classList.toggle("has-value", hasQuery);
  clearTimeout(state.searchTimer);
  if (!hasQuery) { resetSearch({ keepFocus: true }); return; }
  applyRowHighlights();
  openPanel();
  setBusy(true);
  state.searchTimer = setTimeout(runSearch, SEARCH_DEBOUNCE_MS);
}

async function runSearch({ silent = false } = {}) {
  const context = getContext();
  if (!context || !state.query.trim()) return;
  const seq = ++state.searchSeq;
  const stale = () => seq !== state.searchSeq;
  const response = await send({ type: "SEARCH", context, query: state.query, limit: RESULT_LIMIT });
  if (stale()) return;
  if (!response.ok) { setBusy(false); showError(response.error); return; }
  if (response.ready && (response.totalMatches || state.harvesting)) {
    present(response, { silent });
    if (!state.harvesting && shouldRefresh(context, response)) harvestCurrentPage();
    return;
  }
  if (response.ready && !state.harvesting) { present(response, { silent }); return; }
  if (context.type === "global") {
    showAction("Searching every playlist needs a one-time pass through your library.", "Index my whole library", "sweep");
    setBusy(false);
    return;
  }
  const result = await harvestCurrentPage();
  if (stale()) return;
  if (!result.ok) { setBusy(false); showError(result.error); return; }
  runSearch({ silent: true });
}

function shouldRefresh(context, response) {
  if (context.type === "global") return false;
  if (state.lastHarvestKey === contextKey(context)) return false;
  const page = Harvest.describePage();
  if (!page.total) return false;
  return (response.indexedTotal || 0) < page.total;
}

function present(response, { silent }) {
  setBusy(false);
  state.results = response.results || [];
  state.activeIndex = -1;
  state.counter.textContent = response.totalMatches ? `${response.totalMatches}` : "0";
  renderResults(response);
  applyListFilter(response);
  if (!silent) applyRowHighlights();
}

function applyListFilter(response) {
  if (!Tracklist) return;
  if (state.harvesting || state.settings?.filterList === false || state.scope === "global") {
    Tracklist.restore();
    return;
  }
  Tracklist.apply(state.results, {
    totalMatches: response.totalMatches || 0,
    indexedTotal: response.indexedTotal || 0,
    query: state.query.trim(),
    indexing: state.harvesting
  });
}

async function beginSweep() {
  showStatus("Finding your playlists…");
  await Sweep.start({ onProgress: renderSweepOverlay });
  Sweep.resume({ onProgress: renderSweepOverlay, onDone: onSweepDone });
}

function renderSweepOverlay(progress) {
  if (!state.overlay) {
    const overlay = document.createElement("div");
    overlay.className = "sls-sweep";
    overlay.innerHTML = `
      <div class="sls-sweep-head">
        <strong>Indexing your library</strong>
        <button class="sls-sweep-cancel" type="button">Stop</button>
      </div>
      <div class="sls-sweep-bar"><span></span></div>
      <div class="sls-sweep-note"></div>
    `;
    overlay.querySelector(".sls-sweep-cancel").addEventListener("click", async () => {
      await Sweep.cancel();
      removeSweepOverlay();
    });
    document.body.appendChild(overlay);
    state.overlay = overlay;
  }
  const done = progress.done || 0;
  const total = progress.total || 0;
  const ratio = total ? Math.min(1, done / total) : 0;
  state.overlay.querySelector(".sls-sweep-bar span").style.width = `${Math.round(ratio * 100)}%`;
  const retryNote = progress.attempt > 1 ? ` (retry ${progress.attempt - 1} of 1)` : "";
  state.overlay.querySelector(".sls-sweep-note").textContent =
    progress.phase === "discovering"
      ? progress.label || "Finding your playlists…"
      : `${done} of ${total} · ${progress.label || ""}${retryNote} · ` +
        `reading ${formatCount(progress.collected || 0)} · ` +
        `${formatCount(progress.tracks || 0)} indexed total`;
}

function removeSweepOverlay() {
  state.overlay?.remove();
  state.overlay = null;
}

function onSweepDone(result) {
  removeSweepOverlay();
  if (result.cancelled) {
    showTransientStatus(`Stopped. ${formatCount(result.tracks)} tracks were indexed.`);
    return;
  }
  const failed = result.failures?.length ? ` ${result.failures.length} couldn't be read fully.` : "";
  showTransientStatus(`Indexed ${formatCount(result.tracks)} tracks across ${result.total} places.${failed}`);
  if (state.query.trim()) runSearch({ silent: true });
}

function renderSavedFilters() {
  if (!state.savedBox) return;
  const filters = state.savedFilters || [];
  const query = state.query.trim();
  const saveable = query && !filters.some((filter) => filter.query === query);
  state.savedBox.textContent = "";
  if (!filters.length && !saveable) { state.savedBox.hidden = true; return; }
  state.savedBox.hidden = false;
  for (const filter of filters) {
    const chip = document.createElement("button");
    chip.type = "button";
    chip.className = "sls-saved-chip";
    chip.dataset.query = filter.query;
    chip.title = filter.query;
    chip.textContent = filter.name;
    const remove = document.createElement("span");
    remove.className = "sls-saved-x";
    remove.dataset.remove = filter.id;
    remove.textContent = "×";
    remove.setAttribute("role", "button");
    remove.setAttribute("aria-label", `Delete saved filter ${filter.name}`);
    chip.appendChild(remove);
    state.savedBox.appendChild(chip);
  }
  if (saveable) {
    const add = document.createElement("button");
    add.type = "button";
    add.className = "sls-saved-chip is-add";
    add.dataset.save = "1";
    add.textContent = "＋ Save this filter";
    state.savedBox.appendChild(add);
  }
}

async function onSavedClick(event) {
  const remove = event.target.closest?.("[data-remove]");
  if (remove) {
    event.preventDefault();
    event.stopPropagation();
    const result = await send({ type: "DELETE_FILTER", id: remove.dataset.remove });
    if (result.ok) state.savedFilters = result.filters || [];
    renderSavedFilters();
    return;
  }
  const chip = event.target.closest?.(".sls-saved-chip");
  if (!chip) return;
  event.preventDefault();
  if (chip.dataset.save) {
    const result = await send({ type: "SAVE_FILTER", query: state.query.trim(), name: state.query.trim() });
    if (result.ok) state.savedFilters = result.filters || [];
    renderSavedFilters();
    return;
  }
  applyQuery(chip.dataset.query);
}

function applyQuery(query) {
  if (!query || !state.input) return;
  state.input.value = query;
  state.input.focus();
  state.input.dispatchEvent(new Event("input", { bubbles: true }));
}

function applySupportVisibility() {
  if (!state.support) return;
  state.support.hidden = state.settings?.showSupportLink === false;
}

function findPrimaryPlayButton() {
  const nodes = document.querySelectorAll('main button, main [role="button"]');
  for (const node of nodes) {
    if (node.closest('[role="row"], [data-testid="tracklist-row"], .sls-fl')) continue;
    const hint = `${node.getAttribute("aria-label") || ""} ${node.getAttribute("data-testid") || ""}`;
    if (!/play/i.test(hint)) continue;
    const rect = node.getBoundingClientRect();
    if (rect.width >= 40 && rect.height >= 40) return node;
  }
  return null;
}

function findActionBar() {
  for (const selector of ['[data-testid="action-bar-row"]', '[data-testid="playlist-action-bar-row"]', '[data-testid="action-bar"]']) {
    const node = document.querySelector(selector);
    if (node && isVisible(node)) return node;
  }
  const play = findPrimaryPlayButton();
  if (!play) return null;
  const main = document.querySelector("main") || document.body;
  const mainWidth = main.getBoundingClientRect().width || window.innerWidth;
  let node = play.parentElement;
  while (node && node !== document.body) {
    const rect = node.getBoundingClientRect();
    if (rect.width > mainWidth * 0.55 && rect.height > 0 && rect.height < 170) return node;
    node = node.parentElement;
  }
  return null;
}

function attachToActionBar() {
  if (state.root.isConnected && state.root.parentElement?.isConnected && state.query.trim()) {
    schedulePanelPosition();
    return;
  }
  const bar = findActionBar();
  if (!bar) {
    state.root.classList.add("sls-floating");
    if (state.root.parentElement !== document.body) document.body.appendChild(state.root);
    schedulePanelPosition();
    return;
  }
  state.root.classList.remove("sls-floating");
  const children = [...bar.children].filter((node) => node !== state.root && isVisible(node));
  const rect = bar.getBoundingClientRect();
  const midpoint = rect.left + rect.width / 2;
  const rightIndex = children.findIndex((node) => node.getBoundingClientRect().left > midpoint);
  const before = rightIndex > 0 ? children[rightIndex] : null;
  if (before) {
    if (state.root.parentElement !== bar || state.root.nextElementSibling !== before) bar.insertBefore(state.root, before);
  } else if (state.root.parentElement !== bar || state.root.nextElementSibling) {
    bar.appendChild(state.root);
  }
  schedulePanelPosition();
}

function isVisible(node) {
  const rect = node.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0 && rect.bottom > 0;
}

function applyRouteChrome() {
  if (!state.input || !state.route) return;
  const placeholder = state.scope === "global" ? "Search your whole library" : state.route.placeholder;
  state.input.placeholder = placeholder;
  state.input.setAttribute("aria-label", placeholder);
  const contextTab = state.panel.querySelector('.sls-scope[data-scope="context"]');
  if (contextTab) contextTab.textContent = state.route.scopeLabel;
}

function teardown() {
  clearTimeout(state.searchTimer);
  clearTimeout(state.mountTimer);
  clearTimeout(state.statusTimer);
  cancelAnimationFrame(state.positionFrame);
  state.harvestController?.abort();
  clearRowHighlights();
  Tracklist?.restore();
  state.root?.remove();
  state.panel?.remove();
  Object.assign(state, {
    route: null, playlistId: null, root: null, shell: null, panel: null, input: null, counter: null,
    clearButton: null, statusBox: null, actionButton: null, resultList: null, footer: null, progressBar: null,
    support: null, query: "", parsed: null, results: [], activeIndex: -1, panelOpen: false, harvesting: false
  });
}

function renderResults(response) {
  if (!state.resultList) return;
  state.resultList.textContent = "";
  clearWherePanels();
  if (!response.totalMatches) {
    if (state.harvesting) return;
    showStatus(response.indexedTotal ? `No matches in ${formatCount(response.indexedTotal)} tracks` : "Nothing indexed yet");
    setFooter(chipText(response.chips));
    openPanel();
    return;
  }
  hideStatus();
  const shown = state.results;
  const fragment = document.createDocumentFragment();
  shown.forEach((track, index) => fragment.appendChild(buildResultRow(track, index)));
  state.resultList.appendChild(fragment);
  const pieces = [];
  if (response.totalMatches > shown.length) {
    pieces.push(`${shown.length} of ${formatCount(response.totalMatches)} matches`);
  } else {
    pieces.push(`${shown.length} ${shown.length === 1 ? "match" : "matches"}`);
  }
  pieces.push("Enter to play");
  const chips = chipText(response.chips);
  if (chips) pieces.push(chips);
  setFooter(pieces.join(" · "));
  renderSavedFilters();
  openPanel();
}

function buildResultRow(track, index) {
  const row = document.createElement("div");
  row.className = "sls-result";
  row.id = `sls-result-${index}`;
  row.dataset.index = String(index);
  row.setAttribute("role", "option");
  row.setAttribute("aria-selected", "false");
  if (track.image) {
    const art = document.createElement("img");
    art.className = "sls-art";
    art.src = track.image;
    art.alt = "";
    art.loading = "lazy";
    art.decoding = "async";
    art.referrerPolicy = "no-referrer";
    row.appendChild(art);
  } else {
    row.dataset.noArt = "true";
  }
  const body = document.createElement("span");
  body.className = "sls-result-body";
  const title = document.createElement("span");
  title.className = "sls-result-title";
  title.textContent = track.name;
  const meta = document.createElement("span");
  meta.className = "sls-result-meta";
  meta.textContent = [track.artists?.join(", "), track.album].filter(Boolean).join(" — ");
  body.append(title, meta);
  row.appendChild(body);
  if (track.source && state.scope === "global") {
    const source = document.createElement("span");
    source.className = "sls-result-source";
    source.textContent = track.source;
    row.appendChild(source);
  }
  if (track.isLocal) {
    const badge = document.createElement("span");
    badge.className = "sls-result-source";
    badge.textContent = "Local file";
    row.appendChild(badge);
  }
  if (!track.isLocal) {
    const where = document.createElement("button");
    where.type = "button";
    where.className = "sls-where";
    where.dataset.where = track.id;
    where.title = "Which of my playlists is this in?";
    where.setAttribute("aria-label", "Which of my playlists is this in?");
    where.textContent = "Where?";
    row.appendChild(where);
  }
  return row;
}

async function showTrackPlaylists(trackId, anchorRow) {
  const host = anchorRow || state.resultList;
  if (!host) return;
  clearWherePanels();
  const box = document.createElement("div");
  box.className = "sls-where-panel";
  box.textContent = "Looking through your playlists…";
  if (anchorRow) anchorRow.insertAdjacentElement("afterend", box);
  else state.resultList.appendChild(box);
  openPanel();
  const response = await send({ type: "FIND_PLAYLISTS_FOR_TRACK", trackId });
  if (!box.isConnected) return;
  if (!response.ok) { box.textContent = "Couldn't check that right now."; return; }
  if (!response.scanned) {
    box.textContent = "";
    const text = document.createElement("span");
    text.textContent = "This needs your whole library indexed. ";
    const build = document.createElement("button");
    build.type = "button";
    build.className = "sls-where-build";
    build.textContent = "Do it now";
    build.addEventListener("click", () => { box.textContent = "Starting…"; beginSweep(); });
    box.append(text, build);
    return;
  }
  box.textContent = "";
  if (!response.playlists.length) { box.textContent = `Not in any of the ${response.scanned} places indexed.`; return; }
  const title = document.createElement("span");
  title.className = "sls-where-title";
  title.textContent = `In ${response.playlists.length} of your playlists`;
  box.appendChild(title);
  const list = document.createElement("span");
  list.className = "sls-where-list";
  for (const entry of response.playlists) {
    const chip = document.createElement("span");
    chip.className = "sls-where-chip";
    chip.textContent = `${entry.label} · #${entry.position}`;
    list.appendChild(chip);
  }
  box.appendChild(list);
}

function clearWherePanels() {
  for (const node of document.querySelectorAll(".sls-where-panel")) node.remove();
}

function chipText(chips) { return chips?.length ? chips.join(" · ") : ""; }
function formatCount(value) { return Number(value || 0).toLocaleString(); }
function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }

function resetSearch({ keepFocus }) {
  clearTimeout(state.searchTimer);
  clearTimeout(state.statusTimer);
  state.query = "";
  state.parsed = null;
  state.results = [];
  state.activeIndex = -1;
  state.searchSeq++;
  if (state.input) state.input.value = "";
  if (state.counter) state.counter.textContent = "";
  state.root?.classList.remove("has-value");
  Tracklist?.restore();
  clearRowHighlights();
  hideStatus();
  closePanel();
  setBusy(false);
  if (keepFocus) state.input?.focus();
}

async function setScope(scope) {
  if (scope === state.scope) return;
  state.scope = scope;
  for (const button of state.panel.querySelectorAll(".sls-scope")) {
    const active = button.dataset.scope === scope;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-selected", String(active));
  }
  applyRouteChrome();
  Tracklist?.restore();
  if (scope === "global") {
    const status = await send({ type: "GET_CONTEXT_STATUS", context: { type: "global" } });
    if (status.ok && !status.status?.ready) {
      showAction(
        "Searching every playlist needs a one-time pass through your library. It opens each playlist, reads it, and puts you back where you were.",
        "Index my whole library", "sweep"
      );
      return;
    }
  }
  if (state.query.trim()) runSearch();
}

function onResultClick(event) {
  const where = event.target.closest?.("[data-where]");
  if (where) {
    event.preventDefault();
    event.stopPropagation();
    showTrackPlaylists(where.dataset.where, where.closest(".sls-result"));
    return;
  }
  const row = event.target.closest?.(".sls-result");
  if (!row) return;
  event.preventDefault();
  event.stopPropagation();
  activate(state.results[Number(row.dataset.index)]);
}

function onResultHover(event) {
  const row = event.target.closest?.(".sls-result");
  if (!row) return;
  const index = Number(row.dataset.index);
  if (index === state.activeIndex) return;
  setActiveResult(index, { scroll: false });
}

async function activateFromList(track) {
  Tracklist?.restore();
  await nextFrame();
  await nextFrame();
  await activate(track);
}

async function activate(track) {
  if (!track) return;
  closePanel();
  const row = await locateRow(track);
  if (!row) {
    /* Both the position-based homing and the full fallback scan came up
     * empty, so this isn't a stale-position problem any more (that's what
     * the fallback exists to absorb) — the track most likely isn't in the
     * list any more at all. Force a re-read so the index catches up. */
    state.lastHarvestKey = "";
    showTransientStatus("Couldn't find that track in the list — it may have been removed since this was indexed. Re-reading the list now.");
    harvestCurrentPage({ force: true });
    return;
  }
  row.scrollIntoView({ behavior: "smooth", block: "center" });
  await nextFrame();
  for (const type of ["pointerover", "pointerenter", "mouseover", "mouseenter"]) {
    row.dispatchEvent(new MouseEvent(type, { bubbles: type.endsWith("over"), cancelable: true, view: window }));
  }
  await wait(120);
  const playButton =
    row.querySelector('[data-testid="play-button"]') ||
    row.querySelector('button[aria-label^="Play" i]') ||
    row.querySelector('button[title^="Play" i]');
  if (playButton) { playButton.click(); flashRow(row); return; }
  row.dispatchEvent(new MouseEvent("dblclick", { bubbles: true, cancelable: true, view: window }));
  flashRow(row);
}

/*
 * Finding a row in a virtualised list.
 *
 * The position-homing pass below trusts `track.index`, the position the
 * harvester stored. That trust is exactly the thing that can be wrong —
 * see the note above warmIndex(). If the list has shifted since the index
 * was built, homing in on the stored position converges precisely on the
 * WRONG row: the self-correction logic anchors on whatever real row it
 * lands near and re-aims at the same fixed `desired` index every time, so
 * it can iterate ROW_SCAN_ATTEMPTS times and still never visit the row
 * that actually holds this track now. That's the specific shape of the
 * "couldn't reach that row" failures on older tracks: the further back a
 * track sits, the more chances there've been for something above it to
 * change, so the position drift — and this failure — gets more likely the
 * older the track is.
 *
 * So a position-homing miss isn't treated as final any more. It falls
 * back to a full, ID-anchored scan from the top — slower, but it finds
 * the track wherever it actually is now, and it also means the stale
 * position error message below should get rare rather than routine.
 */
async function locateRow(track) {
  const direct = matchRow(visibleRows(), track.id);
  if (direct) return direct;
  if (track.index == null) return locateByFullScan(track);
  const grid = Harvest.findGrid();
  const scroller = grid ? Harvest.findScroller(grid) : null;
  if (!scroller) return null;
  const positional = await locateByPosition(track, scroller);
  if (positional) return positional;
  return locateByFullScan(track);
}

async function locateByPosition(track, scroller) {
  const desired = track.index + 2;
  let rowHeight = visibleRows()[0]?.getBoundingClientRect().height || 56;
  let target = Math.max(0, (desired - 2) * rowHeight - scroller.clientHeight / 2);
  for (let attempt = 0; attempt < ROW_SCAN_ATTEMPTS; attempt++) {
    scroller.scrollTop = target;
    await wait(140);
    const rowsNow = visibleRows();
    const found = matchRow(rowsNow, track.id);
    if (found) return found;
    if (!rowsNow.length) { target += rowHeight; continue; }
    let anchor = null;
    let anchorIndex = 0;
    for (const row of rowsNow) {
      const index = Number(row.getAttribute("aria-rowindex"));
      if (!Number.isFinite(index)) continue;
      if (!anchor || index < anchorIndex) { anchor = row; anchorIndex = index; }
    }
    if (!anchor) { target += rowHeight; continue; }
    const height = anchor.getBoundingClientRect().height;
    if (height > 20) rowHeight = height;
    const scrollerTop = scroller.getBoundingClientRect().top;
    const anchorTop = anchor.getBoundingClientRect().top - scrollerTop + scroller.scrollTop;
    target = Math.max(0, anchorTop + (desired - anchorIndex) * rowHeight - scroller.clientHeight / 2);
  }
  return matchRow(visibleRows(), track.id);
}

/*
 * Last resort: scroll from the top and look at every window that renders,
 * the same way the harvester itself would, stopping the moment the track's
 * id shows up. Bounded by both a hard step count and a stagnation check so
 * a track that's genuinely gone (unliked since the index was built) fails
 * fast rather than scrolling the whole list forever.
 */
const FULL_SCAN_MAX_STEPS = 400;
const FULL_SCAN_STAGNANT_LIMIT = 10;

async function locateByFullScan(track) {
  const grid = Harvest.findGrid();
  const scroller = grid ? Harvest.findScroller(grid) : null;
  if (!scroller) return null;
  const origin = scroller.scrollTop;
  scroller.scrollTop = 0;
  await wait(180);
  let found = matchRow(visibleRows(), track.id);
  let stagnant = 0;
  let lastWindow = rowWindowKey();
  for (let step = 0; step < FULL_SCAN_MAX_STEPS && !found; step++) {
    const atEnd = scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4;
    if (atEnd) break;
    scroller.scrollTop += Math.max(240, scroller.clientHeight * 0.8);
    await wait(160);
    found = matchRow(visibleRows(), track.id);
    if (found) break;
    const windowKey = rowWindowKey();
    if (windowKey === lastWindow) {
      stagnant++;
      if (stagnant >= FULL_SCAN_STAGNANT_LIMIT) break;
    } else {
      stagnant = 0;
      lastWindow = windowKey;
    }
  }
  if (!found) scroller.scrollTop = origin;
  return found || null;
}

function rowWindowKey() {
  const rows = visibleRows();
  if (!rows.length) return "empty";
  const first = rows[0].getAttribute("aria-rowindex");
  const last = rows[rows.length - 1].getAttribute("aria-rowindex");
  return `${first}:${last}:${rows.length}`;
}

function matchRow(rows, trackId) {
  const needle = `/track/${trackId}`;
  return rows.find((row) => {
    const link = row.querySelector('a[href*="/track/"]');
    return link?.getAttribute("href")?.includes(needle);
  }) || null;
}

function flashRow(row) {
  row.classList.add("sls-row-flash");
  setTimeout(() => row.classList.remove("sls-row-flash"), 1400);
}

function applyRowHighlights() {
  if (Tracklist?.isActive()) return;
  if (state.settings && state.settings.highlightRows === false) return;
  const parsed = state.parsed;
  const rows = visibleRows();
  if (!parsed || parsed.isEmpty) { for (const row of rows) row.classList.remove("sls-row-match"); return; }
  const needles = [...parsed.terms, ...parsed.phrases];
  if (!needles.length) { for (const row of rows) row.classList.remove("sls-row-match"); return; }
  for (const row of rows) {
    const haystack = Text.normalize(rowSearchText(row));
    row.classList.toggle("sls-row-match", needles.every((n) => haystack.includes(n)));
  }
}

function rowSearchText(row) {
  const cells = row.querySelectorAll('[role="gridcell"]');
  if (!cells.length) return row.textContent || "";
  let text = "";
  for (let i = 0; i < Math.min(cells.length, 2); i++) text += ` ${cells[i].textContent || ""}`;
  return text;
}

function clearRowHighlights() {
  for (const row of visibleRows()) row.classList.remove("sls-row-match", "sls-row-flash");
}

function visibleRows() {
  return Array.from(document.querySelectorAll(ROW_SELECTOR)).filter((row) => row.textContent?.trim());
}

function onInputFocus() {
  renderSavedFilters();
  if (state.query.trim() || state.savedFilters.length) openPanel();
}

function openPanel() {
  if (!state.panel || state.panelOpen) { schedulePanelPosition(); return; }
  state.panel.hidden = false;
  state.panelOpen = true;
  state.input?.setAttribute("aria-expanded", "true");
  schedulePanelPosition();
}

function closePanel() {
  if (!state.panel) return;
  state.panel.hidden = true;
  state.panelOpen = false;
  state.activeIndex = -1;
  state.input?.setAttribute("aria-expanded", "false");
  state.input?.removeAttribute("aria-activedescendant");
}

function setBusy(value) { state.root?.classList.toggle("is-busy", Boolean(value)); }

function showStatus(message) {
  if (!state.statusBox) return;
  state.statusBox.hidden = false;
  state.statusBox.textContent = message;
  state.actionButton.hidden = true;
  openPanel();
}

function hideStatus() {
  if (!state.statusBox) return;
  state.statusBox.hidden = true;
  state.statusBox.textContent = "";
  state.actionButton.hidden = true;
}

function showAction(message, label, action) {
  if (!state.statusBox) return;
  state.statusBox.hidden = false;
  state.statusBox.textContent = message;
  state.actionButton.hidden = false;
  state.actionButton.textContent = label;
  state.actionButton.dataset.action = action;
  state.resultList.textContent = "";
  setFooter("");
  setBusy(false);
  openPanel();
}

function showTransientStatus(message) {
  clearTimeout(state.statusTimer);
  showStatus(message);
  state.statusTimer = setTimeout(() => {
    if (!state.query.trim()) { closePanel(); return; }
    hideStatus();
    if (state.results.length) runSearch({ silent: true });
  }, 3200);
}

function setFooterSuffix(text) {
  if (!state.footer || !text) return;
  const base = (state.footer.textContent || "").split(" · reading ")[0];
  setFooter(`${base} · ${text}`);
}

function setFooter(text) {
  if (!state.footer) return;
  state.footer.textContent = text || "";
  state.footer.hidden = !text;
}

function renderProgress(progress) {
  if (!state.progressBar) return;
  if (!progress || progress.complete) { state.progressBar.hidden = true; return; }
  const total = Number(progress.total || 0);
  const done = Number(progress.indexed || 0);
  const ratio = total ? Math.min(1, done / total) : 0;
  state.progressBar.hidden = false;
  state.progressBar.firstElementChild.style.width = `${Math.round(ratio * 100)}%`;
}

function schedulePanelPosition() {
  if (!state.panelOpen || !state.panel || !state.input) return;
  cancelAnimationFrame(state.positionFrame);
  state.positionFrame = requestAnimationFrame(positionPanel);
}

function positionPanel() {
  if (!state.panelOpen || state.panel.hidden) return;
  const rect = state.shell?.getBoundingClientRect();
  if (!rect) return;
  const gutter = 8;
  const width = Math.min(460, Math.max(320, rect.width + 150), window.innerWidth - 24);
  let left = rect.left;
  if (left + width > window.innerWidth - 12) left = Math.max(12, window.innerWidth - 12 - width);
  if (left < 12) left = 12;
  const below = window.innerHeight - rect.bottom - gutter - 12;
  const above = rect.top - gutter - 12;
  const flip = below < 220 && above > below;
  const maxHeight = Math.max(160, Math.min(720, flip ? above : below));
  state.panel.style.left = `${Math.round(left)}px`;
  state.panel.style.width = `${Math.round(width)}px`;
  state.panel.style.maxHeight = `${Math.round(maxHeight)}px`;
  if (flip) {
    state.panel.style.top = "auto";
    state.panel.style.bottom = `${Math.round(window.innerHeight - rect.top + gutter)}px`;
  } else {
    state.panel.style.bottom = "auto";
    state.panel.style.top = `${Math.round(rect.bottom + gutter)}px`;
  }
}

function onInputKeydown(event) {
  if (event.key === "Escape") {
    if (state.panelOpen) closePanel(); else resetSearch({ keepFocus: true });
    return;
  }
  if (!state.results.length) return;
  const visible = state.results.length;
  if (event.key === "ArrowDown" || event.key === "ArrowUp") {
    event.preventDefault();
    const delta = event.key === "ArrowDown" ? 1 : -1;
    const next = state.activeIndex + delta;
    const wrapped = next < 0 ? visible - 1 : next % visible;
    setActiveResult(wrapped, { scroll: true });
    return;
  }
  if (event.key === "Home") { event.preventDefault(); setActiveResult(0, { scroll: true }); return; }
  if (event.key === "End") { event.preventDefault(); setActiveResult(visible - 1, { scroll: true }); return; }
  if (event.key === "Enter") {
    event.preventDefault();
    activate(state.results[state.activeIndex >= 0 ? state.activeIndex : 0]);
  }
}

function setActiveResult(index, { scroll }) {
  state.activeIndex = index;
  const rows = state.resultList.querySelectorAll(".sls-result");
  rows.forEach((row, i) => {
    const active = i === index;
    row.classList.toggle("is-active", active);
    row.setAttribute("aria-selected", String(active));
    if (active) {
      state.input.setAttribute("aria-activedescendant", row.id);
      if (scroll) row.scrollIntoView({ block: "nearest" });
    }
  });
}

function onGlobalKeydown(event) {
  const target = event.target;
  const typing =
    target instanceof HTMLInputElement ||
    target instanceof HTMLTextAreaElement ||
    target instanceof HTMLSelectElement ||
    target?.isContentEditable ||
    target?.closest?.('[role="textbox"], [role="searchbox"], [contenteditable]');
  if (typing) return;
  if (event.metaKey || event.ctrlKey || event.altKey) return;
  if (event.key === "/" && state.input?.isConnected) { event.preventDefault(); focusSearch(); }
}

function focusSearch() {
  if (!state.input?.isConnected) {
    scheduleMount(0);
    setTimeout(() => state.input?.focus(), 160);
    return;
  }
  state.input.focus();
  state.input.select();
}

function onDocumentPointerDown(event) {
  if (!state.panelOpen) return;
  const target = event.target;
  if (!(target instanceof Element)) return;
  if (target.closest(".sls-root") || state.panel?.contains(target)) return;
  closePanel();
}

async function onActionClick() {
  const action = state.actionButton.dataset.action;
  if (action === "settings") { await send({ type: "OPEN_OPTIONS" }); return; }
  if (action === "reload") { location.reload(); return; }
  if (action === "sweep") { hideStatus(); beginSweep(); return; }
  if (action === "retry") {
    hideStatus();
    state.lastHarvestKey = "";
    const result = await harvestCurrentPage({ force: true });
    if (!result.ok) { showError(result.error); return; }
    if (state.query.trim()) runSearch();
  }
}

function showError(code) {
  const error = String(code || "");
  if (error === "NO_TRACKLIST" || error === "NO_SCROLLER") {
    showAction("Couldn't find the track list on this page. If it's still loading, give it a second and try again.", "Try again", "retry");
    return;
  }
  if (error === "EMPTY_TRACKLIST") {
    showAction("The track list on this page looks empty. Scroll it once and try again.", "Try again", "retry");
    return;
  }
  if (error === "EXTENSION_RELOADED") {
    showAction("Extension was updated. Reload this page to keep searching.", "Reload page", "reload");
    return;
  }
  if (error === "NO_CONTEXT") { showStatus("Open Liked Songs or a playlist to search it."); return; }
  showAction(`Search failed (${error || "unknown"}).`, "Try again", "retry");
}

function observeDom() {
  const observer = new MutationObserver(() => {
    if (state.observerPending) return;
    state.observerPending = true;
    const elapsed = Date.now() - state.lastObserverRun;
    const wait = Math.max(0, OBSERVER_INTERVAL_MS - elapsed);
    state.observerTimer = setTimeout(() => {
      state.observerPending = false;
      state.lastObserverRun = Date.now();
      requestAnimationFrame(reconcile);
    }, wait);
  });
  observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
}

function reconcile() {
  if (state.harvesting) return;
  if (!currentRoute()) { if (state.root) teardown(); return; }
  if (!state.root?.isConnected) { scheduleMount(0); return; }
  if (state.route?.id === "playlist" && currentPlaylistId() !== state.playlistId) { scheduleMount(0); return; }
  attachToActionBar();
  Tracklist?.reconcile();
  if (state.query.trim()) { applyRowHighlights(); schedulePanelPosition(); }
}

function patchHistory() {
  for (const method of ["pushState", "replaceState"]) {
    const original = history[method];
    history[method] = function patched(...args) {
      const result = original.apply(this, args);
      scheduleMount(60);
      return result;
    };
  }
  window.addEventListener("popstate", () => scheduleMount(60));
}

function wait(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }
function nextFrame() { return new Promise((resolve) => requestAnimationFrame(() => resolve())); }
})();