# How this got here

Five versions, four architectures, one symptom. Kept because the dead ends are
the most useful thing in the repo.

## v0.5 — Client ID, pasted by the user

Every user registers a Spotify developer app and pastes the Client ID. Works.
Requires Premium, requires a developer account, and loses almost everyone
before first use. Under Spotify's February 2026 rules a Development Mode app is
also capped at five authorised users, which rules out distribution entirely.

## v1.0–v1.2 — borrow the web player's session

Drop the Client ID; read the token the player is already using. Setup drops to
zero. Three rounds of bugs were found and fixed along the way — all real, none
of them the actual problem:

- v1.1: action-bar selectors had gone stale, so the search field rendered over
  Spotify's own controls. Fixed by deriving the bar from the play button.
- v1.2: index builds were awaited across a `chrome.runtime.onMessage`
  boundary. An evicted MV3 worker never sends its response and the promise
  never settles — a spinner with nothing behind it. Fixed by moving build state
  into storage and polling it.

The symptom never changed: no songs, ever.

## v1.3 — the diagnosis

The event log settled it. Every request returned `429` on the first call of a
fresh build, with `Retry-After` bouncing randomly between 1 and 59 seconds.

Spotify's Web API rate limit is applied **per application — per Client ID —
regardless of how many users are behind it**. The web player's token carries
Spotify's own first-party Client ID, shared by every web player user on earth
plus every scraper. Spotify began refusing first-party credentials at
`api.spotify.com` around December 2025; the desktop app's Client ID went the
same way with identical unconditional 429s.

Not a bug. Not fixable from inside the extension.

v1.3 fixed the amplifiers — a 429 was being retried four times per request and
the failed build was being restarted every fifteen seconds, forever — and
offered two working sources: your own registered Client ID, or an import of
Spotify's official data export. Both work. Both require something of the user
that most users will not do.

### One thing deliberately not built

Forging `client-token` / `app-platform` headers, or routing requests through
the page so they carry the player's origin, to make extension traffic
indistinguishable from first-party traffic.

That is evading an anti-abuse control rather than fixing a bug. It also would
not work: the limit keys on the Client ID, not the origin, so a disguised
request is still the refused credential asking.

## v2.0 — stop asking

The library is already in the browser. The player fetched it and rendered it;
those rows are on screen. Read them.

No credential, no request, no quota, no Premium, no setup. The thing that
blocked every previous version is a property of requests, and there are none.

The cost is honest and small: `year:` is unavailable because Spotify does not
render a release year anywhere in the track list, and a playlist has to be
visited — by you or by the sweep — to be read. Everything else works, on any
account, immediately.

## v2.0.1 — the quiet failures

v2.0 works. What it had instead of a spinner with nothing behind it was the
opposite failure: answers that looked right. A review of the whole codebase
turned up nine of them, and the pattern is worth recording because it is not
the pattern of the four versions above.

- A mid-harvest flush renumbers its records from zero, so merging flushes by
  ordinal dropped one screenful onto another. The index ended up smaller than
  the library and nothing anywhere said so. Fixed by keying the merge on the
  harvested row position, and by bumping the schema so no index written before
  that distinction existed survives the update.
- The date-added column was located by trying `Date.parse` on cells until one
  answered. `Date.parse` answers for a great deal of album text, so tracks were
  filed under dates that never happened. Now the duration cell — the one shape
  that is unmistakable — is found first and the date is read from the cell
  before it.
- Added-at was stored as local midnight and serialised with `toISOString`,
  which moves it back a day east of Greenwich. It is a calendar date and is now
  handled as one throughout.
- Targeted scrolls assumed row 0 began at pixel 0, ignoring Spotify's page
  header. Every scroll-to-row landed a few hundred pixels short. The offset is
  now measured from a row on screen.
- `is:` with an unrecognised flag parsed to a query with no conditions at all,
  which matched the entire library — the one result a filter must never
  produce.
- A sweep entry that could never become the current page fell through to a full
  page load, which resumed the sweep, which navigated again. The tab reloaded
  every few seconds with a progress bar that never moved. Navigation attempts
  are now counted, in storage, and a third failure records the playlist and
  moves on.
- `harvest.js` and `tracklist.js` had each grown their own copy of the grid
  locator, and the copies had drifted to different selectors. On a page
  carrying both, the filter hid one grid while the harvester scrolled the
  other. One definition now, in the file that owns the DOM reading.
- A search that triggered a harvest re-ran itself on the result, including when
  the result was "already running" — a message loop bounded by nothing.
- `year:` returned zero results with no explanation, which is indistinguishable
  from a broken index. It now says it is unavailable, which was already true
  and merely unsaid.

Plus the things that were merely expensive: full-storage reads where a key list
would do, a per-playlist read where one batched read would do, a directory
rewrite on every flush, an unbounded cache in the worker, and both the popup
and the options page refreshing their statistics once per 500-track chunk while
the worker was busy writing them.

The tests grew teeth in the process. The fake DOM now gives rows a real
position under a page header, so scroll maths that ignores the header fails
the suite instead of passing it, and the partial-flush test drives the actual
service worker rather than a copy of its merge.

## The rule that came out of it

Every version until this one had a failure mode where a spinner turned with
nothing behind it, and each time it took a round of diagnosis to find out why.
So:

> Every loop has a deadline. Progress is a number that changes. If the number
> stops, the loop stops and the user is told the number.

That rule is enforced in `harvest.js`, `sweep.js` and `content.js`, and it is
the reason a failure in v2.0 is a sentence rather than a mystery.
