"use strict";

/*
 * Toolbar popup.
 *
 * Exists so index state is checkable without being on open.spotify.com, and so
 * the toolbar isn't Chrome's generic puzzle piece — which is also a Web Store
 * submission requirement.
 *
 * It reads storage and sends two messages. There is nothing here that can
 * fail in an interesting way any more.
 */

const ui = {
  state: document.getElementById("state"),
  liked: document.getElementById("liked"),
  playlists: document.getElementById("playlists"),
  progress: document.getElementById("progress"),
  bar: document.getElementById("bar"),
  note: document.getElementById("note"),
  open: document.getElementById("open"),
  build: document.getElementById("build"),
  settings: document.getElementById("settings")
};

const REFRESH_DEBOUNCE_MS = 700;

let refreshTimer = 0;

init();

async function init() {
  ui.settings.addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
    window.close();
  });

  ui.open.addEventListener("click", async () => {
    await send({ type: "OPEN_SPOTIFY" });
    window.close();
  });

  ui.build.addEventListener("click", async () => {
    ui.build.disabled = true;
    setNote("Opening Spotify…");

    const result = await send({ type: "START_SWEEP" });

    if (!result.ok) {
      ui.build.disabled = false;
      setNote(
        result.error === "TAB_NOT_READY"
          ? "Spotify is still loading. Try again in a moment."
          : "Open Spotify first.",
        true
      );
      return;
    }

    setNote("Running in your Spotify tab.");
    setTimeout(() => window.close(), 900);
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;

    /* Sweep progress is the live part of this panel, so it redraws at once.
     * Index writes arrive one per 500-track chunk and say nothing the counts
     * below don't already say, so they wait for the writes to stop. */
    if (changes.sweep) {
      refresh();
      return;
    }

    if (Object.keys(changes).some((key) => key.startsWith("idx."))) {
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(refresh, REFRESH_DEBOUNCE_MS);
    }
  });

  await refresh();
}

async function refresh() {
  const [state, stored] = await Promise.all([
    send({ type: "GET_STATE" }),
    chrome.storage.local.get("sweep")
  ]);

  const liked = state.liked || {};
  const global = state.global || {};
  const sweep = stored?.sweep;

  if (sweep?.active) {
    const ratio = sweep.queue?.length ? sweep.cursor / sweep.queue.length : 0;

    ui.progress.hidden = false;
    ui.bar.style.width = `${Math.round(ratio * 100)}%`;
    ui.build.disabled = true;

    setState("setup", "Indexing…");
    setNote(
      `${sweep.cursor + 1} of ${sweep.queue.length} — ${sweep.queue[sweep.cursor]?.label || ""}`
    );
  } else {
    ui.progress.hidden = true;
    ui.build.disabled = false;

    if (liked.ready || global.covered) {
      setState("connected", "Ready");
      setNote("Press / on Spotify to search.");
    } else {
      setState("setup", "Nothing read yet");
      setNote("Open Liked Songs and it reads itself.");
    }
  }

  ui.liked.textContent = liked.ready ? Number(liked.indexed).toLocaleString() : "—";

  ui.playlists.textContent = state.playlistCount
    ? `${global.covered || 0}/${state.playlistCount}`
    : "—";
}

function setState(name, text) {
  ui.state.dataset.state = name;
  ui.state.textContent = text;
}

function setNote(text, warn = false) {
  ui.note.textContent = text;
  ui.note.classList.toggle("warn", Boolean(warn));
}

async function send(message) {
  try {
    return (await chrome.runtime.sendMessage(message)) || { ok: false };
  } catch {
    return { ok: false };
  }
}
