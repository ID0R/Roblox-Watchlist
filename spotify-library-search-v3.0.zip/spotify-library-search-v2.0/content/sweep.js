(() => {
"use strict";
const KEY = "sweep";
const STEP_TIMEOUT_MS = 180_000;
const NAV_TIMEOUT_MS = 12_000;
const MAX_RETRIES_PER_CONTEXT = 1;
const Harvest = window.SLSHarvest;

let running = false;
let cancelled = false;

async function read() {
  const stored = await chrome.storage.local.get(KEY);
  return stored[KEY] || null;
}
async function write(state) {
  await chrome.storage.local.set({ [KEY]: state });
  return state;
}
async function clear() {
  await chrome.storage.local.remove(KEY);
}
async function status() {
  const state = await read();
  if (!state?.active) return null;
  return {
    active: true, done: state.cursor, total: state.queue.length,
    label: state.queue[state.cursor]?.label || "", tracks: state.tracks || 0, failures: state.failures || []
  };
}

async function start({ onProgress } = {}) {
  const existing = await read();
  if (existing?.active) return existing;
  onProgress?.({ phase: "discovering", done: 0, total: 0, label: "Finding your playlists…" });
  const playlists = await Harvest.harvestPlaylistDirectory({});
  const queue = [
    { type: "liked", id: null, label: "Liked Songs", path: "/collection/tracks" },
    ...playlists.map((playlist) => ({ type: "playlist", id: playlist.id, label: playlist.name, path: `/playlist/${playlist.id}` }))
  ];
  const state = await write({
    active: true, queue, cursor: 0, tracks: 0, failures: [], retries: {},
    returnTo: location.pathname + location.search, startedAt: Date.now()
  });
  await send({ type: "SET_PLAYLIST_DIRECTORY", playlists: playlists.map((playlist) => ({ ...playlist, total: 0 })) });
  return state;
}

async function cancel() {
  cancelled = true;
  const state = await read();
  if (state) await write({ ...state, active: false, cancelledAt: Date.now() });
}

async function resume({ onProgress, onDone } = {}) {
  if (running) return;
  const state = await read();
  if (!state?.active) return;
  running = true;
  cancelled = false;
  try {
    await run(state, { onProgress, onDone });
  } finally {
    running = false;
  }
}

function retryKeyOf(target) {
  return `${target.type}:${target.id || ""}`;
}

async function run(initial, { onProgress, onDone }) {
  let state = initial;
  while (state?.active && state.cursor < state.queue.length) {
    if (cancelled) break;
    const target = state.queue[state.cursor];
    /* Surfaced to the overlay so a bounded retry reads as "attempt 2 of 2",
     * not as the sweep silently going in circles on the same list. */
    const attempt = (state.retries?.[retryKeyOf(target)] || 0) + 1;
    onProgress?.({
      phase: "indexing", done: state.cursor, total: state.queue.length, label: target.label,
      tracks: state.tracks, collected: 0, attempt
    });
    const page = Harvest.describePage();
    const onTarget = page.type === target.type && (target.type !== "playlist" || page.id === target.id);
    if (!onTarget) {
      const navigated = await navigate(target.path, target);
      if (!navigated) return;
    }
    let outcome = { indexed: 0, complete: false, total: null };
    try {
      outcome = await harvestCurrent(target, (progress) => {
        onProgress?.({
          phase: "indexing", done: state.cursor, total: state.queue.length, label: target.label,
          tracks: state.tracks, collected: progress.collected || 0, attempt
        });
      });
    } catch (error) {
      outcome = { indexed: 0, complete: false, total: null };
      state.failures = [...(state.failures || []), { label: target.label, error: String(error?.message || error) }].slice(0, 40);
    }
    if (!outcome.complete && !cancelled) {
      const key = retryKeyOf(target);
      const retries = { ...(state.retries || {}) };
      if ((retries[key] || 0) < MAX_RETRIES_PER_CONTEXT) {
        retries[key] = (retries[key] || 0) + 1;
        state = await write({ ...state, retries, cursor: state.cursor + 1, queue: [...state.queue, target] });
        continue;
      }
      state.failures = [
        ...(state.failures || []),
        { label: target.label, error: `could not account for every row (best read ${outcome.total ?? "?"} rows) after retry` }
      ].slice(0, 40);
    }
    state = await write({ ...state, cursor: state.cursor + 1, tracks: (state.tracks || 0) + outcome.indexed });
  }
  const finished = await read();
  if (finished) await write({ ...finished, active: false, finishedAt: Date.now() });
  onDone?.({
    tracks: finished?.tracks || 0, total: finished?.queue?.length || 0, failures: finished?.failures || [], cancelled
  });
  const returnTo = finished?.returnTo;
  if (returnTo && location.pathname !== returnTo.split("?")[0] && !cancelled) {
    await navigate(returnTo, null);
  }
  await clear();
}

async function harvestCurrent(target, onProgress) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), STEP_TIMEOUT_MS);
  try {
    const result = await Harvest.harvest({ onProgress, signal: controller.signal });
    if (!result.records.length) return { indexed: 0, complete: false, total: result.total };
    if (!result.complete) return { indexed: 0, complete: false, total: result.total };
    await send({ type: "INGEST", context: { type: target.type, id: target.id, label: target.label }, records: result.records, total: result.total, complete: true });
    return { indexed: result.records.length, complete: true, total: result.total };
  } finally {
    clearTimeout(timer);
  }
}

async function navigate(path, target) {
  const anchor = document.querySelector(`a[href="${cssEscape(path)}"]`);
  if (anchor) {
    anchor.click();
    if (await waitForPage(path, target)) return true;
  }
  try {
    history.pushState({}, "", path);
    window.dispatchEvent(new PopStateEvent("popstate", { state: {} }));
    if (await waitForPage(path, target)) return true;
  } catch {}
  location.assign(path);
  return false;
}

function cssEscape(value) {
  return String(value).replace(/["\\]/g, "\\$&");
}

function waitForPage(path, target) {
  const wanted = path.split("?")[0];
  const deadline = Date.now() + NAV_TIMEOUT_MS;
  return new Promise((resolve) => {
    const check = () => {
      if (cancelled) return resolve(false);
      if (location.pathname === wanted) {
        const page = Harvest.describePage();
        const matches = !target || (page.type === target.type && (target.type !== "playlist" || page.id === target.id));
        if (matches && page.hasGrid && Harvest.findGrid()?.querySelector('[role="row"]')) {
          setTimeout(() => resolve(true), 260);
          return;
        }
      }
      if (Date.now() > deadline) return resolve(false);
      setTimeout(check, 160);
    };
    setTimeout(check, 120);
  });
}

async function send(message) {
  try {
    return (await chrome.runtime.sendMessage(message)) || { ok: false };
  } catch (error) {
    return { ok: false, error: String(error?.message || error) };
  }
}

window.SLSSweep = { start, cancel, resume, status, read, clear };
})();