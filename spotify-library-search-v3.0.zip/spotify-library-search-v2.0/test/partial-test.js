const store = {};
global.chrome = { storage: { local: {
  get: async (k) => { if (k === null) return {...store};
    const out = {}; for (const key of [].concat(k)) if (key in store) out[key] = store[key]; return out; },
  set: async (o) => Object.assign(store, o),
  remove: async (k) => { for (const key of [].concat(k)) delete store[key]; }
}}};
const B = "..";
require(`${B}/shared/text.js`); require(`${B}/shared/query.js`); require(`${B}/background/store.js`);
const Store = globalThis.SLSStore;
const ctx = { type: "liked", label: "Liked Songs" };
const row = (i) => ({ position: i, id: `t${i}`, name: `Track ${i}`, artists: ["A"], album: "Al", image: "", duration: 1000, added: null, isLocal: false });

(async () => {
  console.log("partial flushes during a live harvest:\n");
  for (const n of [40, 90, 180, 400]) {
    await Store.write(ctx, Array.from({length:n}, (_,i)=>row(i)), { partial: true });
    const s = await Store.getStatus(ctx);
    console.log(`  flush ${String(n).padStart(3)} -> indexed ${String(s.indexed).padStart(3)}  complete=${s.complete}  partial=${s.partial}`);
  }
  console.log("  a stale, smaller flush arrives late:");
  await Store.write(ctx, Array.from({length:90}, (_,i)=>row(i)), { partial: true });
  let s = await Store.getStatus(ctx);
  console.log(`  flush  90 -> indexed ${s.indexed}  (held, not shrunk)`);

  await Store.write(ctx, Array.from({length:935}, (_,i)=>row(i)), { total: 935 });
  s = await Store.getStatus(ctx);
  console.log(`\n  final    -> indexed ${s.indexed}  complete=${s.complete}  partial=${s.partial}`);

  await sparsePositions();
})();

/*
 * Flushes that are not a prefix of the list.
 *
 * The gap-filling pass revisits rows the virtualiser skipped, so a flush can
 * carry rows 500-539 while only rows 0-39 are stored. Each write renumbers its
 * records from zero, so the merge has to key on the harvested row position and
 * not on that ordinal — otherwise the third flush below lands on top of the
 * second and silently destroys 40 tracks.
 *
 * This drives the real service worker rather than a copy of its merge, because
 * the merge is the thing under test.
 */
async function sparsePositions() {
  console.log("\nsparse flushes through the real worker:\n");

  let listener = null;

  const noop = () => {};
  const listenable = { addListener: noop };

  global.self = global;

  global.importScripts = (...paths) => {
    const path = require("path");
    for (const file of paths) require(path.resolve(__dirname, "../background", file));
  };

  global.chrome = {
    ...global.chrome,
    runtime: {
      onMessage: { addListener: (fn) => { listener = fn; } },
      onInstalled: listenable,
      onStartup: listenable,
      lastError: null
    },
    commands: { onCommand: listenable },
    contextMenus: { onClicked: listenable, removeAll: (fn) => fn?.(), create: noop },
    tabs: { query: async () => [], sendMessage: async () => {} },
    windows: {}
  };

  require(`${B}/background/background.js`);

  const send = (message) =>
    new Promise((resolve) => listener(message, {}, resolve));

  const context = { type: "playlist", id: "sparse", label: "Sparse" };
  const flush = (from, count) =>
    send({
      type: "INGEST_PARTIAL",
      context,
      records: Array.from({ length: count }, (_, i) => row(from + i))
    });

  const a = await flush(0, 40);
  console.log(`  rows   0- 39 -> indexed ${a.indexed}`);

  const b = await flush(500, 40);
  console.log(`  rows 500-539 -> indexed ${b.indexed}`);

  const c = await flush(40, 40);
  console.log(`  rows  40- 79 -> indexed ${c.indexed}`);

  const stored = await Store.load(context);
  const byPosition = new Map(stored.songs.map((song) => [song.p, song]));

  const survived = [0, 39, 40, 79, 500, 539].filter(
    (position) => byPosition.get(position)?.n === `Track ${position}`
  );

  console.log(
    `\n  120 expected, ${stored.songs.length} stored; ` +
    `sampled rows intact: ${survived.length}/6 ` +
    `${stored.songs.length === 120 && survived.length === 6 ? "ok" : "BAD"}`
  );
}
