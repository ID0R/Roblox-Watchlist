# Tests

No network in the build environment, so no jsdom. `fake-dom.js` is a hand-built
stand-in for Spotify's virtualised tracklist — faithful in the ways that matter
to the harvester, and, more usefully, able to misbehave the way real renderers
do: lagging behind a fast scroll, dropping a render entirely.

```
node test/harvest-test.js    # the harvester against eleven renderer behaviours
node test/e2e-test.js        # page -> index -> search results
node test/partial-test.js    # mid-harvest flush ordering and merging
```

These caught three real bugs during the v2.0 rewrite: short playlists throwing
`NO_SCROLLER`, a condition referencing a field that never existed
(`existing.partialOf`), and a partial flush downgrading a completed index.

## Keeping them honest

Two cases were added in v2.0.1 because the harness had been agreeing with the
code rather than checking it.

Rows used to report `top: 0` regardless of where they were, which meant any
scroll arithmetic at all looked correct. `FakeGrid` now takes a `header`
height, rows report their real position, and the `header + drops` case makes
the gap-filling pass scroll to a row that is off screen unless the header
offset is measured. Run that case against a harvester with the offset removed
and it recovers 836 of 935 tracks.

The partial-flush test now loads `background/background.js` itself, with the
handful of `chrome` APIs it touches shimmed, and sends it real
`INGEST_PARTIAL` messages carrying sparse row positions. Testing a copy of the
merge would have passed while the shipped merge dropped 40 tracks, which is
what it did.

A useful habit when adding a case: break the fix on purpose and confirm the
new test fails. A test that cannot fail is documentation with a runtime cost.
