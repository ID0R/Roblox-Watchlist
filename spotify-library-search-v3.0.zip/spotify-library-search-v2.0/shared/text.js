"use strict";

/*
 * Normalisation, tokenisation and a bounded edit distance.
 *
 * Loaded as a classic script in BOTH the service worker (via importScripts)
 * and the content script (via content_scripts.js). One copy on purpose: two
 * copies is how the row highlighter and the index end up disagreeing about
 * what "matches", which is the kind of bug that only shows up on the tracks
 * with accents in them.
 *
 * Everything here runs at index time, once per track, so the search path never
 * pays for it.
 */

(function attachText(global) {
  /* Cheap memo for the content script, which normalises the same visible row
   * text on every keystroke. Bounded so a long session can't grow it forever. */
  const cache = new Map();
  const CACHE_LIMIT = 4000;

  /*
   * Case folding is total and unconditional. "travis" matches "Travis Scott",
   * "TRAVIS", "Trávis" and "travis'". If a search ever appears case sensitive,
   * the bug is that this function was not reached — not that it has an
   * exception in it.
   */
  function normalize(value) {
    if (!value) return "";

    const input = String(value);

    const hit = cache.get(input);
    if (hit !== undefined) return hit;

    let out = input.toLowerCase();

    /* Accent folding: decompose, then drop the combining marks. */
    out = out.normalize("NFD").replace(/[\u0300-\u036f]/g, "");

    /* Apostrophes vanish rather than becoming spaces, so "dont" matches
     * "don't" and "rockin" matches "rockin'". Both straight and curly. */
    out = out.replace(/['\u2018\u2019\u02bc\u0060\u00b4]/g, "");

    /* Everything else that isn't a letter, digit or space becomes a space:
     * brackets, dashes, dots, the "feat." punctuation, CJK stays intact. */
    out = out.replace(/[^\p{L}\p{N}]+/gu, " ");

    out = out.trim().replace(/\s+/g, " ");

    if (cache.size >= CACHE_LIMIT) cache.clear();
    cache.set(input, out);

    return out;
  }

  function tokenize(value) {
    const normalized = normalize(value);
    return normalized ? normalized.split(" ") : [];
  }

  /*
   * Levenshtein with an early exit.
   *
   * The budget matters more than the algorithm: a full distance computation
   * over every track in a 20,000-track library on every keystroke is the
   * difference between 120 ms and several seconds. Bailing as soon as the best
   * possible remaining score exceeds the budget keeps the fuzzy pass usable.
   */
  function withinDistance(a, b, budget) {
    if (a === b) return true;
    if (budget <= 0) return false;

    const lenA = a.length;
    const lenB = b.length;

    if (Math.abs(lenA - lenB) > budget) return false;
    if (!lenA) return lenB <= budget;
    if (!lenB) return lenA <= budget;

    let previous = new Array(lenB + 1);
    let current = new Array(lenB + 1);

    for (let j = 0; j <= lenB; j++) previous[j] = j;

    for (let i = 1; i <= lenA; i++) {
      current[0] = i;

      let best = current[0];
      const charA = a.charCodeAt(i - 1);

      for (let j = 1; j <= lenB; j++) {
        const cost = charA === b.charCodeAt(j - 1) ? 0 : 1;

        current[j] = Math.min(
          previous[j] + 1,
          current[j - 1] + 1,
          previous[j - 1] + cost
        );

        if (current[j] < best) best = current[j];
      }

      /* No cell in this row is within budget, and rows only ever grow. */
      if (best > budget) return false;

      const swap = previous;
      previous = current;
      current = swap;
    }

    return previous[lenB] <= budget;
  }

  /*
   * Typo budget scales with word length, so short queries stay exact. "love"
   * must not fuzzily match "live", "lose" and "dove" on every keystroke.
   */
  function typoBudget(length) {
    if (length <= 4) return 0;
    if (length <= 7) return 1;
    return 2;
  }

  global.SLSText = { normalize, tokenize, withinDistance, typoBudget };
})(typeof self !== "undefined" ? self : globalThis);
