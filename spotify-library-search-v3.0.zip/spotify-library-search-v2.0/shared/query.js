"use strict";

/*
 * Query parsing and scoring.
 *
 * Pure functions, no DOM and no chrome.* — which also makes this the easiest
 * file in the tree to test, and the one place worth testing first.
 *
 * Supported syntax:
 *   travis scott          all terms must match somewhere
 *   "exact phrase"        the phrase must appear contiguously
 *   -remix                exclude anything matching
 *   artist:daft           artist field only
 *   album:discovery       album field only
 *   in:chill              source playlist name (whole-library scope)
 *   year:2001             release year, year:1995-2005 for a range
 *   year:<2000 year:>2015 open-ended range
 *   added:>2024-06        added to the library after a date
 *   is:dupe               only tracks that appear more than once
 *
 * Scoring note that took a while to get right: per-term scores are AVERAGED,
 * not summed. Summing let a three-word query that merely contained each word
 * somewhere outrank an exact title match.
 */

(function attachQuery(global) {
  const Text = global.SLSText;

  const FIELD_KEYS = new Set(["artist", "album", "in", "year", "added", "is"]);

  /* Scores are relative to each other and nothing else. The gaps are wide so
   * a title hit can never be overtaken by an album hit on a longer query. */
  const SCORE = {
    titleExact: 100,
    titlePrefix: 70,
    titleWord: 55,
    titleContains: 40,
    artistExact: 50,
    artistPrefix: 38,
    artistContains: 28,
    albumPrefix: 20,
    albumContains: 14,
    fuzzy: 8
  };

  function emptyParse(raw) {
    return {
      raw: raw || "",
      isEmpty: true,
      terms: [],
      phrases: [],
      negatives: [],
      fields: { artist: [], album: [], in: [] },
      year: null,
      added: null,
      flags: new Set(),

      /* Operators that parsed cleanly but cannot be answered from the page.
       * Recorded rather than dropped, so the UI can say why a query that looks
       * reasonable returns nothing. */
      unsupported: new Set()
    };
  }

  /* ------------------------------- parsing ------------------------------- */

  function splitTokens(input) {
    const tokens = [];
    const pattern = /"([^"]*)"|(\S+)/g;

    let match;
    while ((match = pattern.exec(input)) !== null) {
      if (match[1] !== undefined) tokens.push({ quoted: true, value: match[1] });
      else tokens.push({ quoted: false, value: match[2] });
    }

    return tokens;
  }

  function parseYear(value) {
    const text = String(value || "").trim();

    let match = text.match(/^(\d{4})\s*-\s*(\d{4})$/);
    if (match) {
      return { min: Number(match[1]), max: Number(match[2]) };
    }

    match = text.match(/^([<>])=?\s*(\d{4})$/);
    if (match) {
      return match[1] === "<"
        ? { min: 0, max: Number(match[2]) }
        : { min: Number(match[2]), max: 9999 };
    }

    match = text.match(/^(\d{4})$/);
    if (match) {
      return { min: Number(match[1]), max: Number(match[1]) };
    }

    return null;
  }

  /*
   * added:>2024-06 / added:<2020 / added:2023
   *
   * A bare year or year-month is treated as the whole period, so added:2023
   * means "during 2023" rather than "on 1 January 2023", which is what people
   * actually mean when they type it.
   */
  function parseAdded(value) {
    const text = String(value || "").trim();

    const match = text.match(/^([<>])?=?\s*(\d{4})(?:-(\d{2}))?(?:-(\d{2}))?$/);
    if (!match) return null;

    const [, operator, year, month, day] = match;

    const start = Date.UTC(Number(year), month ? Number(month) - 1 : 0, day ? Number(day) : 1);

    let end;
    if (day) end = start + 86_400_000;
    else if (month) end = Date.UTC(Number(year), Number(month), 1);
    else end = Date.UTC(Number(year) + 1, 0, 1);

    if (operator === ">") return { after: end - 1 };
    if (operator === "<") return { before: start };

    return { after: start - 1, before: end };
  }

  function parse(raw) {
    const input = String(raw || "").trim();
    if (!input) return emptyParse(raw);

    const parsed = emptyParse(raw);
    parsed.isEmpty = false;

    for (const token of splitTokens(input)) {
      const { quoted, value } = token;

      if (quoted) {
        const phrase = Text.normalize(value);
        if (phrase) parsed.phrases.push(phrase);
        continue;
      }

      if (value.startsWith("-") && value.length > 1) {
        const negative = Text.normalize(value.slice(1));
        if (negative) parsed.negatives.push(negative);
        continue;
      }

      const colon = value.indexOf(":");

      if (colon > 0) {
        const key = value.slice(0, colon).toLowerCase();
        const argument = value.slice(colon + 1);

        if (FIELD_KEYS.has(key) && argument) {
          if (key === "year") {
            const year = parseYear(argument);
            if (year) {
              parsed.year = year;

              /* Release year is not rendered in Spotify's track list, so there
               * is nothing to read it from. The operator still parses and still
               * filters — it simply rejects everything — and is flagged here so
               * the UI can explain the empty result instead of looking broken. */
              parsed.unsupported.add("year");
              continue;
            }
          } else if (key === "added") {
            const added = parseAdded(argument);
            if (added) {
              parsed.added = added;
              continue;
            }
          } else if (key === "is") {
            const flag = argument.toLowerCase();

            if (flag === "dupe" || flag === "duplicate") {
              parsed.flags.add("dupe");
              continue;
            }

            if (flag === "local") {
              parsed.flags.add("local");
              continue;
            }

            /* An unrecognised flag falls through to be treated as an ordinary
             * search term. Swallowing it used to leave `is:whatever` with no
             * conditions at all, so it matched the entire library — the one
             * result a filter must never produce. */
          } else {
            const normalized = Text.normalize(argument);
            if (normalized) {
              parsed.fields[key].push(normalized);
              continue;
            }
          }
        }
      }

      const term = Text.normalize(value);
      if (term) parsed.terms.push(...term.split(" "));
    }

    const hasAnything =
      parsed.terms.length ||
      parsed.phrases.length ||
      parsed.negatives.length ||
      parsed.fields.artist.length ||
      parsed.fields.album.length ||
      parsed.fields.in.length ||
      parsed.year ||
      parsed.added ||
      parsed.flags.size;

    parsed.isEmpty = !hasAnything;
    return parsed;
  }

  /* ------------------------------ describing ------------------------------ */

  function describe(parsed) {
    if (!parsed || parsed.isEmpty) return [];

    const chips = [];

    for (const artist of parsed.fields.artist) chips.push(`artist: ${artist}`);
    for (const album of parsed.fields.album) chips.push(`album: ${album}`);
    for (const name of parsed.fields.in) chips.push(`in: ${name}`);

    if (parsed.year) {
      const range =
        parsed.year.min === parsed.year.max
          ? `year ${parsed.year.min}`
          : `year ${parsed.year.min || "any"}–${parsed.year.max === 9999 ? "now" : parsed.year.max}`;

      chips.push(parsed.unsupported?.has("year") ? `${range} (unavailable)` : range);
    }

    if (parsed.added) {
      if (parsed.added.after && parsed.added.before) chips.push("added in range");
      else if (parsed.added.after) chips.push("added after");
      else chips.push("added before");
    }

    if (parsed.flags.has("dupe")) chips.push("duplicates only");
    if (parsed.flags.has("local")) chips.push("local files only");

    for (const phrase of parsed.phrases) chips.push(`"${phrase}"`);
    for (const negative of parsed.negatives) chips.push(`without ${negative}`);

    return chips;
  }

  /* ------------------------------- scoring ------------------------------- */

  function wordBoundaryHit(haystack, needle) {
    if (haystack === needle) return SCORE.titleExact;
    if (haystack.startsWith(needle)) return SCORE.titlePrefix;
    if (haystack.includes(` ${needle}`)) return SCORE.titleWord;
    if (haystack.includes(needle)) return SCORE.titleContains;
    return 0;
  }

  function scoreTerm(song, term, allowFuzzy) {
    const title = song._t || "";
    const artists = song._a || "";
    const album = song._l || "";

    let best = wordBoundaryHit(title, term);

    if (artists === term) best = Math.max(best, SCORE.artistExact);
    else if (artists.startsWith(term) || artists.includes(` ${term}`)) {
      best = Math.max(best, SCORE.artistPrefix);
    } else if (artists.includes(term)) {
      best = Math.max(best, SCORE.artistContains);
    }

    if (album.startsWith(term) || album.includes(` ${term}`)) {
      best = Math.max(best, SCORE.albumPrefix);
    } else if (album.includes(term)) {
      best = Math.max(best, SCORE.albumContains);
    }

    if (best > 0 || !allowFuzzy) return best;

    const budget = Text.typoBudget(term.length);
    if (budget <= 0) return 0;

    const tokens = [...(song.ts || []), ...(song.as || [])];

    for (const token of tokens) {
      if (Text.withinDistance(token, term, budget)) return SCORE.fuzzy;
    }

    return 0;
  }

  function matchesAnyField(haystack, needles) {
    return needles.every((needle) => haystack.includes(needle));
  }

  function scoreSong(song, parsed, options = {}) {
    if (!parsed || parsed.isEmpty) return 0;

    const { allowFuzzy = false, playlistName = "", dupeIds = null } = options;

    /* Hard filters first — every one of these is a cheap reject, and running
     * them before the string work is most of why typing stays instant. */

    if (parsed.flags.has("dupe")) {
      if (!dupeIds || !dupeIds.has(song.id)) return 0;
    }

    if (parsed.flags.has("local") && !song.lo) return 0;

    if (parsed.year) {
      const year = Number(song.y || 0);
      if (!year) return 0;
      if (year < parsed.year.min || year > parsed.year.max) return 0;
    }

    if (parsed.added) {
      const added = song.ad ? Date.parse(song.ad) : NaN;
      if (Number.isNaN(added)) return 0;
      if (parsed.added.after && added <= parsed.added.after) return 0;
      if (parsed.added.before && added >= parsed.added.before) return 0;
    }

    if (parsed.fields.artist.length && !matchesAnyField(song._a || "", parsed.fields.artist)) {
      return 0;
    }

    if (parsed.fields.album.length && !matchesAnyField(song._l || "", parsed.fields.album)) {
      return 0;
    }

    if (parsed.fields.in.length && !matchesAnyField(playlistName || "", parsed.fields.in)) {
      return 0;
    }

    const haystack = `${song._t || ""} ${song._a || ""} ${song._l || ""}`;

    for (const negative of parsed.negatives) {
      if (haystack.includes(negative)) return 0;
    }

    for (const phrase of parsed.phrases) {
      if (!haystack.includes(phrase)) return 0;
    }

    /* A query that is nothing but filters — `year:2001`, `is:dupe` — has
     * already passed everything that can reject it, so it matches. */
    if (!parsed.terms.length) {
      return parsed.phrases.length ? SCORE.titleWord : SCORE.titleContains;
    }

    let total = 0;

    for (const term of parsed.terms) {
      const score = scoreTerm(song, term, allowFuzzy);
      if (score === 0) return 0;
      total += score;
    }

    /* Averaged, not summed. See the note at the top of the file. */
    const average = total / parsed.terms.length;

    /* Small nudge so that, all else equal, the track nearer the top of the
     * list wins — which is the one the user is most likely thinking of. */
    return average + Math.max(0, 1 - Number(song.i || 0) / 100_000);
  }

  global.SLSQuery = { parse, describe, scoreSong, SCORE };
})(typeof self !== "undefined" ? self : globalThis);
