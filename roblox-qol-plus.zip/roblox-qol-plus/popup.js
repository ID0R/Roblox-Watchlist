import {
  getWatchlist,
  addToWatchlist,
  removeFromWatchlist,
  updateAlertTypes,
  getSettings,
  updateSettings,
} from "./lib/storage.js";
import { resolveUserId, profileUrl, blockUser } from "./lib/roblox-api.js";
import { isPremiumUnlocked } from "./lib/premium.js";

const listEl = document.getElementById("watchlistItems");
const usernameInput = document.getElementById("usernameInput");
const addBtn = document.getElementById("addBtn");
const addError = document.getElementById("addError");
const monitoringToggle = document.getElementById("monitoringToggle");
const currentGameName = document.getElementById("currentGameName");
const manualPlaceId = document.getElementById("manualPlaceId");
const manualGameBtn = document.getElementById("manualGameBtn");
const clearGameBtn = document.getElementById("clearGameBtn");
const pollStatus = document.getElementById("pollStatus");
const darkThemeToggle = document.getElementById("darkThemeToggle");
const accentHue = document.getElementById("accentHue");
const hueLockTag = document.getElementById("hueLockTag");

function studDot(colorClass) {
  const span = document.createElement("span");
  span.className = `stud small ${colorClass}`;
  span.setAttribute("aria-hidden", "true");
  return span;
}

function formatPollStatus(status) {
  if (!status) return "";
  const when = new Date(status.at).toLocaleTimeString();
  return status.ok ? `Last check OK at ${when}` : `Last check FAILED at ${when}: ${status.message}`;
}

async function render() {
  const [watchlist, settings, premium] = await Promise.all([
    getWatchlist(),
    getSettings(),
    isPremiumUnlocked(),
  ]);

  monitoringToggle.checked = settings.monitoringEnabled;
  darkThemeToggle.checked = settings.darkThemeEnabled;
  accentHue.value = settings.accentHueDeg;
  accentHue.disabled = !premium;
  hueLockTag.style.display = premium ? "none" : "inline";

  currentGameName.innerHTML = "";
  if (settings.currentPlaceName) {
    const dotClass = settings.currentGameSource === "manual" ? "amber" : "green";
    const sourceTag = settings.currentGameSource === "manual" ? " (manual)" : "";
    currentGameName.append(
      studDot(dotClass),
      document.createTextNode(`${settings.currentPlaceName} (${settings.currentPlaceId})${sourceTag}`)
    );
  } else {
    currentGameName.append(
      studDot("gray"),
      document.createTextNode("Not detected — open a Roblox game page or set one manually")
    );
  }

  pollStatus.textContent = formatPollStatus(settings.lastPollStatus);
  pollStatus.classList.toggle("error", Boolean(settings.lastPollStatus && !settings.lastPollStatus.ok));

  listEl.innerHTML = "";

  if (!watchlist.length) {
    const empty = document.createElement("li");
    empty.className = "emptyState";
    empty.textContent = "No one on your watchlist yet.";
    listEl.append(empty);
  }

  for (const entry of watchlist) {
    listEl.append(renderEntry(entry, premium));
  }
}

function renderEntry(entry, premium) {
  const li = document.createElement("li");

  const topRow = document.createElement("div");
  topRow.className = "entryTopRow";

  const nameWrap = document.createElement("span");
  nameWrap.className = "entryName";
  const link = document.createElement("a");
  link.href = profileUrl(entry.userId);
  link.target = "_blank";
  link.textContent = entry.username;
  nameWrap.append(studDot("gray"), link);

  const actions = document.createElement("span");
  actions.className = "entryActions";

  const blockBtn = document.createElement("button");
  blockBtn.className = "btn";
  blockBtn.textContent = "Block/Report";
  blockBtn.title = "Opens their Roblox profile so you can block or report them";
  blockBtn.addEventListener("click", () => blockUser(entry.userId));

  const removeBtn = document.createElement("button");
  removeBtn.className = "btn btnGhost";
  removeBtn.textContent = "Remove";
  removeBtn.addEventListener("click", async () => {
    await removeFromWatchlist(entry.userId);
    render();
  });

  actions.append(blockBtn, removeBtn);
  topRow.append(nameWrap, actions);

  const alertRow = document.createElement("div");
  alertRow.className = "alertRow";
  const currentTypes = new Set(entry.alertTypes && entry.alertTypes.length ? entry.alertTypes : ["join"]);

  alertRow.append(
    alertCheckbox("join", "Join", currentTypes, entry, true),
    alertCheckbox("online", "Online", currentTypes, entry, premium),
    alertCheckbox("offline", "Offline", currentTypes, entry, premium)
  );
  if (!premium) {
    const tag = document.createElement("span");
    tag.className = "premiumTag";
    tag.textContent = "Premium";
    alertRow.append(tag);
  }

  li.append(topRow, alertRow);
  return li;
}

function alertCheckbox(type, label, currentTypes, entry, enabled) {
  const wrap = document.createElement("label");
  wrap.className = "alertCheckbox";

  const input = document.createElement("input");
  input.type = "checkbox";
  input.checked = currentTypes.has(type);
  input.disabled = !enabled;
  input.addEventListener("change", async () => {
    const next = new Set(currentTypes);
    if (input.checked) next.add(type);
    else next.delete(type);
    if (!next.size) next.add("join");
    await updateAlertTypes(entry.userId, [...next]);
    render();
  });

  wrap.append(input, document.createTextNode(label));
  return wrap;
}

addBtn.addEventListener("click", async () => {
  addError.textContent = "";
  const username = usernameInput.value.trim();
  if (!username) return;

  try {
    const resolved = await resolveUserId(username);
    await addToWatchlist({ userId: resolved.userId, username: resolved.username });
    usernameInput.value = "";
    render();
  } catch (err) {
    addError.textContent = err.message;
  }
});

monitoringToggle.addEventListener("change", async () => {
  await updateSettings({ monitoringEnabled: monitoringToggle.checked });
});

darkThemeToggle.addEventListener("change", async () => {
  await updateSettings({ darkThemeEnabled: darkThemeToggle.checked });
});

accentHue.addEventListener("change", async () => {
  await updateSettings({ accentHueDeg: Number(accentHue.value) });
});

manualGameBtn.addEventListener("click", async () => {
  const placeId = Number(manualPlaceId.value.trim());
  if (!placeId) return;
  await chrome.runtime.sendMessage({ type: "SET_CURRENT_GAME_MANUAL", placeId });
  manualPlaceId.value = "";
  render();
});

clearGameBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "CLEAR_CURRENT_GAME" });
  render();
});

render();
