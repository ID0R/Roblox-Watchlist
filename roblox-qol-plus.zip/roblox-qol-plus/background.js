import {
  getWatchlist,
  getSettings,
  updateSettings,
  isNotified,
  markNotified,
  clearNotified,
  getLastPresenceType,
  setLastPresenceType,
} from "./lib/storage.js";
import { getPresence, profileUrl } from "./lib/roblox-api.js";

async function recordError(source, err) {
  console.error(`[qol+] ${source}`, err);
  try {
    await updateSettings({
      lastError: { source, message: err && err.message ? err.message : String(err), at: Date.now() },
    });
  } catch (_) {
    // storage itself is down; nothing more we can do
  }
}

self.addEventListener("error", (event) => {
  recordError("uncaught", event.error || event.message);
});

self.addEventListener("unhandledrejection", (event) => {
  recordError("unhandledrejection", event.reason);
});

const ALARM_NAME = "poll-watchlist";
// How stale an auto-detected current game is allowed to get (in case the
// tab-close/navigate listeners below miss an edge case, e.g. browser crash).
const AUTO_GAME_MAX_AGE_MS = 20 * 60 * 1000;

chrome.runtime.onInstalled.addListener(async () => {
  const { pollIntervalMinutes } = await getSettings();
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: pollIntervalMinutes });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "CURRENT_GAME_DETECTED") {
    updateSettings({
      currentPlaceId: message.placeId,
      currentPlaceName: message.placeName,
      currentGameSource: "auto",
      currentGameTabId: sender.tab ? sender.tab.id : null,
      currentGameSetAt: Date.now(),
    }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === "SET_CURRENT_GAME_MANUAL") {
    updateSettings({
      currentPlaceId: message.placeId,
      currentPlaceName: message.placeName || `Place ${message.placeId}`,
      currentGameSource: "manual",
      currentGameTabId: null,
      currentGameSetAt: Date.now(),
    }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === "CLEAR_CURRENT_GAME") {
    updateSettings({
      currentPlaceId: null,
      currentPlaceName: null,
      currentGameSource: null,
      currentGameTabId: null,
      currentGameSetAt: null,
    }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === "SET_POLL_INTERVAL") {
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: message.minutes });
    sendResponse({ ok: true });
    return;
  }

  if (message.type === "GET_PRESENCE_SINGLE") {
    getPresence([message.userId])
      .then((presences) => sendResponse({ ok: true, presence: presences[0] || null }))
      .catch((err) => sendResponse({ ok: false, message: err.message }));
    return true;
  }
});

// If the tab that auto-detected the current game closes, stop monitoring
// against a game the user may no longer be playing.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const settings = await getSettings();
  if (settings.currentGameSource === "auto" && settings.currentGameTabId === tabId) {
    await updateSettings({
      currentPlaceId: null,
      currentPlaceName: null,
      currentGameSource: null,
      currentGameTabId: null,
      currentGameSetAt: null,
    });
  }
});

// If that same tab navigates away from the game's page entirely, same deal.
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (!changeInfo.url) return;
  const settings = await getSettings();
  if (settings.currentGameSource !== "auto" || settings.currentGameTabId !== tabId) return;
  if (!/^https:\/\/www\.roblox\.com\/games\/\d+/.test(changeInfo.url)) {
    await updateSettings({
      currentPlaceId: null,
      currentPlaceName: null,
      currentGameSource: null,
      currentGameTabId: null,
      currentGameSetAt: null,
    });
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) pollWatchlist();
});

chrome.notifications.onClicked.addListener(async (notificationId) => {
  const match = notificationId.match(/^watchlist-(\d+)-/);
  if (!match) return;
  await chrome.tabs.create({ url: profileUrl(Number(match[1])), active: true });
  chrome.notifications.clear(notificationId);
});

async function pollWatchlist() {
  const settings = await getSettings();
  const watchlist = await getWatchlist();

  if (
    settings.currentGameSource === "auto" &&
    settings.currentGameSetAt &&
    Date.now() - settings.currentGameSetAt > AUTO_GAME_MAX_AGE_MS
  ) {
    await updateSettings({
      currentPlaceId: null,
      currentPlaceName: null,
      currentGameSource: null,
      currentGameTabId: null,
      currentGameSetAt: null,
    });
  }

  if (!settings.monitoringEnabled || !watchlist.length) return;

  const userIds = watchlist.map((u) => u.userId);

  let presences;
  try {
    presences = await getPresence(userIds);
    await updateSettings({ lastPollStatus: { ok: true, message: "OK", at: Date.now() } });
  } catch (err) {
    console.error("[qol+] presence poll failed", err);
    await updateSettings({
      lastPollStatus: { ok: false, message: err.message, at: Date.now() },
    });
    return;
  }

  const currentPlaceId = settings.currentPlaceId;
  const presentUserIds = new Set();

  for (const presence of presences) {
    const entry = watchlist.find((u) => u.userId === presence.userId);
    if (!entry) continue;

    try {
      const alertTypes = entry.alertTypes && entry.alertTypes.length ? entry.alertTypes : ["join"];
      const isOnlineNow = presence.userPresenceType !== 0;
      const prevType = await getLastPresenceType(presence.userId);
      const inTargetGame =
        Boolean(currentPlaceId) &&
        (presence.placeId === currentPlaceId || presence.rootPlaceId === currentPlaceId);

      if (inTargetGame) presentUserIds.add(presence.userId);

      if (alertTypes.includes("join")) {
        if (inTargetGame && !(await isNotified(presence.userId))) {
          notify(entry, `${entry.username} just joined your game.`);
          await markNotified(presence.userId);
        } else if (!inTargetGame && (await isNotified(presence.userId))) {
          await clearNotified(presence.userId);
        }
      }

      if (alertTypes.includes("online") && isOnlineNow && prevType === 0) {
        notify(entry, `${entry.username} just came online.`);
      }

      if (alertTypes.includes("offline") && !isOnlineNow && prevType !== null && prevType !== 0) {
        notify(entry, `${entry.username} just went offline.`);
      }

      await setLastPresenceType(presence.userId, presence.userPresenceType);
    } catch (err) {
      await recordError(`pollWatchlist entry ${entry.username}`, err);
    }
  }

  for (const userId of userIds) {
    if (!presentUserIds.has(userId) && (await isNotified(userId))) {
      await clearNotified(userId);
    }
  }
}

function notify(entry, message) {
  chrome.notifications.create(`watchlist-${entry.userId}-${Date.now()}`, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: "Roblox QoL+ alert",
    message: `${message} Click to view profile.`,
    priority: 2,
  });
}
