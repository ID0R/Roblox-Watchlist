# Roblox Watchlist Notifier

Chrome MV3 extension. Notifies you (an OS notification, nothing more) when a
user on your watchlist joins the Roblox game you're currently in, so you can
decide whether to leave, report, or block them.

No script injection, no executor, no reading the game client's memory — it's
plain HTTP polling of Roblox's own public Presence API, the same technique
third-party trackers like Rolimons/RoTracker use.

## Install (unpacked, for personal use)

1. Go to `chrome://extensions`.
2. Enable **Developer mode** (top-right toggle).
3. Click **Load unpacked** → select the `watchlist-notifier` folder.
4. Pin the extension icon to your toolbar for quick access.

## Setup

1. Click the extension icon.
2. Add usernames to your watchlist (they're resolved to Roblox user IDs
   automatically).
3. Make sure **Monitoring** is toggled on.
4. Tell the extension what game you're currently in — two ways:
   - **Automatic**: open the game's page at `roblox.com/games/<id>/...` in a
     browser tab and leave it open while you play. The extension reads the
     `placeId` from that tab.
   - **Manual**: in the popup, under "Current game," type the numeric Place
     ID and click **Set**. Use this if you're playing through the native
     Roblox client without a browser tab open (the common case). Find a
     game's Place ID in its `roblox.com/games/<id>/...` URL.
5. Click **Clear** next to the current game if you stop playing and want to
   stop monitoring immediately, instead of waiting for auto-clear.

## What happens when a watched user joins

- Every poll interval (default 1 minute, configurable in **Settings**), the
  extension checks Roblox's Presence API for everyone on your watchlist.
- If someone's `placeId`/`rootPlaceId` matches your current game, you get a
  Windows/OS notification: "`<username>` just joined your game."
- Clicking the notification opens their Roblox profile in a new tab.
- You won't get repeat notifications every poll cycle while they're still
  in — only once per join. If they leave and rejoin later, you're notified
  again.
- Each watchlist entry in the popup also has a **Block/Report** button,
  which opens their profile page so you can block or report them in one
  more click (Roblox's own block flow lives behind a menu + confirm dialog
  that this extension doesn't try to automate — see Limitations).

## Settings page

- **Poll interval**: how often (in minutes, minimum 1 — a Chrome-enforced
  floor for recurring alarms) the extension checks presence.
- The popup also shows **Last check OK/FAILED** under the current game, so
  you can tell at a glance if the Presence API call is actually succeeding.

## How current-game detection stays accurate

- If the tab that auto-detected your game closes, or navigates away from
  that game's page, the extension automatically stops monitoring against
  it (so it doesn't keep watching a stale game).
- As a backstop, an auto-detected game also expires after 20 minutes of no
  update, in case the tab-close detection misses an edge case.
- A manually-set game does **not** auto-expire — clear it yourself when
  you're done.

## Known limitations (from Roblox's API, not this code)

- If a watched user's "who can see what I'm playing" privacy setting is
  "No one," their `placeId` won't come back — that's Roblox respecting
  their privacy, and this extension doesn't try to work around it.
- The Presence API can't return a full server roster (everyone in one
  specific server instance) — only "is user X currently in game Y." In a
  game with many concurrent servers, a match means "same game," not
  necessarily "same server."
- Some fields (`gameId`, `placeId`) are inconsistently populated depending
  on caller context, per Roblox devforum reports — treat a missing field as
  "unknown," not "definitely not playing."
- Blocking is not fully automated. Roblox's block action requires an
  authenticated `.ROBLOSECURITY` session plus a CSRF handshake, sits behind
  a menu + confirm dialog, and its underlying endpoint has changed shape
  more than once. Automating it reliably isn't realistic without the
  extension scraping session cookies, which isn't something this project
  does. **Block/Report** instead opens the profile page, focused, so you're
  one manual click away.

## Files

```
manifest.json     MV3 manifest
background.js     Service worker: polling loop, tab tracking, notifications
content.js        Detects current game from the Roblox page URL
popup.html/js/css Watchlist UI, current-game override, poll status, block/report
options.html/js/css  Poll interval setting
lib/storage.js    chrome.storage.local helpers (watchlist, settings, notified-state)
lib/roblox-api.js Presence API (batched) + username lookup + block/report action
icons/            Toolbar/notification icons — voxel-stud mark (original design, not Roblox's logo)
```
