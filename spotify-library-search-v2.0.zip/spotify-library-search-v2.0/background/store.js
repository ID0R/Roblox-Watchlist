"use strict";

/*
 * Index storage.
 *
 * Much smaller than it used to be, because everything that made it big is
 * gone. There is no paging, no resume-from-offset, no snapshot comparison, no
 * rate-limit gate and no partial-build bookkeeping — all of which existed to
 * survive a network fetch that could fail halfway through a service worker's
 * lifetime.
 *
 * Records now arrive complete, in one message, from a content script that read
 * them off the page. A build either produced rows or it didn't, and the worker
 * finds out in a single call that takes milliseconds. The failure modes that
 * shaped three previous versions of this file cannot occur.
 *
 * Record shape, unchanged so the scorer didn't have to be touched:
 *
 *   i  index in the source ordering      _t title, normalised
 *   p  row position on the page          _a artists, normalised
 *   id Spotify track id                  _l album, normalised
 *   n  name                              y  release year (0 — see below)
 *   a  artist names                      ad added-at ISO string
 *   al album name                        lo local file flag
 *   im artwork url
 *   d  duration in ms
 *
 * `i` and `p` are usually equal and are not the same thing. `i` is the record's
 * ordinal in this index, which is what results are ordered and numbered by. `p`
 * is the `aria-rowindex` position the row had on the page, which is what a
 * later partial flush merges against. They diverge whenever a row is skipped —
 * an unreadable row, or simply a harvest still in progress — and conflating
 * them corrupted mid-sweep merges: every flush renumbered the records it had
 * from zero, so the next flush merged real row 40 onto record 12 and overwrote
 * a different track.
 *
 * `y` is always 0. Release year is not rendered anywhere in Spotify's track
 * list, so it cannot be read from it, so the `year:` operator has nothing to
 * filter on. That is an honest cost of not calling an API and it is stated in
 * the UI rather than left to be discovered.
 */

(function attachStore(global) {
  const Text = global.SLSText;

  /* Bumped to 11 for the `p` field. An older index has no positions to merge
   * against, and reading one would reintroduce the bug the field fixes, so it
   * is treated as absent and re-harvested. */
  const SCHEMA_VERSION = 11;
  const CHUNK_SIZE = 500;

  /* The worker's cache is not a cache of everything. A large library across
   * many playlists is tens of megabytes of records, and an MV3 worker that
   * grows without bound is one the browser kills. Least-recently-used contexts
   * are dropped; they cost one storage read to bring back. */
  const MEMORY_LIMIT = 24;

  const META_PREFIX = "idx.meta.";
  const CHUNK_PREFIX = "idx.chunk.";
  const PLAYLIST_DIRECTORY_KEY = "idx.playlists";

  /* ctxKey -> { meta, songs }, in least-recently-used order. */
  const memory = new Map();

  function remember(key, entry) {
    memory.delete(key);
    memory.set(key, entry);

    while (memory.size > MEMORY_LIMIT) {
      const oldest = memory.keys().next().value;
      if (oldest === undefined) break;
      memory.delete(oldest);
    }

    return entry;
  }

  function recall(key) {
    const entry = memory.get(key);
    if (!entry) return null;

    /* Re-insert so it counts as recently used. */
    memory.delete(key);
    memory.set(key, entry);

    return entry;
  }

  function contextKey(context) {
    if (context?.type === "liked") return "liked";
    if (context?.type === "global") return "global";
    if (context?.type === "playlist" && context.id) return `pl_${context.id}`;
    throw new Error("INVALID_CONTEXT");
  }

  const metaKey = (key) => `${META_PREFIX}${key}`;
  const chunkKey = (key, index) => `${CHUNK_PREFIX}${key}.${index}`;

  function trackUri(song) {
    return song.lo ? "" : `spotify:track:${song.id}`;
  }

  function trackUrl(song) {
    return song.lo ? "" : `https://open.spotify.com/track/${song.id}`;
  }

  /* --------------------------- normalisation --------------------------- */

  /*
   * Turns a harvested row into an index record. The normalised fields are
   * computed once, here, and never again — which is what makes matching on
   * every keystroke free, and what makes searching case-, accent- and
   * apostrophe-insensitive without any of the search code knowing about it.
   */
  function toRecord(row, index, position) {
    const name = String(row?.name || "").trim();
    if (!name) return null;

    const artists = Array.isArray(row.artists) ? row.artists.filter(Boolean) : [];
    const album = String(row.album || "").trim();

    return {
      i: index,
      p: Number.isFinite(position) ? position : index,
      id: row.id || `local:${position ?? index}`,
      n: name,
      a: artists,
      al: album,
      im: String(row.image || ""),
      y: 0,
      d: Number(row.duration) || 0,
      ad: row.added || null,
      lo: row.isLocal ? 1 : 0,
      _t: Text.normalize(name),
      _a: Text.normalize(artists.join(" ")),
      _l: Text.normalize(album)
    };
  }

  /*
   * Harvested rows can repeat: a recycled DOM row may be read twice before its
   * index is recorded, and a playlist can legitimately contain the same track
   * twice. Deduplication is by *position*, not by track id — position is
   * unique by definition, and collapsing by id would silently delete the
   * genuine duplicates that `is:dupe` exists to find.
   */
  function toRecords(rows) {
    const byPosition = new Map();

    for (const row of rows || []) {
      const position = Number(row?.position);
      if (!Number.isFinite(position)) continue;
      if (byPosition.has(position)) continue;

      byPosition.set(position, row);
    }

    const ordered = [...byPosition.entries()].sort((a, b) => a[0] - b[0]);

    const records = [];

    for (const [position, row] of ordered) {
      const record = toRecord(row, records.length, position);
      if (record) records.push(record);
    }

    return records;
  }

  /* --------------------------- persistence --------------------------- */

  async function readMeta(key) {
    const stored = await chrome.storage.local.get(metaKey(key));
    const meta = stored[metaKey(key)];

    if (!meta || meta.v !== SCHEMA_VERSION) return null;
    return meta;
  }

  /*
   * Every meta in one call. The per-context version of this ran one awaited
   * read per playlist, so a 120-playlist library paid 120 round trips to answer
   * "how much is indexed?" — and the popup and options page both ask that on
   * every storage change, which during a sweep is every flush.
   */
  async function readMetas(keys) {
    const byKey = new Map();
    if (!keys.length) return byKey;

    const stored = await chrome.storage.local.get(keys.map(metaKey));

    for (const key of keys) {
      const meta = stored[metaKey(key)];
      byKey.set(key, meta && meta.v === SCHEMA_VERSION ? meta : null);
    }

    return byKey;
  }

  async function readChunks(key, chunkCount) {
    if (!chunkCount) return [];

    const keys = [];
    for (let i = 0; i < chunkCount; i++) keys.push(chunkKey(key, i));

    const stored = await chrome.storage.local.get(keys);

    const songs = [];
    for (const name of keys) {
      const chunk = stored[name];
      if (Array.isArray(chunk)) songs.push(...chunk);
    }

    return songs;
  }

  async function dropChunks(key, chunkCount) {
    if (!chunkCount) return;

    const keys = [];
    for (let i = 0; i < chunkCount; i++) keys.push(chunkKey(key, i));

    await chrome.storage.local.remove(keys);
  }

  async function load(context) {
    const key = contextKey(context);

    const cached = recall(key);
    if (cached) return cached;

    const meta = await readMeta(key);
    if (!meta) return null;

    const songs = await readChunks(key, meta.chunks);

    return remember(key, { meta, songs });
  }

  /*
   * Write a whole context at once.
   *
   * `partial` marks a mid-harvest snapshot: it is stored so results can appear
   * while the sweep runs, but it is not treated as a finished index, so the
   * next visit re-reads the page rather than trusting half a list.
   */
  async function write(context, rows, { total, complete = true, partial = false } = {}) {
    const key = contextKey(context);
    const records = toRecords(rows);

    const existing = await readMeta(key);

    /*
     * A partial never shrinks the index. Flushes are fired without awaiting so
     * they can overtake each other, and an early screenful landing after a
     * later one would otherwise throw away the difference. `partialOf` in the
     * first draft was a field that never existed anywhere — a condition that
     * reads sensibly and evaluates to nonsense, which is the worst kind.
     */
    if (partial && existing && existing.count > records.length) {
      return { indexed: existing.count };
    }

    if (existing) await dropChunks(key, existing.chunks);

    const writes = {};
    let chunks = 0;

    for (let i = 0; i < records.length; i += CHUNK_SIZE) {
      writes[chunkKey(key, chunks)] = records.slice(i, i + CHUNK_SIZE);
      chunks++;
    }

    const meta = {
      v: SCHEMA_VERSION,
      type: context.type,
      id: context.id || null,
      label: context.label || "",
      total: Number(total) || records.length,
      count: records.length,
      chunks,
      indexedAt: Date.now(),
      complete: Boolean(complete) && !partial,
      partial: Boolean(partial)
    };

    writes[metaKey(key)] = meta;

    await chrome.storage.local.set(writes);

    remember(key, { meta, songs: records });

    /*
     * Only a finished write touches the directory. Partial flushes arrive every
     * few hundred milliseconds, and each directory update is a read plus a
     * rewrite of every playlist the user has — so noting the playlist on every
     * flush rewrote the whole directory dozens of times per list, for a count
     * that was about to be superseded anyway.
     */
    if (!partial && context.type === "playlist" && context.id) {
      await notePlaylist(context, records.length);
    }

    return { indexed: records.length };
  }

  async function getStatus(context) {
    if (context?.type === "global") return getGlobalStatus();

    const entry = await load(context);

    if (!entry) {
      return {
        ready: false,
        complete: false,
        partial: false,
        indexed: 0,
        total: 0,
        indexedAt: null
      };
    }

    return {
      ready: entry.songs.length > 0,
      complete: Boolean(entry.meta.complete),
      partial: Boolean(entry.meta.partial),
      indexed: entry.songs.length,
      total: entry.meta.total || entry.songs.length,
      indexedAt: entry.meta.indexedAt || null
    };
  }

  /* ----------------------- cross-playlist index ----------------------- */

  async function getPlaylistDirectory() {
    const stored = await chrome.storage.local.get(PLAYLIST_DIRECTORY_KEY);
    return stored[PLAYLIST_DIRECTORY_KEY] || null;
  }

  async function setPlaylistDirectory(playlists) {
    const existing = (await getPlaylistDirectory()) || { playlists: [] };
    const byId = new Map(existing.playlists.map((entry) => [entry.id, entry]));

    for (const playlist of playlists || []) {
      if (!playlist?.id) continue;

      byId.set(playlist.id, { ...(byId.get(playlist.id) || {}), ...playlist });
    }

    const directory = { updatedAt: Date.now(), playlists: [...byId.values()] };

    await chrome.storage.local.set({ [PLAYLIST_DIRECTORY_KEY]: directory });
    return directory;
  }

  /*
   * Visiting a playlist adds it to the directory whether or not a whole-library
   * sweep ever runs. Over normal use the "Everything" scope fills itself in,
   * which is a quiet advantage of reading the page rather than an API: the
   * user browsing their own library *is* the indexing process.
   */
  async function notePlaylist(context, total) {
    await setPlaylistDirectory([
      { id: context.id, name: context.label || "Playlist", total }
    ]);
  }

  async function getGlobalStatus() {
    const directory = await getPlaylistDirectory();

    const contexts = [
      { type: "liked" },
      ...(directory?.playlists || []).map(toPlaylistContext)
    ];

    const metas = await readMetas(contexts.map(contextKey));

    let indexed = 0;
    let covered = 0;
    let coveredPlaylists = 0;

    for (const context of contexts) {
      const meta = metas.get(contextKey(context));
      if (!meta?.count) continue;

      indexed += meta.count;
      covered++;

      if (context.type === "playlist") coveredPlaylists++;
    }

    return {
      ready: covered > 0,
      complete: covered === contexts.length && contexts.length > 1,
      indexed,
      total: indexed,
      playlists: directory?.playlists?.length || 0,
      covered: coveredPlaylists,
      indexedAt: null
    };
  }

  function toPlaylistContext(playlist) {
    return { type: "playlist", id: playlist.id, label: playlist.name };
  }

  /*
   * Every indexed context at once, for whole-library search.
   *
   * Reading them one at a time cost two awaited storage round trips per
   * playlist — a meta, then its chunks — so a 120-playlist library spent most
   * of a search waiting on serialised I/O rather than matching. Now it is one
   * read for the metas and one read for every chunk of every context that is
   * not already in memory.
   */
  async function loadGlobal() {
    const directory = await getPlaylistDirectory();

    const contexts = [
      { type: "liked", label: "Liked Songs" },
      ...(directory?.playlists || []).map(toPlaylistContext)
    ];

    /* Assembled here rather than read back out of `memory`, because the cache
     * is bounded: a library with more contexts than the cache holds would
     * otherwise evict its own earlier reads before it finished. */
    const entries = new Map();
    const pending = [];

    for (const context of contexts) {
      const key = contextKey(context);
      const cached = recall(key);

      if (cached) entries.set(key, cached);
      else pending.push(context);
    }

    const metas = await readMetas(pending.map(contextKey));

    const chunkKeys = [];
    for (const context of pending) {
      const key = contextKey(context);
      const meta = metas.get(key);

      for (let i = 0; i < (meta?.chunks || 0); i++) chunkKeys.push(chunkKey(key, i));
    }

    const stored = chunkKeys.length ? await chrome.storage.local.get(chunkKeys) : {};

    for (const context of pending) {
      const key = contextKey(context);
      const meta = metas.get(key);
      if (!meta) continue;

      const songs = [];
      for (let i = 0; i < (meta.chunks || 0); i++) {
        const chunk = stored[chunkKey(key, i)];
        if (Array.isArray(chunk)) songs.push(...chunk);
      }

      const entry = { meta, songs };

      entries.set(key, entry);
      remember(key, entry);
    }

    const sources = [];

    for (const context of contexts) {
      const entry = entries.get(contextKey(context));
      if (!entry?.songs.length) continue;

      sources.push({
        context,
        label: context.label || "Liked Songs",
        labelNorm: Text.normalize(context.label || "Liked Songs"),
        songs: entry.songs
      });
    }

    return sources;
  }

  /* ------------------------------ mutation ------------------------------ */

  /*
   * Key names only. `get(null)` returns every value as well, which for a large
   * library means deserialising the entire index into the worker just to read
   * the names off it. `getKeys` is Chrome 130+, so the old path stays as a
   * fallback rather than as the default.
   */
  async function allStorageKeys() {
    if (typeof chrome.storage.local.getKeys === "function") {
      return chrome.storage.local.getKeys();
    }

    return Object.keys(await chrome.storage.local.get(null));
  }

  async function clearAllIndexes() {
    const keys = (await allStorageKeys()).filter(
      (key) =>
        key.startsWith(META_PREFIX) ||
        key.startsWith(CHUNK_PREFIX) ||
        key === PLAYLIST_DIRECTORY_KEY
    );

    if (keys.length) await chrome.storage.local.remove(keys);
    memory.clear();
  }

  /*
   * Index size without reading the index.
   *
   * This is called by the options page and the popup on every `idx.*` storage
   * change, which during a sweep is once per flush. The old version answered it
   * by loading every chunk of every context and measuring the JSON — the single
   * most expensive operation in the extension, triggered by its own writes.
   * `getBytesInUse` asks the storage layer the same question directly.
   */
  async function estimateUsage() {
    const directory = await getPlaylistDirectory();

    const keys = [
      "liked",
      ...(directory?.playlists || []).map((playlist) =>
        contextKey(toPlaylistContext(playlist))
      )
    ];

    const metas = await readMetas(keys);

    const chunkKeys = [];
    let contexts = 0;

    for (const [key, meta] of metas) {
      if (!meta) continue;

      contexts++;
      for (let i = 0; i < (meta.chunks || 0); i++) chunkKeys.push(chunkKey(key, i));
    }

    const indexBytes = chunkKeys.length
      ? await chrome.storage.local.getBytesInUse(chunkKeys).catch(() => 0)
      : 0;

    return { indexBytes, contexts };
  }

  global.SLSStore = {
    SCHEMA_VERSION,
    contextKey,
    toPlaylistContext,
    toRecords,
    load,
    loadGlobal,
    write,
    getStatus,
    getGlobalStatus,
    getPlaylistDirectory,
    setPlaylistDirectory,
    clearAllIndexes,
    estimateUsage,
    trackUri,
    trackUrl
  };
})(typeof self !== "undefined" ? self : globalThis);
