# Roblox QoL+

Chrome MV3 extension. Free core: dark theme for roblox.com, a last-online
badge on profile pages, and watchlist join alerts. Premium (locally gated,
no real payment backend yet): custom theme accent color, and online/offline
watchlist alert types in addition to join.

Built to compete on **stability**, not feature count — see the design
rationale in the comments in `content/dark-theme.css` and
`content/lastOnline.js` (whole-page color invert instead of selector-based
reskinning; a floating badge instead of DOM injection). Both choices exist
specifically so a Roblox UI update doesn't break the extension the way it
breaks BTRoblox/Roblokis-style competitors.

## Install (unpacked, for development/testing)

1. Go to `chrome://extensions`.
2. Enable **Developer mode** (top-right toggle).
3. Click **Load unpacked** → select the `roblox-qol-plus` folder.
4. Pin the extension icon to your toolbar.

## Using it

### Dark theme
- Open the popup → check **Enable on roblox.com** under "Dark theme."
- Takes effect immediately on any open or new roblox.com tab (reload the
  tab if it was already open — content scripts don't retroactively inject
  into pages loaded before the extension was toggled).
- **Accent hue** slider is premium-gated (grayed out with a "Premium" tag
  until unlocked — see below).

### Last-online badge
- Automatic. Visit any `roblox.com/users/<id>/profile` page — a small
  floating badge appears bottom-right showing their presence (Online /
  In a game / In Studio / Last seen `<time>`).
- No setup needed, no watchlist entry required — works for any profile you
  visit.

### Watchlist alerts
1. In the popup, add a Roblox username under "Add to watchlist."
2. Toggle **Monitoring** on (top-right switch).
3. Tell it your current game — same two options as before:
   - **Automatic**: keep a `roblox.com/games/<id>/...` tab open while you
     play.
   - **Manual**: type the numeric Place ID under "Current game" → **Set**.
4. Each watchlist entry has **Join / Online / Offline** checkboxes:
   - **Join** is free, on by default — notifies when they enter your
     current game.
   - **Online** and **Offline** are premium-gated — notify on any
     online/offline transition, regardless of what game either of you is
     in.
5. Click a notification to open that user's profile. Or use the
   **Block/Report** button next to their entry any time — opens their
   profile page focused, since Roblox's own block flow needs a manual
   click through their menu + confirm dialog (see Limitations).

### Unlocking premium (for testing — read this before showing anyone else)
- Go to **Settings** (popup footer link) → **Developer / testing** section
  → check **Unlock premium features**.
- This is a **local-only toggle**, not a real purchase. It flips
  `settings.premiumUnlocked` in `chrome.storage.local` so you can see and
  test the premium UI (accent hue slider, online/offline alerts) before
  building a real payment system.
- Anyone who installs this unpacked build can flip this checkbox
  themselves and get premium for free — that's expected and fine for a
  personal/dev build. It is **not** how you'd ship this publicly.

## Wiring up real payments (not built yet — here's the shape of it)

This scaffold deliberately stops short of a payment backend since that
needs your own accounts/credentials. When you're ready:

1. Stand up a small backend (any stack) with:
   - A Stripe Checkout session endpoint that issues a signed license key
     (or a Stripe Customer ID) on successful payment.
   - A `/validate` endpoint the extension calls with that key, returning
     `{ valid: true/false }`.
2. Replace the body of `isPremiumUnlocked()` in `lib/premium.js`: instead
   of reading `settings.premiumUnlocked` from local storage, call
   `/validate`, cache the result (with a timestamp) into
   `settings.premiumUnlocked` / `settings.premiumCheckedAt` so you're not
   round-tripping on every popup render, and re-check periodically (e.g.
   once a day via the existing `chrome.alarms` pattern in `background.js`).
3. Add a "Buy premium" button in `options.html` that opens your Checkout
   page in a new tab, and a "Enter license key" input that calls
   `/validate` and stores the result.
4. Remove the dev-only checkbox from `options.html`/`options.js` before
   shipping.
5. Chrome Web Store no longer supports native paid-extension billing —
   this external license-key flow is the standard workaround other paid
   extensions (RoPro, etc.) use.

## Diagnostics

`background.js` catches uncaught errors, unhandled promise rejections, and
per-watchlist-entry poll failures, storing the most recent one to
`settings.lastError`. Shown on the Settings page under poll interval if
present, so a bad entry or transient API failure no longer fails silently.

## Known limitations (from Roblox's API, not this code)

- Presence API can't return a full server roster — a "join" match means
  "same game," not necessarily "same server," in games with many
  concurrent servers.
- If a watched user's privacy setting is "No one," their `placeId` won't
  come back — that's Roblox respecting their privacy; this extension
  doesn't try to work around it.
- Some presence fields are inconsistently populated depending on caller
  context, per Roblox devforum reports.
- Blocking is not fully automated — Roblox's block flow needs an
  authenticated CSRF handshake and sits behind a menu + confirm dialog.
  **Block/Report** opens the profile page focused rather than attempting a
  fragile auto-click.
- Dark theme uses a whole-page color-invert filter, not a true reskin — a
  few images/icons on roblox.com may look slightly off-color even with the
  media-element counter-invert. This tradeoff is intentional: it survives
  Roblox layout changes that would break a selector-based dark theme.

## Files

```
manifest.json           MV3 manifest
background.js           Service worker: watchlist poll loop, tab tracking,
                         presence-transition detection, notifications
content/
  theme.js               Applies/removes dark-theme class + accent hue var
  dark-theme.css          Smart-invert dark theme (survives UI redesigns)
  lastOnline.js           Floating presence badge on profile pages
  currentGame.js          Detects current game from the Roblox page URL
popup.html/js/css        Main UI: theme toggle, current game, watchlist
options.html/js/css      Poll interval + dev premium toggle
lib/
  storage.js              chrome.storage.local helpers (watchlist, settings,
                           notified-state, presence-history)
  roblox-api.js            Presence API (batched) + username lookup + block/report
  premium.js               Local premium-gate check (swap for real backend later)
icons/                   Toolbar/notification icons — violet/paper split-block
                         with a "+" mark (original design, not Roblox's logo)
```
