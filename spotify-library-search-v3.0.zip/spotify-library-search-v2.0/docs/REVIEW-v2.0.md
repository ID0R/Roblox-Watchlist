# Code review — v1.3.0 → v2.0.0

The architecture you proposed, and why it was the right call.

---

## The idea

> "Somehow you are able to scan, the extension is able to scan all the songs
> that the user has… without using your own credentials or using API."

That is exactly what this version does, and it resolves a problem that three
previous versions could not, because the problem was never in this codebase.

**v1.2** borrowed the web player's access token. **v1.3** established why that
fails: the token belongs to Spotify's own first-party Client ID, Spotify's rate
limit is applied per Client ID regardless of user, and Spotify now refuses
first-party credentials at `api.spotify.com` outright. Every request returned
429 on arrival.

v1.3's answer was to get a legitimate credential — your own registered app.
Correct, and a bad fit for what you are building: it requires Premium, which
rules out most of the people you want to reach.

**v2.0's answer is to stop needing a credential.** Your browser already has
your library. Spotify fetched it, laid it out and rendered it — that is what
is on your screen. Reading rows off your own screen needs no token, makes no
request, has no quota and cannot be refused, because nothing is being asked of
anyone.

---

## What was actually still broken in v1.3

Worth recording, because "the spinner came back" had a cause.

**S1 — Default source was `own-app`, and you had no Client ID.** So every
search started a build, the build asked `Auth.ensureToken()` for a token that
did not exist, and threw `AUTH_REQUIRED`. The UI had a message for that.

The likely reason you saw a spinner instead: **reloading an extension does not
re-inject content scripts into tabs that are already open.** A Spotify tab left
open from the v1.2 session keeps running v1.2's content script — including
v1.2's restart loop — against v1.3's worker. Everything you described matches
that exactly.

That is a real usability failure regardless of whose fault it is, and v2.0
removes the conditions for it: there is no Client ID, no source setting, and no
state that a stale content script can get stuck in.

---

## The new architecture

**Indexing moved out of the service worker and into the content script.** That
one move deletes an entire category of failure. The worker could be evicted
mid-build (v1.2's spinner); it had no DOM, so it had to ask Spotify's servers
for data that was already rendered (v1.3's 429). A content script has the DOM
and lives as long as the tab.

```
  before                            after
  ──────                            ─────
  worker ──HTTP──► api.spotify.com  content script ──reads──► the page
     │  429, forever                     │  records
     └─ build.state ──► content          └──► worker ──► index
```

The worker's entire remaining job is storage and matching. Every handler
completes in milliseconds, so eviction is now irrelevant rather than fatal.

### The harvester

`content/harvest.js`. Scroll the virtualised list, collect what renders,
repeat. Three things make it reliable rather than approximate:

- **`aria-rowindex` is identity.** Recycled rows arrive out of order and
  repeat; collection order means nothing and position means everything.
- **`aria-rowcount` is the finish line.** The grid publishes the true total, so
  progress is "340 of 935" and completion is a fact rather than a guess.
- **The observer is armed before the scroll, never after.** React commits a
  scroll-driven re-render synchronously, so an observer attached afterwards has
  already missed the mutation it is waiting for and sits out the full timeout
  every step. Measured on 935 tracks: **71 seconds before this fix, 0.48
  seconds after.** Single highest-impact line in the release.

Then a gap-filling pass: work out which row indices are still missing, scroll
to each, collect. It repeats while it is still recovering rows and stops the
moment a full pass adds nothing — a fixed pass count loses rows when a
gap-filling scroll is itself dropped, which is the exact failure being worked
around.

### On parallelism

You asked about parallel processing or multithreading. It does not apply, and
that is worth saying rather than quietly skipping: there is one list, one
scroll position and one renderer. You cannot be at two scroll offsets at once,
and a worker thread has no DOM.

What makes it fast is not doing work at once but never waiting unnecessarily —
the observer-before-scroll change above. 935 tracks in under half a second;
10,000 in 2.7 seconds.

### Whole-library indexing

The player only loads a playlist's tracks when you open it, so the extension
opens each in turn. `content/sweep.js` keeps **no state in memory**: queue,
cursor, tally and return-page all live in `chrome.storage.local` and are
re-read on every page load. If a navigation turns into a full reload, the sweep
resumes from disk two seconds later. Same lesson as MV3 worker eviction,
applied to a different boundary.

Playlists are also indexed opportunistically whenever you visit one, so normal
browsing fills the cross-playlist index in on its own.

---

## Tested

A hand-built fake of Spotify's virtualised grid (no network in the build
environment, so no jsdom — which turned out to help, because the fake can be
made to misbehave the way real renderers do).

| Scenario | Result |
|---|---|
| 935 tracks, clean renderer | 935/935, correct order, 0.48s |
| 935 tracks, renderer lags 30 ms | 935/935, 3.3s |
| 935 tracks, zero overscan | 935/935, 0.46s |
| 935 tracks, every 4th render dropped | 935/935, 5.5s |
| 935 tracks, every 3rd dropped + lag | 935/935, 12.6s |
| 10,000 tracks | 10,000/10,000, 2.7s |
| 12 tracks (fits on screen, no scrollbar) | 12/12 |
| 1 track / 0 tracks | handled |

End-to-end, 935 harvested rows through storage into search: 221 KB stored,
`travis` → 401 hits in 1.6 ms, `TRAVIS` identical, `is:dupe` and `artist:` and
`added:` all correct, index byte-identical to the page in original order.

### Bugs the tests found

- **Short playlists crashed.** A list that fits on screen has no scroll
  container, so `findScroller` returned null and the harvest threw
  `NO_SCROLLER`. A twelve-track playlist is not a failure, it is the easiest
  case — no scroller now means every row is already rendered, so collect and
  return.
- **`existing.partialOf`** — a condition referencing a field that has never
  existed anywhere in the codebase. Reads sensibly, evaluates to nonsense.
- **A partial flush could downgrade a finished index.** A snapshot arriving
  after a completed harvest merged into it and re-flagged the whole thing
  partial, causing a re-harvest on every subsequent visit.

---

## What this costs

Stated plainly, because it is the real trade.

**`year:` is gone.** Release year is not rendered anywhere in Spotify's track
list, so there is nothing on the page to read it from. Every other operator
works, because every other operator maps to a column you can see.

**A playlist must be visited to be indexed.** Either by you, or by the sweep
opening it for you.

**Selectors are Spotify internals.** Everything here is derived from structure
first — the ARIA grid role, `aria-rowindex`, `aria-rowcount`, and `/track/`,
`/artist/`, `/album/` hrefs, which are what the player itself navigates with.
Test ids are tried first as a fast path but nothing depends on them. This is
the most maintenance-prone part of the tree and always will be; the difference
from previous versions is that a break here fails loudly with a named error
rather than looking like an empty library.

**Playback got better, not worse.** The old API fallback was Premium-only. Now
every indexed track was read off a row, so every indexed track has a row, and
activation is a scroll and a click that works on any account.

---

## What was deleted

`background/auth.js`, `background/session.js`, `background/api.js`,
`background/importer.js`, `page/interceptor.js`, `content/bridge.js` — and with
them the `identity` permission, the `alarms` permission, and the
`api.spotify.com` and `accounts.spotify.com` host permissions.

The extension can now reach exactly one thing: the Spotify tab you already have
open. It only reads it.

| | v1.3 | v2.0 |
|---|---|---|
| Permissions | 5 + 3 hosts | 3 + 1 host |
| MAIN-world script | yes | no |
| Network requests | yes | **none** |
| Setup steps | 4 (or a 5-day wait) | 0 |
| Premium required | yes | no |

---

## Open

**No incremental update.** Re-visiting a playlist re-reads the whole list. At
half a second for 935 tracks this is not worth optimising; at 50,000 it would
be. The integrity check is already in place — the index compares its count
against the grid's `aria-rowcount` and only re-reads when they disagree.

**A sorted or filtered list is indexed as displayed.** If you sort a playlist
by title and then index it, positions reflect that sort. Harmless for search,
slightly odd for the position numbers shown in "which playlist is this in".

**Album pages and artist pages** use the same grid structure and would work
with a route entry each.

**Still no test suite in the repo.** The harness used for this release
(`fake-dom.js` plus the harvest, end-to-end and partial-flush tests) is the
thing most worth committing next — it caught three real bugs in one afternoon.
