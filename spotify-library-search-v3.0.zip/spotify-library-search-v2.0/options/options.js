"use strict";
/*
* Options page.
*
* Almost everything this page used to do is gone, because almost everything it
* used to do was setup — a Client ID field, a redirect URI, a connect button,
* a source picker, a file dropzone, a session diagnostic block. None of it is
* needed by a version that reads the page.
*
* What's left is what a settings page should be: what's indexed, what the
* search understands, and a switch for each behaviour that is a matter of
* taste. The result-count setting is deliberately not among them: showing
* every match is the point, not a preference.
*/
const el = (id) => document.getElementById(id);
const ui = {
connectionBadge: el("connectionBadge"),
connectionText: el("connectionText"),
statLiked: el("statLiked"),
statPlaylists: el("statPlaylists"),
statSize: el("statSize"),
sweep: el("sweep"),
sweepHint: el("sweepHint"),
exportCsv: el("exportCsv"),
clearIndexes: el("clearIndexes"),
clearEverything: el("clearEverything"),
filterName: el("filterName"),
filterQuery: el("filterQuery"),
addFilter: el("addFilter"),
filterList: el("filterList"),
toast: el("toast"),
confirmDialog: el("confirmDialog"),
confirmTitle: el("confirmTitle"),
confirmBody: el("confirmBody"),
confirmOk: el("confirmOk")
};
const TOGGLES = [
"filterList",
"fuzzySearch",
"highlightRows",
"autoIndexOnOpen",
"showSupportLink"
];
let toastTimer = 0;
init();
async function init() {
bindEvents();
await refreshAll();
/* The sweep runs in the Spotify tab and writes its progress to storage, so
* this page can watch it without holding a connection to anything. */
chrome.storage.onChanged.addListener((changes, area) => {
if (area !== "local") return;
if (changes.sweep) renderSweep(changes.sweep.newValue);
if (Object.keys(changes).some((key) => key.startsWith("idx."))) refreshStats();
});
}
function bindEvents() {
ui.sweep.addEventListener("click", async () => {
ui.sweep.disabled = true;
ui.sweepHint.textContent = "Opening Spotify…";
const result = await send({ type: "START_SWEEP" });
ui.sweep.disabled = false;
if (!result.ok) {
ui.sweepHint.textContent =
result.error === "TAB_NOT_READY"
? "Spotify is open but still loading. Give it a moment and try again."
: "Couldn't reach a Spotify tab. Open open.spotify.com and try again.";
return;
}
ui.sweepHint.textContent =
"Running in your Spotify tab — switch to it to watch, or leave it be.";
});
ui.addFilter.addEventListener("click", addFilter);
ui.filterQuery.addEventListener("keydown", (event) => {
if (event.key === "Enter") addFilter();
});
ui.filterList.addEventListener("click", async (event) => {
const button = event.target.closest?.("[data-delete]");
if (!button) return;
const result = await send({ type: "DELETE_FILTER", id: button.dataset.delete });
if (result.ok) renderFilters(result.filters || []);
toast("Filter removed");
});
ui.exportCsv.addEventListener("click", exportCsv);
ui.clearIndexes.addEventListener("click", async () => {
const ok = await confirmAction(
"Clear the search index?",
"It rebuilds itself the next time you open a playlist, which takes a few seconds."
);
if (!ok) return;
await send({ type: "CLEAR_INDEXES" });
toast("Index cleared");
await refreshAll();
});
ui.clearEverything.addEventListener("click", async () => {
const ok = await confirmAction(
"Erase everything?",
"This removes the index, your saved filters and all your settings.",
"Erase"
);
if (!ok) return;
await send({ type: "CLEAR_EVERYTHING" });
toast("Everything erased");
await refreshAll();
});
for (const name of TOGGLES) {
el(name).addEventListener("change", (event) => {
saveSettings({ [name]: event.target.checked });
});
}
}
async function addFilter() {
const query = ui.filterQuery.value.trim();
if (!query) {
toast("Add a query first");
return;
}
const result = await send({
type: "SAVE_FILTER",
query,
name: ui.filterName.value.trim() || query
});
if (!result.ok) {
toast("Couldn't save that filter");
return;
}
ui.filterName.value = "";
ui.filterQuery.value = "";
renderFilters(result.filters || []);
toast("Filter saved");
}
function renderFilters(filters) {
ui.filterList.textContent = "";
if (!filters.length) {
const empty = document.createElement("li");
empty.className = "empty";
empty.textContent = "No saved filters yet.";
ui.filterList.appendChild(empty);
return;
}
for (const filter of filters) {
const item = document.createElement("li");
const text = document.createElement("div");
const name = document.createElement("strong");
name.textContent = filter.name;
const query = document.createElement("code");
query.textContent = filter.query;
text.append(name, query);
const remove = document.createElement("button");
remove.type = "button";
remove.className = "ghost danger";
remove.dataset.delete = filter.id;
remove.textContent = "Delete";
item.append(text, remove);
ui.filterList.appendChild(item);
}
}
async function exportCsv() {
const result = await send({ type: "EXPORT_CONTEXT", context: { type: "global" } });
if (!result.ok || !result.rowCount) {
toast(result.ok ? "Nothing indexed yet" : "Export failed");
return;
}
const blob = new Blob([`\ufeff${result.csv}`], { type: "text/csv;charset=utf-8" });
const url = URL.createObjectURL(blob);
const link = document.createElement("a");
link.href = url;
link.download = `spotify-library-${new Date().toISOString().slice(0, 10)}.csv`;
link.click();
URL.revokeObjectURL(url);
toast(`Exported ${format(result.rowCount)} tracks`);
}
/* -------------------------------- state -------------------------------- */
async function refreshAll() {
const [state, storage, sweep] = await Promise.all([
send({ type: "GET_STATE" }),
send({ type: "GET_STORAGE_REPORT" }),
chrome.storage.local.get("sweep")
]);
renderSettings(state.settings);
renderFilters(state.settings?.savedFilters || []);
renderStats(state, storage);
renderSweep(sweep?.sweep);
}
async function refreshStats() {
const [state, storage] = await Promise.all([
send({ type: "GET_STATE" }),
send({ type: "GET_STORAGE_REPORT" })
]);
renderStats(state, storage);
}
function renderStats(state, storage) {
const liked = state.liked || {};
const global = state.global || {};
ui.statLiked.textContent = liked.ready
? `${format(liked.indexed)} tracks${liked.complete ? "" : " (partial)"}`
: "Not read yet";
ui.statPlaylists.textContent = state.playlistCount
? `${format(global.covered || 0)} of ${format(state.playlistCount)} read`
: "None seen yet";
const bytes = storage?.bytesInUse ?? storage?.indexBytes ?? 0;
ui.statSize.textContent = bytes ? formatBytes(bytes) : "—";
const anything = liked.ready || global.covered;
ui.connectionBadge.dataset.state = anything ? "connected" : "setup";
ui.connectionText.textContent = anything ? "Ready" : "Open Spotify to begin";
}
function renderSweep(sweep) {
if (!sweep?.active) {
ui.sweep.disabled = false;
return;
}
ui.sweep.disabled = true;
const label = sweep.queue?.[sweep.cursor]?.label || "";
ui.sweepHint.textContent =
`Indexing ${sweep.cursor + 1} of ${sweep.queue.length}` +
`${label ? ` — ${label}` : ""} · ${format(sweep.tracks || 0)} tracks so far.`;
}
function renderSettings(settings) {
if (!settings) return;
for (const name of TOGGLES) el(name).checked = settings[name] !== false;
}
/* ------------------------------- helpers ------------------------------- */
async function send(message) {
try {
return (await chrome.runtime.sendMessage(message)) || { ok: false };
} catch (error) {
return { ok: false, error: String(error?.message || error) };
}
}
async function saveSettings(patch) {
await send({ type: "SET_SETTINGS", settings: patch });
toast("Saved");
}
function confirmAction(title, body, confirmLabel = "Confirm") {
ui.confirmTitle.textContent = title;
ui.confirmBody.textContent = body;
ui.confirmOk.textContent = confirmLabel;
ui.confirmDialog.showModal();
return new Promise((resolve) => {
ui.confirmDialog.addEventListener(
"close",
() => resolve(ui.confirmDialog.returnValue === "confirm"),
{ once: true }
);
});
}
function toast(message) {
clearTimeout(toastTimer);
ui.toast.textContent = message;
ui.toast.hidden = false;
toastTimer = setTimeout(() => {
ui.toast.hidden = true;
}, 3200);
}
function format(value) {
return Number(value || 0).toLocaleString();
}
function formatBytes(bytes) {
if (bytes < 1024) return `${bytes} B`;
if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}