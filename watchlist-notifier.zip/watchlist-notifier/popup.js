import {
  getWatchlist,
  addToWatchlist,
  removeFromWatchlist,
  getSettings,
  updateSettings,
} from "./lib/storage.js";
import { resolveUserId, profileUrl, blockUser } from "./lib/roblox-api.js";

const listEl = document.getElementById("watchlistItems");
const usernameInput = document.getElementById("usernameInput");
const addBtn = document.getElementById("addBtn");
const addError = document.getElementById("addError");
const monitoringToggle = document.getElementById("monitoringToggle");
const currentGameName = document.getElementById("currentGameName");
const manualPlaceId = document.getElementById("manualPlaceId");
const manualGameBtn = document.getElementById("manualGameBtn");
const clearGameBtn = document.getElementById("clearGameBtn");
const pollStatus = document.getElementById("pollStatus");

function studDot(colorClass) {
  const span = document.createElement("span");
  span.className = `stud small ${colorClass}`;
  span.setAttribute("aria-hidden", "true");
  return span;
}

function formatPollStatus(status) {
  if (!status) return "";
  const when = new Date(status.at).toLocaleTimeString();
  return status.ok ? `Last check OK at ${when}` : `Last check FAILED at ${when}: ${status.message}`;
}

async function render() {
  const [watchlist, settings] = await Promise.all([getWatchlist(), getSettings()]);

  monitoringToggle.checked = settings.monitoringEnabled;

  currentGameName.innerHTML = "";
  if (settings.currentPlaceName) {
    const dotClass = settings.currentGameSource === "manual" ? "amber" : "green";
    const sourceTag = settings.currentGameSource === "manual" ? " (manual)" : "";
    currentGameName.append(
      studDot(dotClass),
      document.createTextNode(`${settings.currentPlaceName} (${settings.currentPlaceId})${sourceTag}`)
    );
  } else {
    currentGameName.append(
      studDot("gray"),
      document.createTextNode("Not detected — open a Roblox game page or set one manually")
    );
  }

  pollStatus.textContent = formatPollStatus(settings.lastPollStatus);
  pollStatus.classList.toggle("error", Boolean(settings.lastPollStatus && !settings.lastPollStatus.ok));

  listEl.innerHTML = "";

  if (!watchlist.length) {
    const empty = document.createElement("li");
    empty.className = "emptyState";
    empty.textContent = "No one on your watchlist yet.";
    listEl.append(empty);
  }

  for (const entry of watchlist) {
    const li = document.createElement("li");

    const nameWrap = document.createElement("span");
    nameWrap.className = "entryName";

    const link = document.createElement("a");
    link.href = profileUrl(entry.userId);
    link.target = "_blank";
    link.textContent = entry.username;

    nameWrap.append(studDot("gray"), link);

    const actions = document.createElement("span");
    actions.className = "entryActions";

    const blockBtn = document.createElement("button");
    blockBtn.className = "btn";
    blockBtn.textContent = "Block/Report";
    blockBtn.title = "Opens their Roblox profile so you can block or report them";
    blockBtn.addEventListener("click", () => blockUser(entry.userId));

    const removeBtn = document.createElement("button");
    removeBtn.className = "btn btnGhost";
    removeBtn.textContent = "Remove";
    removeBtn.addEventListener("click", async () => {
      await removeFromWatchlist(entry.userId);
      render();
    });

    actions.append(blockBtn, removeBtn);
    li.append(nameWrap, actions);
    listEl.append(li);
  }
}

addBtn.addEventListener("click", async () => {
  addError.textContent = "";
  const username = usernameInput.value.trim();
  if (!username) return;

  try {
    const resolved = await resolveUserId(username);
    await addToWatchlist({ userId: resolved.userId, username: resolved.username });
    usernameInput.value = "";
    render();
  } catch (err) {
    addError.textContent = err.message;
  }
});

monitoringToggle.addEventListener("change", async () => {
  await updateSettings({ monitoringEnabled: monitoringToggle.checked });
});

manualGameBtn.addEventListener("click", async () => {
  const placeId = Number(manualPlaceId.value.trim());
  if (!placeId) return;
  await chrome.runtime.sendMessage({
    type: "SET_CURRENT_GAME_MANUAL",
    placeId,
  });
  manualPlaceId.value = "";
  render();
});

clearGameBtn.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "CLEAR_CURRENT_GAME" });
  render();
});

render();
