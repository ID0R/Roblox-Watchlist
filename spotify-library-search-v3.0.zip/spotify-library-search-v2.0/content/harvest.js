(() => {
"use strict";
const MAX_SWEEP_MS = 180_000;
const SETTLE_MAX_MS = 260;
const POLL_MS = 16;
/*
 * A real page under real load (lazy images, other extensions, a slow
 * machine) drops and delays renders far more than the synthetic test
 * environment does. STAGNANT_LIMIT and the row-read retry budget were tuned
 * against the fake DOM, where "flaky" means "1 in 3 renders vanishes
 * instantly" - real drop-outs run longer than that. Giving each stall more
 * patience before giving up is cheap (it only costs time on the passes that
 * would otherwise have produced a false "unreadable"), and directly trades
 * against the harvest reporting an index that is honestly smaller than the
 * real list.
 */
const STAGNANT_LIMIT = 14;
const ROW_READ_RETRIES = 12;
const ROW_READ_RETRY_MS = 160;
/* A contiguous run of missing rows this long or longer gets a real
 * re-scroll through every step of it, not sparse sampling — see gapRound(). */
const LARGE_GAP_THRESHOLD = 40;
/* Sparse sampling still applies to small, isolated gaps: one scroll per
 * cluster, spaced so the render window each scroll produces should bridge
 * the gap between targets. */
const GAP_CLUSTER_SPAN = 8;

function findGrid() {
  const candidates = [
    '[data-testid="playlist-tracklist"]',
    '[data-testid="track-list"]',
    'main div[role="grid"][aria-rowcount]',
    'main div[role="grid"]',
    'main div[role="treegrid"]'
  ];
  for (const selector of candidates) {
    const node = document.querySelector(selector);
    if (node && node.getBoundingClientRect().height > 0) return node;
  }
  return null;
}

function findScroller(from) {
  let node = from;
  while (node && node !== document.body) {
    const style = getComputedStyle(node);
    if (
      /(auto|scroll|overlay)/.test(style.overflowY) &&
      node.scrollHeight > node.clientHeight + 40
    ) {
      return node;
    }
    node = node.parentElement;
  }
  const root = document.scrollingElement || document.documentElement;
  return root.scrollHeight > root.clientHeight + 40 ? root : null;
}

function readTotal(grid) {
  const count = Number(grid?.getAttribute("aria-rowcount"));
  if (Number.isFinite(count) && count > 1) return count - 1;
  return 0;
}

function rows(grid) {
  return grid.querySelectorAll(
    '[role="row"][aria-rowindex], [data-testid="tracklist-row"]'
  );
}

const DURATION = /^(\d{1,2}):([0-5]\d)$/;

function parseDuration(text) {
  const match = DURATION.exec(String(text || "").trim());
  if (!match) return 0;
  return (Number(match[1]) * 60 + Number(match[2])) * 1000;
}

const RELATIVE = /^(\d+)\s+(second|minute|hour|day|week|month|year)s?\s+ago$/i;
const RELATIVE_MS = {
  second: 1000, minute: 60_000, hour: 3_600_000, day: 86_400_000,
  week: 604_800_000, month: 2_629_800_000, year: 31_557_600_000
};

function parseAdded(text) {
  const value = String(text || "").trim();
  if (!value) return null;
  if (/^today$/i.test(value)) return new Date().toISOString();
  if (/^yesterday$/i.test(value)) return new Date(Date.now() - 86_400_000).toISOString();
  const relative = RELATIVE.exec(value);
  if (relative) {
    const ms = RELATIVE_MS[relative[2].toLowerCase()] * Number(relative[1]);
    return new Date(Date.now() - ms).toISOString();
  }
  const parsed = Date.parse(value);
  if (!Number.isNaN(parsed)) return new Date(parsed).toISOString();
  return null;
}

function idFrom(href, kind) {
  const match = new RegExp(`/${kind}/([A-Za-z0-9]+)`).exec(String(href || ""));
  return match ? match[1] : null;
}

function cleanText(node) {
  return (node?.textContent || "").replace(/\s+/g, " ").trim();
}

function readRow(row) {
  const rowIndex = Number(row.getAttribute("aria-rowindex"));
  if (!Number.isFinite(rowIndex) || rowIndex < 2) return null;
  const position = rowIndex - 2;
  const trackLink =
    row.querySelector('[data-testid="internal-track-link"]') ||
    row.querySelector('a[href*="/track/"]') ||
    row.querySelector('a[href*="/episode/"]') ||
    row.querySelector('a[href*="/show/"]');
  const href = trackLink?.getAttribute("href") || "";
  const id = idFrom(href, "track") || idFrom(href, "episode") || idFrom(href, "show");
  const artistLinks = [...row.querySelectorAll('a[href*="/artist/"]')];
  const artists = artistLinks.map(cleanText).filter(Boolean);
  const albumLink = row.querySelector('a[href*="/album/"]');
  let name = cleanText(trackLink);
  let album = cleanText(albumLink);
  const cells = [...row.querySelectorAll('[role="gridcell"]')];
  if (!name) {
    for (const cell of cells) {
      const lines = (cell.innerText || "").split("\n").map((s) => s.trim()).filter(Boolean);
      if (!lines.length) continue;
      name = lines[0];
      if (!artists.length && lines[1]) artists.push(lines[1]);
      break;
    }
  }
  if (!name) return null;
  let duration = 0;
  let added = null;
  for (let i = cells.length - 1; i >= 0; i--) {
    const text = cleanText(cells[i]);
    if (!text) continue;
    if (!duration && DURATION.test(text)) { duration = parseDuration(text); continue; }
    if (!added && duration) {
      const parsedDate = parseAdded(text);
      if (parsedDate) added = parsedDate;
    }
  }
  if (!album) {
    const middle = cells[2];
    const text = cleanText(middle);
    if (text && !DURATION.test(text)) album = text;
  }
  const image = row.querySelector("img")?.getAttribute("src") || "";
  return { position, id: id || `local:${position}`, name, artists, album, image, duration, added, isLocal: !id };
}

function collect(grid, into) {
  let added = 0;
  for (const row of rows(grid)) {
    const rowIndex = Number(row.getAttribute("aria-rowindex"));
    if (!Number.isFinite(rowIndex) || into.has(rowIndex)) continue;
    const record = readRow(row);
    if (!record) continue;
    into.set(rowIndex, record);
    added++;
  }
  return added;
}

async function readMissingFromDom(grid, into, missing) {
  for (let attempt = 0; attempt < ROW_READ_RETRIES && missing.size; attempt++) {
    for (const row of rows(grid)) {
      const rowIndex = Number(row.getAttribute("aria-rowindex"));
      if (!Number.isFinite(rowIndex) || !missing.has(rowIndex)) continue;
      if (into.has(rowIndex)) { missing.delete(rowIndex); continue; }
      const record = readRow(row);
      if (!record) continue;
      into.set(rowIndex, record);
      missing.delete(rowIndex);
    }
    if (missing.size) await waitMs(ROW_READ_RETRY_MS);
  }
  return missing;
}

function frame() {
  return new Promise((resolve) => requestAnimationFrame(() => resolve()));
}

function waitMs(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function rowWindow(grid) {
  let first = 0, last = 0, count = 0;
  for (const row of rows(grid)) {
    const index = Number(row.getAttribute("aria-rowindex"));
    if (!Number.isFinite(index)) continue;
    if (!count || index < first) first = index;
    if (!count || index > last) last = index;
    count++;
  }
  return count ? `${first}:${last}:${count}` : "empty";
}

function arm(grid, signature, timeout = SETTLE_MAX_MS) {
  return new Promise((resolve) => {
    let done = false;
    const finish = async () => {
      if (done) return;
      done = true;
      observer.disconnect();
      clearTimeout(timer);
      clearInterval(poll);
      await frame();
      resolve();
    };
    const observer = new MutationObserver(finish);
    observer.observe(grid, { childList: true, subtree: true, attributes: true, attributeFilter: ["aria-rowindex"] });
    const poll = setInterval(() => { if (rowWindow(grid) !== signature) finish(); }, POLL_MS);
    const timer = setTimeout(finish, timeout);
  });
}

async function stepAndSettle(grid, action, timeout) {
  const signature = rowWindow(grid);
  const settled = arm(grid, signature, timeout);
  action();
  await settled;
}

function atBottom(scroller) {
  return scroller.scrollTop + scroller.clientHeight >= scroller.scrollHeight - 4;
}

function measureRowHeight(grid) {
  for (const row of rows(grid)) {
    const height = row.getBoundingClientRect().height;
    if (height > 20) return height;
  }
  return 0;
}

async function linearPass(args) {
  const { grid, scroller, found, total, report, aborted } = args;
  await stepAndSettle(grid, () => { scroller.scrollTop = 0; });
  collect(grid, found);
  report();
  let stagnant = 0;
  let lastSize = found.size;
  while (!aborted()) {
    if (total && found.size >= total) break;
    const wasAtBottom = atBottom(scroller);
    await stepAndSettle(grid, () => { scroller.scrollTop += Math.max(240, scroller.clientHeight * 0.8); });
    collect(grid, found);
    report();
    if (wasAtBottom) break;
    if (found.size === lastSize) {
      stagnant++;
      if (stagnant >= STAGNANT_LIMIT) break;
    } else {
      stagnant = 0;
      lastSize = found.size;
    }
  }
  await arm(grid, rowWindow(grid));
  collect(grid, found);
  report();
}

/*
 * Missing rows come in two shapes, and one strategy does not serve both.
 *
 * A handful of scattered misses (a render that dropped one screenful here
 * and there) is what the old sparse-sample-every-8-rows approach was built
 * for: scroll near each one, and whatever window that scroll renders
 * usually covers its neighbours too.
 *
 * A long CONTIGUOUS run of misses - dozens or hundreds of rows in a row
 * that never rendered on the first pass - is a different problem. Sampling
 * points 8 rows apart across a 300-row hole assumes each sampled scroll's
 * render window is wide enough to bridge the gap to the next sample. On a
 * real page under real load that assumption is exactly what breaks, and the
 * result is a harvest that reports "complete" while quietly missing a real
 * block of tracks (or marks that whole block "unreadable" — accounted for
 * on paper, absent from the index). So a run past LARGE_GAP_THRESHOLD gets
 * a genuine re-sweep: scroll through every step of it, the same way the
 * first linear pass would have, rather than hoping a few sample points
 * happen to cover it.
 */
async function gapRound(args) {
  const { grid, scroller, found, unreadable, total, deadline, signal, report, aborted } = args;
  const missing = [];
  for (let rowIndex = 2; rowIndex <= total + 1; rowIndex++) {
    if (!found.has(rowIndex) && !unreadable.has(rowIndex)) missing.push(rowIndex);
  }
  if (!missing.length) return;

  const runs = [];
  for (const rowIndex of missing) {
    const run = runs[runs.length - 1];
    if (run && rowIndex - run.end <= 1) run.end = rowIndex;
    else runs.push({ start: rowIndex, end: rowIndex });
  }

  for (const run of runs) {
    if (aborted() || signal?.aborted || Date.now() > deadline) return;
    const span = run.end - run.start + 1;
    if (span >= LARGE_GAP_THRESHOLD) {
      await sweepRun(args, run);
    } else {
      await sampleRun(args, run);
    }
  }
}

async function sweepRun(args, run) {
  const { grid, scroller, found, report, aborted, signal, deadline } = args;
  const rowHeight = measureRowHeight(grid) || 56;
  let offset = Math.max(0, (run.start - 2) * rowHeight - scroller.clientHeight / 2);
  const bottom = (run.end - 2) * rowHeight + scroller.clientHeight / 2;
  let stagnant = 0;
  let lastSize = found.size;
  while (offset < bottom) {
    if (aborted() || signal?.aborted || Date.now() > deadline) return;
    await stepAndSettle(grid, () => { scroller.scrollTop = offset; });
    collect(grid, found);
    report();
    if (found.size === lastSize) {
      stagnant++;
      /* Roughly double the patience of the main linear pass's stall limit:
       * this is already the second look at rows that failed once, so a
       * slow render here is more likely than in the first pass, not less. */
      if (stagnant >= STAGNANT_LIMIT * 2) break;
    } else {
      stagnant = 0;
      lastSize = found.size;
    }
    offset += Math.max(180, scroller.clientHeight * 0.6);
  }
  await arm(grid, rowWindow(grid));
  collect(grid, found);
  report();
}

async function sampleRun(args, run) {
  const { grid, scroller, found, unreadable, deadline, signal, report, aborted } = args;
  const rowHeight = measureRowHeight(grid) || 56;
  const targets = [];
  for (let rowIndex = run.start; rowIndex <= run.end; rowIndex += GAP_CLUSTER_SPAN + 1) {
    targets.push(rowIndex);
  }
  if (targets[targets.length - 1] !== run.end) targets.push(run.end);
  for (const rowIndex of targets) {
    if (aborted() || signal?.aborted || Date.now() > deadline) return;
    const offset = Math.max(0, (rowIndex - 2) * rowHeight - scroller.clientHeight / 2);
    await stepAndSettle(grid, () => { scroller.scrollTop = offset; });
    collect(grid, found);
    report();
    if (found.has(rowIndex)) continue;
    const still = await readMissingFromDom(grid, found, new Set([rowIndex]));
    if (still.size) unreadable.add(rowIndex);
    report();
  }
}

async function harvest({ onProgress, signal } = {}) {
  const grid = findGrid();
  if (!grid) throw new Error("NO_TRACKLIST");
  const total = readTotal(grid);
  const scroller = findScroller(grid);
  if (!scroller) {
    const visible = new Map();
    collect(grid, visible);
    const records = [...visible.entries()].sort((a, b) => a[0] - b[0]).map(([, record]) => record);
    const complete = !total || records.length >= total;
    onProgress?.({ collected: records.length, total: total || records.length, complete });
    return { records, total: total || records.length, complete, unreadable: 0, aborted: false };
  }
  const found = new Map();
  const unreadable = new Set();
  const deadline = Date.now() + MAX_SWEEP_MS;
  const origin = scroller.scrollTop;
  const report = () => onProgress?.({ collected: found.size, total, complete: false });
  const aborted = () => signal?.aborted || Date.now() > deadline;
  const unaccounted = () => total && found.size + unreadable.size < total;
  const args = { grid, scroller, found, unreadable, total, deadline, signal, report, aborted };
  try {
    await linearPass(args);
    if (unaccounted() && !aborted()) await gapRound(args);
    if (unaccounted() && !aborted()) {
      await linearPass(args);
      if (unaccounted() && !aborted()) await gapRound(args);
    }
  } finally {
    scroller.scrollTop = origin;
  }
  const records = [...found.entries()].sort((a, b) => a[0] - b[0]).map(([, record]) => record);
  const complete = Boolean(total) ? found.size + unreadable.size >= total : records.length > 0;
  onProgress?.({ collected: records.length, total, complete });
  return { records, total: total || records.length, complete, unreadable: unreadable.size, aborted: Boolean(signal?.aborted) };
}

async function harvestPlaylistDirectory({ signal } = {}) {
  const container = findSidebarList();
  const found = new Map();
  const sweep = () => {
    for (const link of document.querySelectorAll('a[href^="/playlist/"]')) {
      const id = idFrom(link.getAttribute("href"), "playlist");
      if (!id || found.has(id)) continue;
      const name = cleanText(link.querySelector("p, span, div")) || link.getAttribute("aria-label") || cleanText(link);
      if (!name) continue;
      found.set(id, { id, name });
    }
  };
  sweep();
  const scroller = container ? findScroller(container) : null;
  if (scroller) {
    const origin = scroller.scrollTop;
    const deadline = Date.now() + 20_000;
    try {
      await stepAndSettle(container, () => { scroller.scrollTop = 0; });
      sweep();
      let stagnant = 0;
      let lastSize = found.size;
      while (!signal?.aborted && Date.now() < deadline) {
        const wasAtBottom = atBottom(scroller);
        await stepAndSettle(container, () => { scroller.scrollTop += Math.max(200, scroller.clientHeight * 0.8); });
        sweep();
        if (wasAtBottom) break;
        if (found.size === lastSize) {
          stagnant++;
          if (stagnant >= 4) break;
        } else {
          stagnant = 0;
          lastSize = found.size;
        }
      }
    } finally {
      scroller.scrollTop = origin;
    }
  }
  return [...found.values()];
}

function findSidebarList() {
  const candidates = ['[data-testid="rootlist"]', 'nav [role="list"]', '[aria-label="Your Library"]', 'nav'];
  for (const selector of candidates) {
    const node = document.querySelector(selector);
    if (node && node.querySelector('a[href^="/playlist/"]')) return node;
  }
  return null;
}

function readTitle() {
  const heading = document.querySelector('[data-testid="entityTitle"] h1') || document.querySelector("main h1");
  return cleanText(heading);
}

function describePage() {
  const path = location.pathname;
  const grid = findGrid();
  const total = grid ? readTotal(grid) : 0;
  if (path === "/collection/tracks") {
    return { type: "liked", id: null, label: "Liked Songs", total, hasGrid: Boolean(grid) };
  }
  const playlist = /^\/playlist\/([^/?#]+)/.exec(path);
  if (playlist) {
    return { type: "playlist", id: decodeURIComponent(playlist[1]), label: readTitle() || "Playlist", total, hasGrid: Boolean(grid) };
  }
  return { type: null, id: null, label: "", total: 0, hasGrid: false };
}

window.SLSHarvest = {
  harvest, harvestPlaylistDirectory, describePage, findGrid, findScroller, readTotal, readRow, parseAdded, parseDuration
};
})();