"use strict";
/*
 * Service worker entry point.
 *
 * What is no longer here is the point of this version. There is no OAuth, no
 * session capture, no Spotify client, no rate-limit gate, no paging, no build
 * orchestration, no keepalive port and no long-running operation of any kind.
 * Every handler in this file completes in milliseconds, which means the
 * worker's eviction — the thing that produced a spinner nobody could
 * interpret in v1.2 — is now simply irrelevant. It can be evicted between any
 * two messages and nothing is lost.
 *
 * There is also no INGEST_PARTIAL handler any more. Mid-harvest snapshots
 * were screen-sized non-snapshots of the library that raced each other into
 * the index; the index is now written once per context, complete, or not at
 * all. Simpler state machine, and the index always means what it says.
 *
 * The worker's entire job is: hold the index, match against it, answer.
 */
importScripts("../shared/text.js", "../shared/query.js", "./store.js");

const Text = self.SLSText;
const Query = self.SLSQuery;
const Store = self.SLSStore;

const MAX_RESULTS = 20000;
const FUZZY_THRESHOLD = 4;
const SETTINGS_KEY = "settings";
const DEFAULT_SETTINGS = {
  fuzzySearch: true,
  filterList: true,
  highlightRows: true,
  autoIndexOnOpen: true,
  showSupportLink: true,
  savedFilters: []
};

const HANDLERS = {
  GET_STATE: handleGetState,
  INGEST: handleIngest,
  SET_PLAYLIST_DIRECTORY: handleSetPlaylistDirectory,
  GET_CONTEXT_STATUS: handleContextStatus,
  SEARCH: handleSearch,
  FIND_PLAYLISTS_FOR_TRACK: handleFindPlaylistsForTrack,
  EXPORT_CONTEXT: handleExportContext,
  GET_SETTINGS: handleGetSettings,
  SET_SETTINGS: handleSetSettings,
  SAVE_FILTER: handleSaveFilter,
  DELETE_FILTER: handleDeleteFilter,
  GET_STORAGE_REPORT: handleStorageReport,
  CLEAR_INDEXES: handleClearIndexes,
  CLEAR_EVERYTHING: handleClearEverything,
  START_SWEEP: handleStartSweep,
  OPEN_OPTIONS: handleOpenOptions,
  OPEN_SPOTIFY: handleOpenSpotify
};

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handler = HANDLERS[message?.type];
  if (!handler) {
    sendResponse({ ok: false, error: "UNKNOWN_MESSAGE" });
    return false;
  }
  handler(message, sender)
    .then((result) => sendResponse({ ok: true, ...result }))
    .catch((error) => {
      const code = String(error?.message || error || "UNKNOWN_ERROR");
      if (code !== "INVALID_CONTEXT") console.error("[Library Search]", error);
      sendResponse({ ok: false, error: code });
    });
  return true;
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "focus-search") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "FOCUS_SEARCH" }).catch(() => {});
});

chrome.runtime.onInstalled.addListener(async (details) => {
  await migrate(details);
  createContextMenu();
});
chrome.runtime.onStartup?.addListener(createContextMenu);

/*
 * v2.0 changed where records come from and what they contain, so nothing from
 * an earlier version can be read. Clearing it out is not housekeeping — an
 * index built from an API response has a release year and this one does not,
 * and a half-migrated index is worse than an absent one because it looks fine.
 */
async function migrate(details) {
  if (details?.reason !== "update" && details?.reason !== "install") return;
  const all = await chrome.storage.local.get(null);
  const dead = Object.keys(all).filter(
    (key) =>
      key.startsWith("idx.") ||
      key.startsWith("auth.") ||
      key.startsWith("session.") ||
      key.startsWith("api.") ||
      key.startsWith("libraryCache:") ||
      key === "build.state" ||
      key === "sweep"
  );
  if (dead.length) await chrome.storage.local.remove(dead);
  /* Settings survive, minus the keys that no longer mean anything.
   * `resultLimit` is gone with them: capping results is the bug, not a
   * preference. */
  const settings = all[SETTINGS_KEY];
  if (settings) {
    const {
      dataSource,
      includeFollowed,
      apiPlaybackFallback,
      resultLimit,
      ...keep
    } = settings;
    await chrome.storage.local.set({ [SETTINGS_KEY]: keep });
  }
}

/* ------------------------------- settings ------------------------------- */
async function getSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return { ...DEFAULT_SETTINGS, ...(stored[SETTINGS_KEY] || {}) };
}
async function handleGetSettings() {
  return { settings: await getSettings() };
}
async function handleSetSettings(message) {
  const settings = { ...(await getSettings()), ...(message.settings || {}) };
  await chrome.storage.local.set({ [SETTINGS_KEY]: settings });
  return { settings };
}
async function handleSaveFilter(message) {
  const query = String(message.query || "").trim();
  if (!query) throw new Error("INVALID_FILTER");
  const settings = await getSettings();
  const filters = Array.isArray(settings.savedFilters) ? [...settings.savedFilters] : [];
  if (filters.some((filter) => filter.query === query)) return { settings, filters };
  const name = String(message.name || query).trim().slice(0, 40) || query.slice(0, 40);
  filters.push({ id: `f${Date.now().toString(36)}`, name, query });
  const next = { ...settings, savedFilters: filters.slice(0, 24) };
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  return { settings: next, filters: next.savedFilters };
}
async function handleDeleteFilter(message) {
  const settings = await getSettings();
  const filters = (settings.savedFilters || []).filter((f) => f.id !== message.id);
  const next = { ...settings, savedFilters: filters };
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  return { settings: next, filters };
}

/* ----------------------------- context menu ----------------------------- */
const WHERE_MENU_ID = "sls-where-is-this";

function createContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create(
      {
        id: WHERE_MENU_ID,
        title: "Which of my playlists is this in?",
        contexts: ["link"],
        targetUrlPatterns: ["*://open.spotify.com/track/*"]
      },
      () => void chrome.runtime.lastError
    );
  });
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== WHERE_MENU_ID || !tab?.id) return;
  const match = String(info.linkUrl || "").match(/\/track\/([A-Za-z0-9]+)/);
  if (!match) return;
  chrome.tabs
    .sendMessage(tab.id, { type: "SHOW_TRACK_PLAYLISTS", trackId: match[1] })
    .catch(() => {});
});

/* ------------------------------- ingest ------------------------------- */
function normalizeContext(context) {
  if (!context?.type) throw new Error("INVALID_CONTEXT");
  if (context.type === "liked") return { type: "liked", label: "Liked Songs" };
  if (context.type === "global") return { type: "global", label: "Your library" };
  if (context.type === "playlist") {
    if (!context.id) throw new Error("INVALID_CONTEXT");
    return { type: "playlist", id: context.id, label: context.label || "Playlist" };
  }
  throw new Error("INVALID_CONTEXT");
}

/*
 * A finished harvest. One message, one write, done. The caller only sends
 * these when the harvest accounted for every row on the page, so what lands
 * here is always a whole, position-true picture of one list.
 */
async function handleIngest(message) {
  const context = normalizeContext(message.context);
  const result = await Store.write(context, message.records, {
    total: message.total,
    complete: message.complete !== false
  });
  return result;
}

async function handleSetPlaylistDirectory(message) {
  const directory = await Store.setPlaylistDirectory(message.playlists);
  return { playlists: directory.playlists.length };
}

/* -------------------------------- state -------------------------------- */
async function handleGetState() {
  const [settings, directory, liked, global] = await Promise.all([
    getSettings(),
    Store.getPlaylistDirectory(),
    Store.getStatus({ type: "liked" }),
    Store.getStatus({ type: "global" })
  ]);
  return {
    settings,
    liked,
    global,
    playlistCount: directory?.playlists?.length || 0,
    playlistsUpdatedAt: directory?.updatedAt || null
  };
}

async function handleContextStatus(message) {
  const context = normalizeContext(message.context);
  return { status: await Store.getStatus(context) };
}

/* -------------------------------- search -------------------------------- */
function buildDuplicateIdSet(songs) {
  const seen = new Map();
  const duplicates = new Set();
  for (const song of songs) {
    /* Grouped by title + artist rather than id: the common real duplicate is
     * the same recording from a single and from an album. */
    const fingerprint = `${song._t}|${song._a}`;
    const previous = seen.get(fingerprint);
    if (previous) {
      duplicates.add(previous);
      duplicates.add(song.id);
    } else {
      seen.set(fingerprint, song.id);
    }
  }
  return duplicates;
}

function toResult(song, source) {
  return {
    id: song.id,
    index: song.i,
    name: song.n,
    artists: song.a,
    album: song.al,
    duration: song.d || 0,
    image: song.im || "",
    uri: Store.trackUri(song),
    url: Store.trackUrl(song),
    addedAt: song.ad,
    isLocal: Boolean(song.lo),
    source: source || null
  };
}

async function handleSearch(message) {
  const context = normalizeContext(message.context);
  const settings = await getSettings();
  const parsed = Query.parse(message.query || "");
  if (parsed.isEmpty) {
    return {
      ready: true,
      query: message.query || "",
      totalMatches: 0,
      indexedTotal: 0,
      results: [],
      chips: []
    };
  }
  const scopes =
    context.type === "global" ? await Store.loadGlobal() : await loadSingleScope(context);
  const indexedTotal = scopes.reduce((sum, scope) => sum + scope.songs.length, 0);
  if (!indexedTotal) {
    return {
      ready: false,
      query: message.query || "",
      totalMatches: 0,
      indexedTotal: 0,
      results: [],
      chips: Query.describe(parsed)
    };
  }
  const needsDupes = parsed.flags.has("dupe");
  /*
   * No limit means all of them. The UI asks for everything (limit 0) and
   * renders everything; a numeric limit is honoured only if a caller
   * explicitly passes one, and even then only as a message-size bound.
   */
  const requested = Number(message.limit);
  const limit =
    Number.isFinite(requested) && requested > 0
      ? Math.min(requested, MAX_RESULTS)
      : MAX_RESULTS;
  let ranked = collect(scopes, parsed, { allowFuzzy: false, needsDupes });
  /* Fuzzy is a fallback, not the default path — running it only when the
   * strict pass came up short keeps the common case exact and fast. */
  if (
    settings.fuzzySearch &&
    ranked.length < 3 &&
    parsed.terms.length &&
    parsed.terms.join("").length >= FUZZY_THRESHOLD
  ) {
    ranked = collect(scopes, parsed, { allowFuzzy: true, needsDupes });
  }
  ranked.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if (a.scopeIndex !== b.scopeIndex) return a.scopeIndex - b.scopeIndex;
    return a.song.i - b.song.i;
  });
  const first = ranked[0];
  return {
    ready: true,
    query: message.query || "",
    totalMatches: ranked.length,
    indexedTotal,
    firstMatchIndex: first ? first.song.i : null,
    chips: Query.describe(parsed),
    results: ranked.slice(0, limit).map((entry) => toResult(entry.song, entry.source))
  };
}

function collect(scopes, parsed, { allowFuzzy, needsDupes }) {
  const ranked = [];
  for (let scopeIndex = 0; scopeIndex < scopes.length; scopeIndex++) {
    const scope = scopes[scopeIndex];
    const options = {
      allowFuzzy,
      playlistName: scope.labelNorm,
      dupeIds: needsDupes ? getDupeIds(scope) : null
    };
    for (const song of scope.songs) {
      if (allowFuzzy) ensureTokens(song);
      const score = Query.scoreSong(song, parsed, options);
      if (score > 0) ranked.push({ song, score, scopeIndex, source: scope.label });
    }
  }
  return ranked;
}

function ensureTokens(song) {
  if (!song.ts) song.ts = song._t ? song._t.split(" ") : [];
  if (!song.as) song.as = song._a ? song._a.split(" ") : [];
}

function getDupeIds(scope) {
  if (!scope._dupes) scope._dupes = buildDuplicateIdSet(scope.songs);
  return scope._dupes;
}

async function loadSingleScope(context) {
  const entry = await Store.load(context);
  if (!entry?.songs.length) return [];
  const label = entry.meta.label || context.label || "";
  return [{ context, label, labelNorm: Text.normalize(label), songs: entry.songs }];
}

async function handleFindPlaylistsForTrack(message) {
  const trackId = String(message.trackId || "");
  if (!trackId) throw new Error("INVALID_TRACK");
  const scopes = await Store.loadGlobal();
  const found = [];
  for (const scope of scopes) {
    const hit = scope.songs.find((song) => song.id === trackId);
    if (!hit) continue;
    found.push({
      label: scope.label,
      context: scope.context,
      position: hit.i + 1,
      addedAt: hit.ad
    });
  }
  return { trackId, playlists: found, scanned: scopes.length };
}

async function handleExportContext(message) {
  const context = normalizeContext(message.context);
  const scopes =
    context.type === "global" ? await Store.loadGlobal() : await loadSingleScope(context);
  const rows = [["source", "position", "title", "artists", "album", "added", "url"]];
  for (const scope of scopes) {
    for (const song of scope.songs) {
      rows.push([
        scope.label,
        String(song.i + 1),
        song.n,
        song.a.join("; "),
        song.al,
        song.ad || "",
        Store.trackUrl(song)
      ]);
    }
  }
  return { csv: toCsv(rows), rowCount: rows.length - 1 };
}

function toCsv(rows) {
  return rows
    .map((row) =>
      row
        .map((cell) => {
          const value = String(cell ?? "");
          return /[",\r\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
        })
        .join(",")
    )
    .join("\r\n");
}

/* ------------------------------ maintenance ------------------------------ */
async function handleStorageReport() {
  const usage = await Store.estimateUsage();
  const bytesInUse = await chrome.storage.local.getBytesInUse(null).catch(() => null);
  return { ...usage, bytesInUse };
}
async function handleClearIndexes() {
  await Store.clearAllIndexes();
  await chrome.storage.local.remove("sweep");
  return {};
}
async function handleClearEverything() {
  await chrome.storage.local.clear();
  return {};
}

/*
 * A sweep has to run in a page, because a page is where the library is. The
 * worker's only role is to find a Spotify tab, make sure it is on a page with
 * a track list, and ask it to start.
 */
async function handleStartSweep() {
  const url = "https://open.spotify.com/collection/tracks";
  let [tab] = await chrome.tabs.query({ url: "https://open.spotify.com/*" });
  if (tab?.id) {
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    tab = await chrome.tabs.create({ url, active: true });
    /* A fresh tab needs its content script to exist before it can be told
     * anything. The sweep is resumable, so a missed message is not fatal — but
     * waiting here means the common case works without the user retrying. */
    await new Promise((resolve) => setTimeout(resolve, 3500));
  }
  if (!tab?.id) throw new Error("NO_SPOTIFY_TAB");
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "START_SWEEP" });
  } catch {
    throw new Error("TAB_NOT_READY");
  }
  return { started: true };
}

async function handleOpenSpotify() {
  const url = "https://open.spotify.com/collection/tracks";
  const [existing] = await chrome.tabs.query({ url: "https://open.spotify.com/*" });
  if (existing?.id) {
    await chrome.tabs.update(existing.id, { active: true, url });
    await chrome.windows.update(existing.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
  return {};
}

async function handleOpenOptions() {
  await chrome.runtime.openOptionsPage();
  return {};
}