# Library Search for Spotify

Instant search across your Liked Songs and playlists, inside the Spotify web
player. Type, and the list on the page filters to your matches.

**No account. No Client ID. No developer app. No Premium. No setup at all.**
Install it, open Liked Songs, type.

---

## Install

1. Open `chrome://extensions` and turn on **Developer mode**.
2. **Load unpacked** → select this folder.
3. **If a Spotify tab was already open, reload it.** Chrome does not re-inject
   content scripts into existing tabs, so an old tab keeps running the old
   code. This is the single most common reason an update appears to do nothing.
4. Open <https://open.spotify.com/collection/tracks> and start typing, or
   press `/`.

The first time you open a playlist it reads the list — about half a second for
a thousand tracks — and everything after that is instant.

## How it works

Your browser already has your library. The Spotify web player fetched it, laid
it out and drew it on screen; those rows are what you are looking at. This
extension reads them.

That means **no credentials and no requests**. Nothing is fetched from
Spotify's servers, so there is no rate limit, no quota, nothing that can be
refused and nothing that stops working when a policy changes. The extension's
only permission for the web is the Spotify tab you already have open, and it
only reads it.

The one obstacle is that Spotify renders about fifteen rows at a time and
recycles them as you scroll, so the full list is never in the page at once. So
the extension scrolls the list, collects what appears, fills in anything it
missed, and puts your scroll position back. 935 tracks in under half a second;
10,000 in under three.

## What it does

- One compact search field in Spotify's own action bar, one dropdown beneath.
- **The list on the page filters as you type** — across the whole playlist, not
  just the rows on screen. Clearing the box restores Spotify's list untouched.
- **"Which of my playlists is this in?"** — a **Where?** button on every result
  and a right-click entry on any track link. Answers with playlist names and
  the track's position in each.
- **Saved smart filters** — name any query and pin it to the dropdown.
- **Scope toggle** — this list, or everything, with the source playlist shown
  on each result.
- **Query operators** — `artist:`, `album:`, `in:`, `added:>2024-06`,
  `is:dupe`, `is:local`, `"exact phrase"`, `-exclude`.
- **Typo tolerance**, used only when an exact search finds nothing.
- **Duplicate detection** and **CSV export**.
- `/` focuses the field. `Ctrl/Cmd+Shift+F` is remappable at
  `chrome://extensions/shortcuts`.

Search is never case sensitive and ignores accents and apostrophes: `travis`
finds **Travis Scott**, `cafe` finds **Café**, `dont` finds **Don't**.

## Searching every playlist

Playlists are indexed as you visit them, so this fills in on its own.

To do it in one go, use **Index my whole library** (options page, or the
toolbar popup). It opens each playlist in turn, reads it, and returns you to
where you started, with a progress card and a **Stop** button. It survives page
reloads — if it gets interrupted it picks up where it left off.

## What it can't do

Two honest limits, both consequences of reading the page instead of an API:

- **`year:` doesn't work.** Spotify never shows a release year in the track
  list, so there is nothing to read it from. Every other operator maps to a
  column you can see.
- **A playlist has to be visited to be read** — by you, or by the sweep.

## Permissions

| Permission | Why |
|---|---|
| `storage` | Your settings and the track index |
| `unlimitedStorage` | Large libraries exceed the 10 MB default |
| `contextMenus` | The right-click "which playlists is this in?" entry |
| `open.spotify.com` | Where the search box is added and the list is read |

That's the whole list. No `identity`, no `api.spotify.com`, no background
network access of any kind.

## Where your data goes

Nowhere. The index lives in `chrome.storage.local` on this device. No server,
no telemetry, no account.

## Troubleshooting

**Nothing happens after updating the extension** — reload the Spotify tab. See
step 3 above; this is almost always it.

**"Couldn't find the track list on this page"** — the page was still loading.
Press **Try again**.

**The list scrolls on its own for a moment** — that's the read. It puts you
back where you were.

**A count that looks short** — open the options page; if Liked Songs shows
"(partial)" the read was interrupted. Searching again re-reads it.

**Everything says "not read yet" straight after an update** — expected. An
update whose record format changed discards the old index rather than reading
it under new rules, because a half-understood index looks healthy and answers
wrongly. Open a playlist and it rebuilds in about half a second.

**No search field** — Spotify changed its action-bar markup *and* the
play-button fallback missed. The field falls back to a floating box below the
header; the logic is `findActionBar()` in `content/content.js`.

## Docs

- `docs/ARCHITECTURE.md` — how it works and why each decision was made
- `docs/REVIEW-v2.0.md` — the rewrite, the test results, the bugs they caught
- `docs/HISTORY.md` — five versions, four architectures, and the dead ends

## Support

A small coffee icon sits beside the search field, linking to
<https://ko-fi.com/id0r58858>. It can be turned off in settings.
