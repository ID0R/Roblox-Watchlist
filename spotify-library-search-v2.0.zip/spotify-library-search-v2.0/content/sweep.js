(() => {
  "use strict";

  /*
   * Indexing the whole library.
   *
   * One playlist is easy — it is on screen, scroll it. Every playlist is
   * harder, because the player only loads a playlist's tracks when you open
   * it. There is no way to read a playlist you are not looking at without
   * asking Spotify's servers for it, and asking is the thing that doesn't work
   * any more. So the extension does what a person would do: it opens each
   * playlist in turn and reads it.
   *
   * The awkward part is that opening a playlist may reload the page, which
   * destroys every variable in this file. Spotify's router usually handles a
   * client-side navigation, but "usually" is not something to build a
   * multi-minute operation on.
   *
   * So the sweep keeps no state in memory at all. Queue, position, results and
   * the page to return to all live in chrome.storage.local, and this module
   * re-reads them on every page load and picks up wherever it was. A full
   * reload mid-sweep costs two seconds, not the sweep. That is the same lesson
   * as the MV3 worker eviction from v1.2, applied to a different boundary:
   * anything that can be interrupted must be able to resume from disk.
   *
   * Everything here is cancellable and everything has a deadline.
   */

  const KEY = "sweep";
  const STEP_TIMEOUT_MS = 25_000;
  const NAV_TIMEOUT_MS = 12_000;

  /*
   * How many times one queue entry may be navigated to before it is written
   * off. The last navigation strategy is a full page load, which destroys this
   * module and resumes it from storage — so a playlist that can never become
   * the current page (deleted, made private, moved, or simply gone) used to
   * reload the tab forever, a few seconds apart, with a progress bar that never
   * moved. The counter lives in storage for the same reason the queue does: it
   * has to survive the reload it is counting.
   */
  const NAV_ATTEMPTS = 2;

  const Harvest = window.SLSHarvest;

  let running = false;
  let cancelled = false;

  /* ------------------------------- state ------------------------------- */

  async function read() {
    const stored = await chrome.storage.local.get(KEY);
    return stored[KEY] || null;
  }

  async function write(state) {
    await chrome.storage.local.set({ [KEY]: state });
    return state;
  }

  async function clear() {
    await chrome.storage.local.remove(KEY);
  }

  async function status() {
    const state = await read();
    if (!state?.active) return null;

    return {
      active: true,
      done: state.cursor,
      total: state.queue.length,
      label: state.queue[state.cursor]?.label || "",
      tracks: state.tracks || 0,
      failures: state.failures || []
    };
  }

  /* ------------------------------ starting ------------------------------ */

  /*
   * The playlist list comes from the sidebar, which is the only place the
   * player renders it without being asked. Liked Songs goes first because it
   * is the one everybody actually searches.
   */
  async function start({ onProgress } = {}) {
    const existing = await read();
    if (existing?.active) return existing;

    /* A cancelled sweep leaves the flag set. Without clearing it here the next
     * sweep the user starts aborts its own discovery pass before it begins. */
    cancelled = false;

    onProgress?.({ phase: "discovering", done: 0, total: 0, label: "Finding your playlists…" });

    /* Discovery scrolls the sidebar and can take a few seconds on a large
     * library, and the Stop button already exists by then — so it gets the
     * cancellation flag too, instead of running to completion regardless. */
    const playlists = await Harvest.harvestPlaylistDirectory({
      signal: {
        get aborted() {
          return cancelled;
        }
      }
    });

    const queue = [
      { type: "liked", id: null, label: "Liked Songs", path: "/collection/tracks" },
      ...playlists.map((playlist) => ({
        type: "playlist",
        id: playlist.id,
        label: playlist.name,
        path: `/playlist/${playlist.id}`
      }))
    ];

    const state = await write({
      active: true,
      queue,
      cursor: 0,
      attempts: 0,
      tracks: 0,
      failures: [],
      returnTo: location.pathname + location.search,
      startedAt: Date.now()
    });

    /* The directory is stored now rather than at the end, so "which playlists
     * is this in" and the Everything scope work against a partial sweep. */
    await send({
      type: "SET_PLAYLIST_DIRECTORY",
      playlists: playlists.map((playlist) => ({ ...playlist, total: 0 }))
    });

    return state;
  }

  async function cancel() {
    cancelled = true;

    const state = await read();
    if (state) await write({ ...state, active: false, cancelledAt: Date.now() });
  }

  /* ------------------------------- running ------------------------------- */

  /*
   * Called on every mount. If a sweep is in flight, this is the resume point —
   * including after a full page reload, where every other trace of the sweep
   * is gone.
   */
  async function resume({ onProgress, onDone } = {}) {
    if (running) return;

    const state = await read();
    if (!state?.active) return;

    running = true;
    cancelled = false;

    try {
      await run(state, { onProgress, onDone });
    } finally {
      running = false;
    }
  }

  async function run(initial, { onProgress, onDone }) {
    let state = initial;

    while (state?.active && state.cursor < state.queue.length) {
      if (cancelled) break;

      const target = state.queue[state.cursor];

      onProgress?.({
        phase: "indexing",
        done: state.cursor,
        total: state.queue.length,
        label: target.label,
        tracks: state.tracks
      });

      /* Already here? Then harvest. Otherwise go there — and if that turns
       * into a full page load, this function simply stops existing and the
       * next mount resumes from storage. */
      const page = Harvest.describePage();
      const onTarget =
        page.type === target.type && (target.type !== "playlist" || page.id === target.id);

      if (!onTarget) {
        const attempts = Number(state.attempts) || 0;

        /* Out of attempts: record it and move on, rather than reloading the
         * tab at this playlist for the rest of the day. */
        if (attempts >= NAV_ATTEMPTS) {
          state = await write({
            ...state,
            cursor: state.cursor + 1,
            attempts: 0,
            failures: [
              ...(state.failures || []),
              { label: target.label, error: "COULD_NOT_OPEN" }
            ].slice(0, 40)
          });

          continue;
        }

        state = await write({ ...state, attempts: attempts + 1 });

        const navigated = await navigate(target.path, target);
        if (!navigated) return;
      } else if (state.attempts) {
        /* Arrived. The count is per queue entry, not cumulative. */
        state = await write({ ...state, attempts: 0 });
      }

      let indexed = 0;

      try {
        indexed = await harvestCurrent(target, (progress) => {
          onProgress?.({
            phase: "indexing",
            done: state.cursor,
            total: state.queue.length,
            label: target.label,
            tracks: state.tracks + (progress.collected || 0)
          });
        });
      } catch (error) {
        state.failures = [
          ...(state.failures || []),
          { label: target.label, error: String(error?.message || error) }
        ].slice(0, 40);
      }

      state = await write({
        ...state,
        cursor: state.cursor + 1,
        attempts: 0,
        tracks: (state.tracks || 0) + indexed
      });
    }

    const finished = await read();

    if (finished) {
      await write({ ...finished, active: false, finishedAt: Date.now() });
    }

    onDone?.({
      tracks: finished?.tracks || 0,
      total: finished?.queue?.length || 0,
      failures: finished?.failures || [],
      cancelled
    });

    /* Put the user back on the page they started from. */
    const returnTo = finished?.returnTo;

    if (returnTo && location.pathname !== returnTo.split("?")[0] && !cancelled) {
      await navigate(returnTo, null);
    }

    await clear();
  }

  async function harvestCurrent(target, onProgress) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), STEP_TIMEOUT_MS);

    try {
      const result = await Harvest.harvest({ onProgress, signal: controller.signal });

      if (!result.records.length) return 0;

      await send({
        type: "INGEST",
        context: { type: target.type, id: target.id, label: target.label },
        records: result.records,
        total: result.total,
        complete: result.complete
      });

      return result.records.length;
    } finally {
      clearTimeout(timer);
    }
  }

  /* ----------------------------- navigation ----------------------------- */

  /*
   * Three ways to change page, cheapest first.
   *
   * A real click on a real link is best: it goes through the router the way
   * the player expects, keeps the page alive and takes milliseconds. Synthetic
   * history manipulation is the fallback — React Router listens for popstate,
   * so pushing and then announcing it usually works. A full navigation is the
   * last resort; it costs a reload but it always works, and the sweep is built
   * to survive one.
   */
  async function navigate(path, target) {
    const anchor = document.querySelector(`a[href="${cssEscape(path)}"]`);

    if (anchor) {
      anchor.click();
      if (await waitForPage(path, target)) return true;
    }

    try {
      history.pushState({}, "", path);
      window.dispatchEvent(new PopStateEvent("popstate", { state: {} }));

      if (await waitForPage(path, target)) return true;
    } catch {
      /* Fall through to the hard navigation. */
    }

    location.assign(path);
    return false;
  }

  function cssEscape(value) {
    return String(value).replace(/["\\]/g, "\\$&");
  }

  /*
   * Arriving is not the same as being ready. The URL changes immediately; the
   * tracklist for the new context appears later, and harvesting in between
   * reads the *previous* playlist's rows — which is how you end up with one
   * playlist's contents filed under another's name.
   *
   * So this waits for the page to both be the right one and have a grid with
   * rows in it.
   */
  function waitForPage(path, target) {
    const wanted = path.split("?")[0];
    const deadline = Date.now() + NAV_TIMEOUT_MS;

    return new Promise((resolve) => {
      const check = () => {
        if (cancelled) return resolve(false);

        if (location.pathname === wanted) {
          const page = Harvest.describePage();

          const matches =
            !target ||
            (page.type === target.type &&
              (target.type !== "playlist" || page.id === target.id));

          if (matches && page.hasGrid && Harvest.findGrid()?.querySelector('[role="row"]')) {
            /* One extra beat so the first screenful is real rows rather than
             * the skeleton placeholders Spotify paints first. */
            setTimeout(() => resolve(true), 260);
            return;
          }
        }

        if (Date.now() > deadline) return resolve(false);

        setTimeout(check, 160);
      };

      setTimeout(check, 120);
    });
  }

  async function send(message) {
    try {
      return (await chrome.runtime.sendMessage(message)) || { ok: false };
    } catch (error) {
      return { ok: false, error: String(error?.message || error) };
    }
  }

  window.SLSSweep = { start, cancel, resume, status, read, clear };
})();
