import {
  getWatchlist,
  getSettings,
  updateSettings,
  isNotified,
  markNotified,
  clearNotified,
} from "./lib/storage.js";
import { getPresence, profileUrl } from "./lib/roblox-api.js";

const ALARM_NAME = "poll-watchlist";
// How stale an auto-detected current game is allowed to get (in case the
// tab-close/navigate listeners below miss an edge case, e.g. browser crash).
const AUTO_GAME_MAX_AGE_MS = 20 * 60 * 1000;

chrome.runtime.onInstalled.addListener(async () => {
  const { pollIntervalMinutes } = await getSettings();
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: pollIntervalMinutes });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "CURRENT_GAME_DETECTED") {
    updateSettings({
      currentPlaceId: message.placeId,
      currentPlaceName: message.placeName,
      currentGameSource: "auto",
      currentGameTabId: sender.tab ? sender.tab.id : null,
      currentGameSetAt: Date.now(),
    }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === "SET_CURRENT_GAME_MANUAL") {
    updateSettings({
      currentPlaceId: message.placeId,
      currentPlaceName: message.placeName || `Place ${message.placeId}`,
      currentGameSource: "manual",
      currentGameTabId: null,
      currentGameSetAt: Date.now(),
    }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === "CLEAR_CURRENT_GAME") {
    updateSettings({
      currentPlaceId: null,
      currentPlaceName: null,
      currentGameSource: null,
      currentGameTabId: null,
      currentGameSetAt: null,
    }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === "SET_POLL_INTERVAL") {
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: message.minutes });
    sendResponse({ ok: true });
  }
});

// If the tab that auto-detected the current game closes, stop monitoring
// against a game the user may no longer be playing.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const settings = await getSettings();
  if (settings.currentGameSource === "auto" && settings.currentGameTabId === tabId) {
    await updateSettings({
      currentPlaceId: null,
      currentPlaceName: null,
      currentGameSource: null,
      currentGameTabId: null,
      currentGameSetAt: null,
    });
  }
});

// If that same tab navigates away from the game's page entirely, same deal.
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (!changeInfo.url) return;
  const settings = await getSettings();
  if (settings.currentGameSource !== "auto" || settings.currentGameTabId !== tabId) return;
  if (!/^https:\/\/www\.roblox\.com\/games\/\d+/.test(changeInfo.url)) {
    await updateSettings({
      currentPlaceId: null,
      currentPlaceName: null,
      currentGameSource: null,
      currentGameTabId: null,
      currentGameSetAt: null,
    });
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) pollWatchlist();
});

chrome.notifications.onClicked.addListener(async (notificationId) => {
  const match = notificationId.match(/^watchlist-(\d+)-/);
  if (!match) return;
  await chrome.tabs.create({ url: profileUrl(Number(match[1])), active: true });
  chrome.notifications.clear(notificationId);
});

async function pollWatchlist() {
  const settings = await getSettings();

  if (
    settings.currentGameSource === "auto" &&
    settings.currentGameSetAt &&
    Date.now() - settings.currentGameSetAt > AUTO_GAME_MAX_AGE_MS
  ) {
    await updateSettings({
      currentPlaceId: null,
      currentPlaceName: null,
      currentGameSource: null,
      currentGameTabId: null,
      currentGameSetAt: null,
    });
    return;
  }

  if (!settings.monitoringEnabled || !settings.currentPlaceId) return;

  const watchlist = await getWatchlist();
  if (!watchlist.length) return;

  const userIds = watchlist.map((u) => u.userId);

  let presences;
  try {
    presences = await getPresence(userIds);
    await updateSettings({ lastPollStatus: { ok: true, message: "OK", at: Date.now() } });
  } catch (err) {
    console.error("[watchlist] presence poll failed", err);
    await updateSettings({
      lastPollStatus: { ok: false, message: err.message, at: Date.now() },
    });
    return;
  }

  const currentPlaceId = settings.currentPlaceId;
  const presentUserIds = new Set();

  for (const presence of presences) {
    const inTargetGame =
      presence.placeId === currentPlaceId || presence.rootPlaceId === currentPlaceId;

    if (inTargetGame) {
      presentUserIds.add(presence.userId);
      if (!(await isNotified(presence.userId))) {
        const entry = watchlist.find((u) => u.userId === presence.userId);
        if (entry) notify(entry);
        await markNotified(presence.userId);
      }
    }
  }

  // Anyone previously notified who's no longer showing as present gets
  // cleared, so a later rejoin fires a fresh notification.
  for (const userId of userIds) {
    if (!presentUserIds.has(userId) && (await isNotified(userId))) {
      await clearNotified(userId);
    }
  }
}

function notify(entry) {
  chrome.notifications.create(`watchlist-${entry.userId}-${Date.now()}`, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: "Watchlist alert",
    message: `${entry.username} just joined your game. Click to view profile.`,
    priority: 2,
  });
}
