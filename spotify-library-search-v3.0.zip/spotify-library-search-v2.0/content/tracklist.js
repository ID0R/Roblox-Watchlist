(() => {
"use strict";
/*
* In-place list filtering.
*
* The obvious implementation — hide the rows that don't match — does not
* work on Spotify. The tracklist is virtualised: only the ~30 rows around
* the scroll position exist in the DOM at all, and their geometry is what
* the virtualiser uses to decide what to render next. Hiding rows filters
* the thirty you happen to be looking at and corrupts the scroll maths while
* doing it.
*
* So this doesn't filter Spotify's list. It stands in for it: the native
* grid is hidden (never removed, never rewritten) and a list of our own is
* rendered in its place, drawn from the local index, showing every match in
* the whole library rather than every match on screen.
*
* Clicking a row restores the native list first and then plays through it,
* so playback and queue behaviour stay exactly Spotify's.
*/
/*
* Effectively uncapped. The stand-in list exists to show every match; a 300
* row ceiling is what made a big artist search look truncated. Rows are
* plain DOM with lazy images, so thousands render fine, and the ceiling that
* remains is only a guard against pathological queries.
*/
const MAX_ROWS = 10000;
const state = {
active: false,
grid: null,
list: null,
onActivate: null,
onClear: null
};
/* ------------------------------ finding ------------------------------ */
function findGrid() {
const selectors = [
'[data-testid="playlist-tracklist"]',
'[data-testid="track-list"]',
'main div[role="grid"][aria-label]',
'main div[role="grid"]',
'main div[role="treegrid"]'
];
for (const selector of selectors) {
const node = document.querySelector(selector);
if (node && node.getBoundingClientRect().height > 0) return node;
}
return null;
}
/* ------------------------------ rendering ------------------------------ */
function formatDuration(ms) {
const total = Math.round(Number(ms || 0) / 1000);
if (!total) return "";
const minutes = Math.floor(total / 60);
const seconds = total % 60;
return `${minutes}:${String(seconds).padStart(2, "0")}`;
}
function formatAdded(value) {
if (!value) return "";
const date = new Date(value);
if (Number.isNaN(date.getTime())) return "";
return date.toLocaleDateString(undefined, {
year: "numeric",
month: "short",
day: "numeric"
});
}
function buildHeader(summary) {
const header = document.createElement("div");
header.className = "sls-fl-head";
const label = document.createElement("span");
label.className = "sls-fl-label";
label.textContent = summary;
const clear = document.createElement("button");
clear.type = "button";
clear.className = "sls-fl-clear";
clear.textContent = "Clear filter";
clear.addEventListener("click", (event) => {
event.preventDefault();
event.stopPropagation();
if (state.onClear) state.onClear();
});
header.append(label, clear);
return header;
}
function buildColumns() {
const row = document.createElement("div");
row.className = "sls-fl-columns";
row.setAttribute("aria-hidden", "true");
for (const [text, cls] of [
["#", "sls-fl-index"],
["Title", "sls-fl-title-col"],
["Album", "sls-fl-album"],
["Date added", "sls-fl-added"],
["", "sls-fl-duration"]
]) {
const cell = document.createElement("span");
cell.className = cls;
cell.textContent = text;
row.appendChild(cell);
}
return row;
}
function buildRow(track, position) {
const row = document.createElement("div");
row.className = "sls-fl-row";
row.setAttribute("role", "row");
row.tabIndex = 0;
row.dataset.slsIndex = String(position);
const index = document.createElement("span");
index.className = "sls-fl-index";
index.textContent = String((track.index ?? 0) + 1);
const title = document.createElement("span");
title.className = "sls-fl-title";
if (track.image) {
const art = document.createElement("img");
art.src = track.image;
art.alt = "";
art.loading = "lazy";
art.decoding = "async";
art.referrerPolicy = "no-referrer";
title.appendChild(art);
}
const text = document.createElement("span");
text.className = "sls-fl-text";
const name = document.createElement("span");
name.className = "sls-fl-name";
name.textContent = track.name || "";
const artists = document.createElement("span");
artists.className = "sls-fl-artists";
artists.textContent = (track.artists || []).join(", ");
text.append(name, artists);
title.appendChild(text);
const album = document.createElement("span");
album.className = "sls-fl-album";
album.textContent = track.album || "";
const added = document.createElement("span");
added.className = "sls-fl-added";
added.textContent = formatAdded(track.addedAt);
const duration = document.createElement("span");
duration.className = "sls-fl-duration";
duration.textContent = formatDuration(track.duration);
row.append(index, title, album, added, duration);
if (track.source) {
const badge = document.createElement("span");
badge.className = "sls-fl-source";
badge.textContent = track.source;
title.appendChild(badge);
}
return row;
}
/* ------------------------------- control ------------------------------- */
function apply(results, { totalMatches, indexedTotal, query, indexing }) {
const grid = findGrid();
if (!grid) return false;
/* Spotify re-renders constantly; if it swapped the grid out from under an
* active filter, start again against the new one. */
if (state.active && state.grid !== grid) restore();
state.grid = grid;
grid.classList.add("sls-fl-hidden");
if (!state.list || !state.list.isConnected) {
state.list = document.createElement("div");
state.list.className = "sls-fl";
grid.parentElement.insertBefore(state.list, grid);
}
state.list.textContent = "";
const shown = results.slice(0, MAX_ROWS);
const summary = !totalMatches
? indexing
? `Still indexing — no matches for "${query}" yet`
: `No matches for "${query}" in ${indexedTotal.toLocaleString()} tracks`
: totalMatches > shown.length
? `Showing ${shown.length} of ${totalMatches.toLocaleString()} matches for "${query}"`
: `${totalMatches} ${totalMatches === 1 ? "match" : "matches"} for "${query}"`;
state.list.appendChild(buildHeader(summary));
if (shown.length) {
state.list.appendChild(buildColumns());
const body = document.createElement("div");
body.className = "sls-fl-body";
const fragment = document.createDocumentFragment();
shown.forEach((track, position) => fragment.appendChild(buildRow(track, position)));
body.appendChild(fragment);
body.addEventListener("click", (event) => {
const row = event.target.closest?.(".sls-fl-row");
if (!row) return;
event.preventDefault();
event.stopPropagation();
const track = shown[Number(row.dataset.slsIndex)];
if (track && state.onActivate) state.onActivate(track);
});
body.addEventListener("keydown", (event) => {
if (event.key !== "Enter" && event.key !== " ") return;
const row = event.target.closest?.(".sls-fl-row");
if (!row) return;
event.preventDefault();
const track = shown[Number(row.dataset.slsIndex)];
if (track && state.onActivate) state.onActivate(track);
});
state.list.appendChild(body);
}
state.active = true;
return true;
}
function restore() {
if (state.grid) state.grid.classList.remove("sls-fl-hidden");
/* Defensive: a re-render can leave an orphaned marker on a grid we no
* longer hold a reference to. */
for (const node of document.querySelectorAll(".sls-fl-hidden")) {
node.classList.remove("sls-fl-hidden");
}
state.list?.remove();
state.list = null;
state.grid = null;
state.active = false;
}
/* Called from the content script's throttled reconcile pass, so an active
* filter survives Spotify re-rendering the page underneath it. */
function reconcile() {
if (!state.active) return;
if (!state.list?.isConnected || !state.grid?.isConnected) {
restore();
return;
}
state.grid.classList.add("sls-fl-hidden");
}
window.SLSTracklist = {
apply,
restore,
reconcile,
isActive: () => state.active,
setHandlers: ({ onActivate, onClear }) => {
state.onActivate = onActivate;
state.onClear = onClear;
}
};
})();