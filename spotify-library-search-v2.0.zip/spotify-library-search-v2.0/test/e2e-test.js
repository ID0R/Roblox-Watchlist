"use strict";
const { makeLibrary, FakeGrid, install } = require("./fake-dom.js");

const BASE = "..";

(async () => {
  // 1. Harvest 935 tracks off a fake page.
  const tracks = makeLibrary(935);
  const grid = new FakeGrid(tracks, {});
  install(grid);
  require(`${BASE}/content/harvest.js`);

  const harvested = await global.window.SLSHarvest.harvest({});
  console.log(`harvested            ${harvested.records.length} rows from the page`);

  // 2. Feed them through the real store + query engine with fake storage.
  const store = {};
  global.chrome = { storage: { local: {
    get: async (k) => { if (k === null) return {...store};
      const out = {}; for (const key of [].concat(k)) if (key in store) out[key] = store[key];
      return out; },
    set: async (o) => Object.assign(store, o),
    remove: async (k) => { for (const key of [].concat(k)) delete store[key]; }
  }}};

  const g = globalThis;
  require(`${BASE}/shared/text.js`);
  require(`${BASE}/shared/query.js`);
  require(`${BASE}/background/store.js`);

  const Store = g.SLSStore, Query = g.SLSQuery, Text = g.SLSText;

  const ctx = { type: "liked", label: "Liked Songs" };
  const written = await Store.write(ctx, harvested.records, { total: harvested.total });
  console.log(`stored               ${written.indexed} records in ${Object.keys(store).filter(k=>k.startsWith("idx.chunk")).length} chunks`);
  console.log(`storage footprint    ${(JSON.stringify(store).length/1024).toFixed(0)} KB`);

  const entry = await Store.load(ctx);

  function search(q, limit = 5) {
    const parsed = Query.parse(q);
    const dupes = new Set(); const seen = new Map();
    for (const s of entry.songs) { const fp = `${s._t}|${s._a}`;
      if (seen.has(fp)) { dupes.add(seen.get(fp)); dupes.add(s.id); } else seen.set(fp, s.id); }
    const t0 = process.hrtime.bigint();
    const hits = entry.songs
      .map(s => ({ s, score: Query.scoreSong(s, parsed, { playlistName: "liked songs", dupeIds: dupes }) }))
      .filter(x => x.score > 0).sort((a,b) => b.score - a.score);
    const us = Number(process.hrtime.bigint() - t0) / 1000;
    return { hits, us };
  }

  console.log("\nsearches over the harvested index:\n");
  // added:2024-08 pins to the fixed date two thirds of the fake rows carry, so
  // the count is the same next year. is:bogus must match nothing — an
  // unrecognised flag used to leave a query with no conditions at all, which
  // matched the entire library.
  for (const q of ["travis", "TRAVIS", "sicko", "dont", "artist:drake", "album:astroworld", "is:dupe", "is:bogus", "added:2024-08", "added:>2026-09", "travis -sicko"]) {
    const { hits, us } = search(q);
    const sample = hits.slice(0,2).map(h => `${h.s.n} — ${h.s.a[0]}`).join("; ");
    console.log(`  ${q.padEnd(18)} ${String(hits.length).padStart(4)} hits  ${us.toFixed(0).padStart(5)}µs   ${sample}`);
  }

  // 3. Verify the index round-trips through storage exactly.
  const reloaded = await Store.readSanity ? null : null;
  const names = entry.songs.map(s => s.n);
  const ok = names.length === tracks.length && names.every((n,i) => n === tracks[i].name);
  console.log(`\nindex matches page   ${ok ? "yes — all 935 in original order" : "NO"}`);

  // 4. Partial-flush merge, the thing that makes results appear mid-sweep.
  const partialA = harvested.records.slice(0, 40);
  const partialB = harvested.records.slice(40, 90);
  await Store.write(ctx, partialA, { partial: true });
  const afterA = (await Store.load(ctx)).songs.length;
  const merged = [...partialA, ...partialB];
  await Store.write(ctx, merged, { partial: true });
  const afterB = (await Store.load(ctx)).songs.length;
  console.log(`partial flush        ${afterA} then ${afterB} (grows, never replaces)`);
})();
