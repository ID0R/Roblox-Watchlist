# Architecture

## Layout

```
manifest.json
shared/
  text.js          normalisation, tokenisation, bounded edit distance
  query.js         query parser + scoring
content/
  harvest.js       reads the rendered tracklist  ← the engine
  sweep.js         whole-library walk, resumable across page loads
  tracklist.js     stands in for Spotify's grid while a query is active
  content.js       search UI, drives the harvester
  search.css
background/
  background.js    message router, search
  store.js         chunked index
options/           settings
popup/             toolbar status
icons/
docs/
```

`shared/` runs unchanged in both the content script and the worker, which is
why the worker uses `importScripts` rather than being an ES module. One copy of
the normaliser matters: two copies is how the row highlighter and the index end
up disagreeing about what "matches".

## The one-line version

The library is already in your browser. Read it from there.

## Where the data comes from

Nowhere. There is no network code in this extension. The host permission list
is a single entry — `https://open.spotify.com/*` — and it is used to inject a
content script, not to fetch anything.

Spotify's web player fetches your Liked Songs and playlists for its own
rendering, under your own session, and paints them on screen. Those rows are
the data source. `harvest.js` reads them.

This is what makes v2.0 immune to the failure that killed v1.2 and v1.3: a
rate limit applies to requests, and there are none.

## Virtualisation, and the only real obstacle

Spotify renders roughly fifteen rows at a time and recycles them as you scroll,
so at any instant the DOM holds a sliver of a 935-track playlist. Reading
`document.querySelectorAll` once gets you fifteen tracks.

So the harvester scrolls. Sixty steps for 935 tracks, finishing in under half a
second.

```
  arm mutation observer
  scroll by 80% of a viewport      ← 20% overlap, so a lagging render
  wait for the render to land         cannot open a seam
  collect every row by aria-rowindex
  repeat until aria-rowcount is satisfied, or nothing new appears
  then: fill any gaps by index, targeted
  then: restore the user's scroll position
```

Three properties do the work:

**`aria-rowindex` is identity.** Recycled rows arrive out of order and repeat.
Collection order means nothing; row index means everything. Deduplication is by
position, never by track id — collapsing by id would silently delete the
genuine duplicates that `is:dupe` exists to find.

**`aria-rowcount` is the finish line.** The grid publishes the true total, so
progress is "340 of 935" rather than "340 so far", and completion is a fact.

**The observer is armed before the scroll.** React commits a scroll-driven
re-render synchronously, so an observer attached afterwards has already missed
its mutation and waits out the full timeout every step. That one ordering
detail is 71 seconds versus 0.48 on a 935-track list.

### Gap filling

A linear sweep can skip rows if a render is dropped. Rather than sweeping again
and hoping, the harvester computes exactly which indices are missing and
scrolls to each. It repeats while it is still recovering rows and stops when a
full pass adds nothing — a fixed pass count loses rows whenever a gap-filling
scroll is itself dropped, which is the precise failure being worked around.

Scrolling to row *n* is `n × rowHeight` only if row 0 begins at scroll offset
zero, and it does not: Spotify paints a header above the grid — cover art,
title, play button, and on a playlist page a description too. That offset is
measured from a row currently on screen rather than assumed, because the header
is not a constant and differs between playlist, album and Liked Songs pages. An
unmeasured offset does not fail loudly; it turns every targeted scroll into a
near miss, which is the blind guessing gap filling exists to replace. The same
measurement puts "scroll to this result" on the right row.

### Lists that do not scroll

A playlist that fits on screen has no scroll container. Every row it has is
already rendered, so the harvester collects and returns. (The first draft threw
`NO_SCROLLER` here, which is the right error for the wrong situation.)

## What a row yields

Everything is read from links wherever possible, because a track's identity
lives in `/track/<id>`, an artist's in `/artist/<id>` and an album's in
`/album/<id>`. Those hrefs are what the player itself navigates with — far more
stable than class names, and unambiguous in a way text is not. Two tracks can
share a title; they cannot share an id.

| Field | Read from |
|---|---|
| id | `/track/<id>` href |
| name | track link text |
| artists | every `/artist/` link in the row |
| album | `/album/` link, or the cell between title and date |
| artwork | the row's `img` src |
| duration | the gridcell that looks like `m:ss` |
| date added | the gridcell before it, relative or absolute |
| position | `aria-rowindex` minus the header row |
| release year | **not available** — Spotify does not render it |

Duration and date are found by *shape*, not by column position, because reading
by position breaks the moment Spotify adds or removes a column. Duration is the
anchor: it is the one cell whose shape (`m:ss`) is unmistakable, so it is found
first and the date is read from the cell immediately before it. Accepting a
date from anywhere in the row is worse than reading none, because `Date.parse`
accepts a great deal of album text and answers with a confident, fictional
timestamp that then filters wrongly and silently.

Local files have no id and no links, so the whole row is plain text. They are
indexed with a synthetic id and flagged.

Dates arrive in two forms — "3 days ago" and "14 Aug 2024" — and both are
converted to a real timestamp, because `added:>2024-06` is worthless against a
string. Relative dates are approximate by nature, which is fine for a filter
measured in months.

What the page shows is a *calendar date*, not an instant, so it is stored as
one: UTC midnight of the day named, formatted back with `timeZone: "UTC"`, and
compared against boundaries built with `Date.UTC`. Storing local midnight and
serialising with `toISOString` moves the date back a day for every reader east
of Greenwich, so a track added on the 14th is filed under the 13th and the
extension's own row disagrees with the Spotify row beside it.

## Indexing runs in the page, not the worker

The structural decision of this release.

An MV3 service worker can be evicted at any moment. v1.2 ran multi-minute
builds inside one, awaited across a message boundary, and when the worker died
the caller's promise never settled — a spinner with nothing behind it. v1.3
fixed the awaiting and hit a different wall: a worker has no DOM, so it had to
ask Spotify's servers for data that was already on screen.

A content script has the DOM and lives exactly as long as the tab. So it
harvests, hands finished records to the worker in one message, and the worker's
entire job becomes storage and matching — handlers that complete in
milliseconds. Eviction is now irrelevant rather than fatal.

## The whole-library sweep

The player only loads a playlist's tracks when you open it. So the sweep opens
each one.

Navigation is attempted three ways, cheapest first: click a real sidebar link
(goes through the router, keeps the page alive, milliseconds); push history and
announce a popstate (React Router listens for it); full navigation (costs a
reload, always works).

Because the third is possible, **the sweep keeps no state in memory.** Queue,
cursor, running tally and the page to return to all live in
`chrome.storage.local`, re-read on every page load. A reload mid-sweep costs
two seconds, not the sweep.

Arriving is not the same as being ready: the URL changes immediately, the new
tracklist appears later, and harvesting in between reads the *previous*
playlist's rows under the new playlist's name. So the sweep waits for the page
to be both the right one and populated.

Playlists are also indexed opportunistically on every visit, so ordinary
browsing fills the cross-playlist index by itself.

## The stored index

One meta record plus one chunk per 500 tracks, per context, under `idx.*` in
`chrome.storage.local`. Chunking keeps a write proportional to the part that
changed rather than to the size of the library, and the worker holds a bounded
LRU of the contexts it has read recently — bounded because an unbounded cache
in a process that is *supposed* to be evicted is a leak that only shows up on
the largest libraries.

Every record carries two numbers that look interchangeable and are not:

| Field | Meaning |
|---|---|
| `i` | the record's ordinal in this stored index, 0…n-1, dense |
| `p` | the row position it was harvested from, sparse and authoritative |

They are equal for a finished harvest of a whole list, and they diverge exactly
where it matters. A mid-harvest flush renumbers its own records from zero, so a
flush carrying rows 500-539 stores them at ordinals 0-39. Merging the next
flush by ordinal then drops real row 40 onto record 12 and overwrites a
different track — 120 harvested rows quietly becoming 80. The merge in
`handleIngestPartial` therefore keys on `p`, the "#" column in the stand-in
list reads `p`, and `SCHEMA_VERSION` was raised to 11 so no index written
before `p` existed can be read as though it had one.

Only a finished write touches the playlist directory. Partial flushes arrive
every few hundred milliseconds, and a directory update is a read plus a rewrite
of every playlist the user owns.

## Search

Pure local matching over normalised strings. Case folding, accent folding and
apostrophe removal happen once at index time and once per query — never per
row. `travis`, `Travis` and `TRAVIS` produce byte-identical queries; if search
ever looks case sensitive, the bug is that `Text.normalize` was not reached.

Per-term scores are **averaged**, not summed: summing let a three-word query
that merely contained each word outrank an exact title match. Fuzzy matching is
a fallback that runs only when the exact pass returns fewer than three results
and the query is at least four characters, with a typo budget that scales with
word length so "love" does not fuzzily match "live", "lose" and "dove".

Measured on 935 harvested tracks: 221 KB stored, 1.6 ms per search.

## Filtering the list on the page

Hiding non-matching rows does not work — the list is virtualised, so you would
be filtering the thirty rows on screen and corrupting the scroll maths doing
it. `tracklist.js` hides the native grid with one class and renders a list of
its own in its place, from the index, showing every match in the whole playlist
with real positions.

The native grid is never removed or rewritten, which makes restoring it one
`classList.remove` — and matters more now, because the harvester needs to
scroll it. A harvest restores the native list first and puts the filter back
afterwards.

## Playback

Every indexed track was read off a row, so every indexed track has a row. The
locator scrolls to its known position and clicks Spotify's own play control, so
queue behaviour is identical to clicking the row yourself. The row play button
only exists while the row is hovered, so the pointer sequence is synthesised
first.

The old Premium-only API fallback is gone and not missed.

## UI contract

- One search control, inserted before the action bar's right-hand cluster with
  `margin-inline-end: auto`. The bar is **derived, not hard-coded**: test ids
  first, then a walk up from the big play button to the first ancestor spanning
  the content width.
- One dropdown, portaled to `<body>`, because Spotify's nested scroll
  containers and transforms clip anything mounted inside them.
- A sweep gets a fixed overlay rather than a dropdown line, because it
  navigates the page and must survive that.
- **Every state gets a sentence with a number in it.** Reading, sweeping,
  failing. Every loop in this codebase has a deadline and a progress counter,
  and stops when the counter stops. A turning spinner over an empty box is
  indistinguishable from a hang — which is the failure this project shipped
  three times, and the reason for most of the rules above.
