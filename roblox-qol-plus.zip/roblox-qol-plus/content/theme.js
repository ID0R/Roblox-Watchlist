(function () {
  function apply(settings) {
    const enabled = Boolean(settings && settings.darkThemeEnabled);
    document.documentElement.classList.toggle("qolplus-dark-theme", enabled);
    const hue = (settings && settings.accentHueDeg) || 180;
    document.documentElement.style.setProperty("--qolplus-hue", `${hue}deg`);
  }

  chrome.storage.local.get("settings").then(({ settings }) => apply(settings));

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.settings) apply(changes.settings.newValue);
  });
})();
